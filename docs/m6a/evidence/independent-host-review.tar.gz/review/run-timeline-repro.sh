#!/bin/bash
set -eu
ROOT=/workspace/scratch/df6c1284d5ab
HERE="$ROOT/esv-m6a-review"
REPO="$ROOT/EasySaveVideo"
COMPILER="$ROOT/android-build-home/gradle-home/wrapper/dists/gradle-9.6.0-bin/42k10rwplmzkhuboz9kdazi7s/gradle-9.6.0/lib"
STDLIB="$COMPILER/kotlin-stdlib-2.3.21.jar"
mkdir -p "$HERE/classes"
java -cp "$COMPILER/*" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -jvm-target 17 \
 -classpath "$STDLIB:$REPO/library/build/classes/kotlin/main" -d "$HERE/classes" \
 "$HERE/EditVerificationPolicy.wip.kt" "$HERE/EditMp4Probe.wip.kt" "$HERE/EditAacConfigPolicy.wip.kt" "$HERE/TimelineRepro.kt"
java -cp "$HERE/classes:$REPO/library/build/classes/kotlin/main:$STDLIB" com.easysavevideo.app.editor.verification.TimelineReproKt
