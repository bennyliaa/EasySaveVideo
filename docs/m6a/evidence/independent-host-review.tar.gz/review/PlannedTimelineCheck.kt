package com.easysavevideo.app.editor.verification

import com.easysavevideo.library.MediaReadRef
import com.easysavevideo.library.edit.*
import kotlin.random.Random

/** Current production core planner + independent verifier policy, with synthetic source clocks. */
fun main() {
    var cases = 0
    val random = Random(6102026)
    for (fps in listOf(3, 5, 24, 25, 30, 60)) for (roundUp in listOf(false, true)) repeat(50) {
        val duration = 10_000_000L
        val inputTimes = LongArray(fps * 10) { index -> (index * 1_000_000L + if (roundUp) fps - 1 else 0) / fps }
        val timeline = EditFrameTimeline(inputTimes, duration)
        val ref = MediaReadRef("source", 1, 1)
        val metadata = EditSourceMetadata(ref, duration, 640, 360, 0, fps, EditAudioProfile.Silent, 1024,
            avcProfile = EditAvcProfile.HIGH, color = EditColorProfile.SDR, squarePixels = true,
            constantFrameRate = true, bitDepth = 8, frameTimeline = timeline)
        val segments = List(random.nextInt(1, 9)) {
            val start = random.nextLong(0, 6_000_000)
            val end = (start + random.nextLong(if (fps == 3) 2_000_000 else 1_200_000, 4_000_000)).coerceAtMost(duration)
            EditSegment(ref, start, end)
        }
        val request = EditRequest("repro", segments)
        val fingerprint = request.fingerprint()
        val plan = EditPlanner.plan(request, listOf(metadata))
        check(fingerprint == plan.request.fingerprint())
        val output = mutableListOf<Long>()
        plan.segments.forEach { segment ->
            check(segment.executionStartUs >= segment.segment.startUs)
            check(segment.executionEndUsExclusive <= segment.segment.endUsExclusive)
            val snapped = timeline.snapInward(segment.segment.startUs, segment.segment.endUsExclusive)
            repeat(snapped.frameCount) { i ->
                val raw = segment.outputStartUs + timeline.frameTimeUs(snapped.firstFrameIndex + i) - snapped.startUs
                // Simulate the pinned 90kHz MP4 clock's one-way integer quantization.
                output += raw * 90_000 / 1_000_000 * 1_000_000 / 90_000
            }
        }
        check(output.size.toLong() == plan.expectation.videoFrameCount)
        val last = output.last() - output[output.lastIndex - 1]
        val track = EditMp4Track("vide", IntArray(output.size) { 4 }, output.size * 4L, 1_000_000,
            output.last() + last, last, plan.expectation.width, plan.expectation.height, 0, 100)
        val ledger = EditSampleLedger(true, plan.expectation, track)
        output.forEachIndexed { index, pts -> ledger.sample(pts, 4, if (index == 0) 1 else 0) }
        val scan = ledger.finish()
        check(scan.samples.size == output.size)
        val proof = EditVerificationEvidence(EditOutputRef("repro", "artifact"), plan.expectation, 1024,
            "0".repeat(64), scan.endUs, plan.expectation.width, plan.expectation.height, 0, "video/avc", null, null, null,
            output.first(), output.last(), output.size.toLong(), 0, output.size.toLong(), 0, true, false, true, true)
        check(proof.validFor(proof.output, plan.expectation))
        cases++
    }
    val fixedRef = MediaReadRef("fixed", 1, 1)
    val fixedSource = EditSourceMetadata(fixedRef, 1_000_000, 640, 360, 0, 30, EditAudioProfile.Silent, 1024,
        avcProfile = EditAvcProfile.HIGH, color = EditColorProfile.SDR, squarePixels = true,
        constantFrameRate = true, bitDepth = 8,
        frameTimeline = EditFrameTimeline(LongArray(30) { it * 1_000_000L / 30 }, 1_000_000))
    val fixedPlan = EditPlanner.plan(EditRequest("fixed", List(2) { EditSegment(fixedRef, 0, 250_000) }), listOf(fixedSource))
    check(fixedPlan.expectation.videoFrameCount == 14L && fixedPlan.expectation.durationUs == 466_666L)
    check(fixedPlan.request.segments.all { it.endUsExclusive == 250_000L })
    val audioSource = fixedSource.copy(audio = EditAudioProfile.Aac(48_000, 2))
    val cutPlan = EditPlanner.plan(EditRequest("cut", listOf(EditSegment(fixedRef, 10_000, 1_000_000))), listOf(audioSource))
    check(cutPlan.segments.single().executionStartUs == 33_333L && cutPlan.expectation.videoFrameCount == 29L)
    println("PASS: original 250ms merge and 10ms A/V trim counterexamples now have explicit inward execution ranges and preserved requested provenance.")
    println("PASS: $cases deterministic synthetic trim/merge plans preserve original request, snap inward, and satisfy current exact-count verifier after simulated 90kHz rounding.")
    println("Scope: production Kotlin planner/verification policy only. Media3 encode/decode, Android/GPU/OEM behavior are NOT_RUN.")
}
