#!/bin/bash
set -eu
ROOT=/workspace/scratch/df6c1284d5ab
HERE="$ROOT/esv-m6a-review/native"
REPO="$ROOT/EasySaveVideo"
COMPILER="$ROOT/android-build-home/gradle-home/wrapper/dists/gradle-9.6.0-bin/42k10rwplmzkhuboz9kdazi7s/gradle-9.6.0/lib"
STDLIB="$COMPILER/kotlin-stdlib-2.3.21.jar"
mkdir -p "$HERE/gl-harness/classes" "$HERE/policy-harness/classes"
java --module jdk.compiler/com.sun.tools.javac.Main -d "$HERE/gl-harness/classes" $(find "$HERE/gl-harness" -name '*.java')
java -cp "$HERE/gl-harness/classes" androidx.media3.effect.ReleaseOrderRepro | tee "$HERE/gl-release-repro.log"
java -cp "$HERE/gl-harness/classes" androidx.media3.effect.ReleaseErrorRepro | tee "$HERE/gl-release-error-repro.log"
java -cp "$HERE/gl-harness/classes" InterruptCleanupRepro | tee "$HERE/interrupt-cleanup-repro.log"
java -cp "$COMPILER/*" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -jvm-target 17 \
 -classpath "$STDLIB:$REPO/library/build/classes/kotlin/main" -d "$HERE/policy-harness/classes" \
 "$REPO/library/src/main/kotlin/com/easysavevideo/library/edit/EditContracts.kt" \
 "$REPO/library/src/main/kotlin/com/easysavevideo/library/edit/EditFrameTimeline.kt" \
 "$REPO/library/src/main/kotlin/com/easysavevideo/library/edit/EditGeometry.kt" \
 "$REPO/app/src/main/kotlin/com/easysavevideo/app/editor/engine/EditorEnginePolicy.kt" \
 "$REPO/app/src/main/kotlin/com/easysavevideo/app/editor/engine/EditorCleanupWait.kt" \
 "$HERE/policy-harness/NativePolicyCheck.kt"
java -cp "$HERE/policy-harness/classes:$REPO/library/build/classes/kotlin/main:$STDLIB" com.easysavevideo.app.editor.engine.NativePolicyCheckKt | tee "$HERE/native-policy-check.log"
