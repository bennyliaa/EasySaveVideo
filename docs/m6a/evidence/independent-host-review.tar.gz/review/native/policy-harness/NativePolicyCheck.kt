package com.easysavevideo.app.editor.engine
import java.util.concurrent.FutureTask
fun main() {
 check(EditorEnginePolicy.timestampAllowed(-33_333, null, false, 1_000_000, 33_334, 42_667))
 check(!EditorEnginePolicy.timestampAllowed(-1, null, true, 1_000_000, 33_334, 42_667))
 check(!EditorEnginePolicy.timestampAllowed(-42_668, null, false, 1_000_000, 33_334, 42_667))
 val order=EditorNativeReleaseOrder();order.registerGl()
 check(order.allowsCodecRelease())
 order.beginGlRelease();check(!order.allowsCodecRelease())
 order.confirmGlReleased();check(order.allowsCodecRelease())
 val task=FutureTask<Unit>{throw AssertionError("synthetic cleanup error")};task.run()
 check(EditorTaskFailureProbe.failed(task,null));order.glFailed();check(!order.allowsCodecRelease())
 val frames=longArrayOf(0,39_999,80_000,120_000,160_000,200_000,240_000,280_000)
 check(EditorEnginePolicy.observedFrameRate(frames,frames.size,320_000)==25)
 val cleanup=java.util.concurrent.CompletableFuture<Unit>()
 val closer=Thread{Thread.sleep(40);cleanup.complete(Unit)}.apply{start()}
 try {
  Thread.currentThread().interrupt()
  check(EditorCleanupWait.awaitCompletion(cleanup,2_000))
  check(cleanup.isDone && Thread.currentThread().isInterrupted)
 } finally {Thread.interrupted();closer.join(2_000)}
 val never=java.util.concurrent.CompletableFuture<Unit>()
 check(!EditorCleanupWait.awaitCompletion(never,20))
 println("PASS: current policy accepts bounded negative AAC, rejects negative video/out-of-window audio, gates codec release on final GL cleanup, observes hidden Future Errors, admits the CFR rounding repro, preserves interrupted cleanup acknowledgement, and rejects genuine timeout.")
 println("Host Kotlin policy checks only. No Android, MediaCodec, Surface, or GL ran.")
}
