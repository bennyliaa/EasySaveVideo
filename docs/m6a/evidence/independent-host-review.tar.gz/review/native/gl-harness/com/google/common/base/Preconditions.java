package com.google.common.base; public class Preconditions { public static void checkState(boolean b){if(!b)throw new IllegalStateException();} }
