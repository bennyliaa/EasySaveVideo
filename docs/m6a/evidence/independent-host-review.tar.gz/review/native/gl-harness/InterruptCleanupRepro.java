import java.util.concurrent.*;
public final class InterruptCleanupRepro {
 public static void main(String[] args) throws Exception {
  CompletableFuture<Boolean> release = new CompletableFuture<>();
  Thread worker=new Thread(() -> {try {Thread.sleep(50);}catch(InterruptedException e){throw new AssertionError(e);}release.complete(true);});
  worker.start();
  Thread.currentThread().interrupt();
  long start=System.nanoTime();
  boolean returnedImmediately=false;
  try {release.get(10,TimeUnit.SECONDS);} catch(InterruptedException expected){returnedImmediately=true;}
  if (!returnedImmediately || release.isDone()) throw new AssertionError("expected skipped cleanup wait");
  long elapsedMillis=TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-start);
  worker.join();
  System.out.println("CONFIRMED: interrupted get skipped cleanup wait after "+elapsedMillis+" ms; ordinary worker release succeeded later.");
 }
}
