package androidx.media3.common.util; public class Util { public static boolean isRunningOnEmulator(){return false;} }
