package androidx.media3.effect;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
public final class ReleaseOrderRepro {
 public static void main(String[] args) throws Exception {
  ExecutorService executor = Executors.newSingleThreadExecutor();
  List<String> events = Collections.synchronizedList(new ArrayList<>());
  CountDownLatch running = new CountDownLatch(1), finishActiveTask = new CountDownLatch(1);
  AtomicBoolean shadersReleased = new AtomicBoolean();
  VideoFrameProcessingTaskExecutor actualPinned = new VideoFrameProcessingTaskExecutor(executor, false, error -> { throw new AssertionError(error); });
  actualPinned.submit(() -> {events.add("GL task running"); running.countDown(); try { finishActiveTask.await(); } catch(InterruptedException e){throw new AssertionError(e);} });
  if (!running.await(2,TimeUnit.SECONDS)) throw new AssertionError("setup");
  actualPinned.release(() -> { shadersReleased.set(true); events.add("shader and SurfaceTexture cleanup"); });
  executor.execute(() -> events.add("GlObjectsProvider cleanup"));
  executor.shutdown();
  events.add("processor.release returned");
  events.add("VideoSampleExporter encoder.release permitted");
  if (shadersReleased.get()) throw new AssertionError("Expected active task to block cleanup");
  System.out.println("CONFIRMED: actual pinned external-executor release returned before queued shader cleanup.");
  finishActiveTask.countDown();
  if (!executor.awaitTermination(2,TimeUnit.SECONDS)) throw new AssertionError("teardown");
  System.out.println(String.join(" -> ",events));
  System.out.println("Host executor/control-flow test only. No Android, MediaCodec, Surface, or GL ran.");
 }
}
