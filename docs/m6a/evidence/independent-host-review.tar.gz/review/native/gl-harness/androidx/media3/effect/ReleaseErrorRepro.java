package androidx.media3.effect;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
public final class ReleaseErrorRepro {
 public static void main(String[] args) throws Exception {
  ExecutorService executor = Executors.newSingleThreadExecutor();
  AtomicInteger reported = new AtomicInteger(), followingBarrier = new AtomicInteger();
  VideoFrameProcessingTaskExecutor actualPinned = new VideoFrameProcessingTaskExecutor(executor, false, error -> reported.incrementAndGet());
  actualPinned.release(() -> { throw new AssertionError("injected cleanup Error"); });
  executor.execute(() -> followingBarrier.incrementAndGet());
  executor.shutdown();
  if (!executor.awaitTermination(2,TimeUnit.SECONDS)) throw new AssertionError("teardown");
  if (reported.get()!=0 || followingBarrier.get()!=1) throw new AssertionError("unexpected proof");
  System.out.println("CONFIRMED: cleanup Error was swallowed by ignored Future; no error listener event; following FIFO barrier ran.");
  System.out.println("Host exception/control-flow test only. No Android, MediaCodec, Surface, or GL ran.");
 }
}
