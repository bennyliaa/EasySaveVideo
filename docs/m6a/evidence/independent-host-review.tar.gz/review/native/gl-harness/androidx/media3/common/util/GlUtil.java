package androidx.media3.common.util; public class GlUtil { public static class GlException extends Exception {} }
