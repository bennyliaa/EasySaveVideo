#!/bin/bash
set -eu
ROOT=/workspace/scratch/df6c1284d5ab
HERE="$ROOT/esv-m6a-review"
REPO="$ROOT/EasySaveVideo"
COMPILER="$ROOT/android-build-home/gradle-home/wrapper/dists/gradle-9.6.0-bin/42k10rwplmzkhuboz9kdazi7s/gradle-9.6.0/lib"
STDLIB="$COMPILER/kotlin-stdlib-2.3.21.jar"
CORE="$REPO/library/src/main/kotlin/com/easysavevideo/library"
VERIFY="$REPO/app/src/main/kotlin/com/easysavevideo/app/editor/verification"
mkdir -p "$HERE/planned-classes"
java -cp "$COMPILER/*" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -jvm-target 17 \
 -classpath "$STDLIB" -d "$HERE/planned-classes" \
 "$CORE/LibraryModels.kt" "$CORE/LibraryPolicies.kt" "$CORE/edit/EditContracts.kt" \
 "$CORE/edit/EditGeometry.kt" "$CORE/edit/EditFrameTimeline.kt" "$CORE/edit/EditPlanner.kt" "$CORE/edit/EditVerificationEvidence.kt" \
 "$VERIFY/EditVerificationPolicy.kt" "$VERIFY/EditMp4Probe.kt" "$VERIFY/EditAacConfigPolicy.kt" "$HERE/PlannedTimelineCheck.kt"
java -cp "$HERE/planned-classes:$STDLIB" com.easysavevideo.app.editor.verification.PlannedTimelineCheckKt
