package com.easysavevideo.app.editor.verification

import com.easysavevideo.library.edit.*

/** Executes WIP production verification policy against synthetic timestamps only. */
fun main() {
    fun mustReject(label: String, action: () -> Unit) {
        try { action(); error("Unexpected acceptance: $label") }
        catch (failure: EditFailure) { println("REPRODUCED: $label -> ${failure.code}") }
    }
    val joined = (0..7).map { it * 1_000_000L / 30 } + (0..7).map { 250_000L + it * 1_000_000L / 30 }
    val joinExpected = EditOutputExpectation(500_000, 16, 16, 30, EditAudioProfile.Silent, 66_668, 0)
    val joinTiming = EditMp4Track("vide", IntArray(joined.size) { 4 }, joined.size * 4L, 1_000_000,
        joined.last() + 33_333, 33_333, 16, 16, 0, 66)
    mustReject("two admitted 250ms CFR30 clips have 16667us internal join step") {
        val ledger = EditSampleLedger(true, joinExpected, joinTiming)
        joined.forEachIndexed { index, pts -> ledger.sample(pts, 4, if (index == 0) 1 else 0) }
        ledger.finish()
    }
    val cut = (1..29).map { it * 1_000_000L / 30 - 10_000 }
    val cutExpected = EditOutputExpectation(990_000, 16, 16, 30, EditAudioProfile.Aac(48_000, 2), 33_334, 42_667)
    val cutTiming = EditMp4Track("vide", IntArray(cut.size) { 4 }, cut.size * 4L, 1_000_000,
        cut.last() - cut.first() + 33_333, 33_333, 16, 16, 0, 66)
    mustReject("A/V trim at 10ms with audio at zero keeps first video at 23333us") {
        val ledger = EditSampleLedger(true, cutExpected, cutTiming)
        cut.forEachIndexed { index, pts -> ledger.sample(pts, 4, if (index == 0) 1 else 0) }
        ledger.finish()
    }
    println("Scope: host Kotlin policy and synthetic timestamp contracts, not Android/Media3 encode, decode, GPU, or OEM proof.")
}
