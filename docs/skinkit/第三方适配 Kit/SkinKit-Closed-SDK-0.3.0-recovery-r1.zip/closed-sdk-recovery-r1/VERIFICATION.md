# SkinKit reconstruction checkpoint, 2026-10-10

This is new reconstruction work based on main 0f218f0681117251e130a78438c64005b1492451 and code9 2ee5c29. Original code10 d4c64 and ce7715 objects remain missing. No original-code10 recovery claim is made.

Implemented: one SAF ZIP export; strict original resource manifest/hash verification; bounded copy and fresh target readback; asynchronous cancellation and cleanup drain; request identity, rotation retention and process interruption handling. Failure/cancellation does not delete the user's target. Only known empty, seekable targets are accepted. Existing SDK implementation sources remain unchanged.

Packaging preparation: removed source publication variants from 17 SDK modules, added four comment-only consumer rules files, restored 31 binary-host files from the original SDK sample, and added preparation, staging, packaging, verification and POSIX test-input scripts. Original Ready documents, APK and SDK ZIP remain intact. New debug APKs are unsigned, version 0.3.0-recovery-r1; formal V1.0.0 release remains pending.

Final direct export JUnit: 20/20 PASS. Final default-animation and no-animation demo runs: filtered export tests 20/20 PASS; lintDebug, assembleDebug and compileReleaseKotlin PASS. Logs are in build/recovery-evidence, with selected copies in evidence/.

Whole-demo Windows run before the final source-close guard: 67 tests, 9 failures, no errors; 19 export tests passed. All nine failures were existing directory synchronization storage cases. The current 68-test suite has NOT been run as a whole on POSIX.

Original SDK binary-host: 3 tests, 2 Windows storage failures, 1 stale gate test passed. Newly staged SDK base and animation configurations: the same 3 tests and same 2 failures. Both configurations passed lint, R8, resource shrink and release assembly under --continue. Failures are FileChannel.open(directory, READ) AccessDeniedException on Windows, reproduced by an independent directory-channel probe. No SDK workaround was introduced.

All 17 staged SDK compiled-entry inventories match the original SDK exactly (697 classes total). The recovery SDK candidate has now been packaged and passed static archive, POM/module, public API, original-document, license, source exclusion and credential-pattern checks. Its 236 members contain 13 JARs, 4 release AARs, 67 POMs and 62 inventoried components. Device SAF-provider, rotation, accessibility, production signing and fresh final-archive host build remain NOT_RUN. No GitHub push or candidate upload was performed.

Updated parent-reported Linux result: r3 ran twice with demo 68/68 and binary-host 3/3 passed, including ResourceExport 20/20. Total per run: 71 passed, 0 failed, 0 skipped. The parent verified the original 29 test classes unchanged plus exactly 5 missing classes added, every production/dependency JAR unchanged, 11 text fixtures changed only from CRLF to LF, and 14 fixture checksums passed. This is execution of precompiled JVM inputs, not a fresh source rebuild or Android acceptance. Raw Linux reports reside with the parent; these records attribute the result rather than invent local logs. Windows failure records remain unchanged.

r3 input ZIP SHA256 a7d37ed95cf04852a26bf4d549e547f4d7b399c7803df2ec03cd5cb1e50e450d, Library ID libfile_5b50ececc64c8191b15681eb2af28e3e. Manifest SHA256 1f4d7b5272bd3bc024190f3a14e6caaa5fffb569078f1486f36f113cba04d5d2, Library ID libfile_68897b6678e08191aac4702a60f18854. Application/SDK source identity remains 060c2afa3a6ebf9661c5c99539b315d3e1f863ba. All older r1/r2 inputs and failure evidence are preserved.

The Linux consumer preserved the original r3 run.sh and executed a separate LF copy. Future preparation explicitly writes LF shell-script bytes; the original r3 package is unchanged.

Current next step: review the static candidate and plan fresh final-archive host build and device SAF-provider acceptance separately. Production signing remains unexecuted. Do not promote the earlier historical package PASS text into current acceptance. No upload or push is authorized in this packaging step.
