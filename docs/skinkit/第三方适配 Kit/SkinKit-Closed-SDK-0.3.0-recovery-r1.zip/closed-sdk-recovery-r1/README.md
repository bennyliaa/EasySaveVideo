# SkinKit binary SDK — recovery candidate 2026-10-10

This is newly built from code9 plus restored publication configuration; it is not the missing code10 Git source.
17 modules: 13 JVM JAR + 4 release Android AAR, Java 17 bytecode, minSdk 26, compileSdk 36.
sample-host consumes only Maven binaries. Use its skinKitRepo property or the adjacent maven/ directory.
No sources JAR, SDK implementation source, WeChat adapter, keys, maps, user photos, or build tools are delivered.
Commercial use and future updates follow LICENSE-SKINKIT.txt; no IAP or separate export purchase exists.
Device behavior and production signing are NOT_RUN. See the NEW recovery verification report, not historical PASS notes.
Linux r3 precompiled inputs passed 71 tests twice as reported by the parent. This is not a fresh source rebuild or a host build against this final archive.
The two original requirement documents are preserved byte-for-byte under docs/.
