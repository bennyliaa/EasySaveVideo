# Dependency notices — recovery candidate

The measured runtime graphs and sample test dependencies are in DEPENDENCY-INVENTORY.json. Every third-party binary matches the approved original SDK inventory byte-for-byte; original license texts and notices remain in third-party-licenses/.

- androidx.activity:activity:1.6.0 (runtime): The Apache Software License, Version 2.0
- androidx.annotation:annotation-experimental:1.3.0 (runtime): The Apache Software License, Version 2.0
- androidx.annotation:annotation:1.3.0 (runtime): The Apache Software License, Version 2.0
- androidx.appcompat:appcompat-resources:1.6.1 (runtime): The Apache Software License, Version 2.0
- androidx.appcompat:appcompat:1.6.1 (runtime): The Apache Software License, Version 2.0
- androidx.arch.core:core-common:2.1.0 (runtime): The Apache Software License, Version 2.0
- androidx.arch.core:core-runtime:2.1.0 (runtime): The Apache Software License, Version 2.0
- androidx.collection:collection:1.1.0 (runtime): The Apache Software License, Version 2.0
- androidx.concurrent:concurrent-futures:1.0.0 (runtime): The Apache Software License, Version 2.0
- androidx.core:core-ktx:1.9.0 (runtime): The Apache Software License, Version 2.0
- androidx.core:core:1.9.0 (runtime): The Apache Software License, Version 2.0
- androidx.cursoradapter:cursoradapter:1.0.0 (runtime): The Apache Software License, Version 2.0
- androidx.customview:customview:1.0.0 (runtime): The Apache Software License, Version 2.0
- androidx.drawerlayout:drawerlayout:1.0.0 (runtime): The Apache Software License, Version 2.0
- androidx.emoji2:emoji2-views-helper:1.2.0 (runtime): The Apache Software License, Version 2.0
- androidx.emoji2:emoji2:1.2.0 (runtime): The Apache Software License, Version 2.0
- androidx.fragment:fragment:1.3.6 (runtime): The Apache Software License, Version 2.0
- androidx.interpolator:interpolator:1.0.0 (runtime): The Apache Software License, Version 2.0
- androidx.lifecycle:lifecycle-common:2.5.1 (runtime): The Apache Software License, Version 2.0
- androidx.lifecycle:lifecycle-livedata-core:2.5.1 (runtime): The Apache Software License, Version 2.0
- androidx.lifecycle:lifecycle-livedata:2.0.0 (runtime): The Apache Software License, Version 2.0
- androidx.lifecycle:lifecycle-process:2.4.1 (runtime): The Apache Software License, Version 2.0
- androidx.lifecycle:lifecycle-runtime:2.5.1 (runtime): The Apache Software License, Version 2.0
- androidx.lifecycle:lifecycle-viewmodel-savedstate:2.5.1 (runtime): The Apache Software License, Version 2.0
- androidx.lifecycle:lifecycle-viewmodel:2.5.1 (runtime): The Apache Software License, Version 2.0
- androidx.loader:loader:1.0.0 (runtime): The Apache Software License, Version 2.0
- androidx.resourceinspection:resourceinspection-annotation:1.0.1 (runtime): The Apache Software License, Version 2.0
- androidx.savedstate:savedstate:1.2.0 (runtime): The Apache Software License, Version 2.0
- androidx.startup:startup-runtime:1.1.1 (runtime): The Apache Software License, Version 2.0
- androidx.tracing:tracing:1.0.0 (runtime): The Apache Software License, Version 2.0
- androidx.vectordrawable:vectordrawable-animated:1.1.0 (runtime): The Apache Software License, Version 2.0
- androidx.vectordrawable:vectordrawable:1.1.0 (runtime): The Apache Software License, Version 2.0
- androidx.versionedparcelable:versionedparcelable:1.1.1 (runtime): The Apache Software License, Version 2.0
- androidx.viewpager:viewpager:1.0.0 (runtime): The Apache Software License, Version 2.0
- com.airbnb.android:lottie:6.7.1 (runtime): Apache-2.0
- com.google.guava:listenablefuture:1.0 (runtime): The Apache Software License, Version 2.0
- com.squareup.okio:okio:1.17.6 (runtime): Apache 2.0
- junit:junit:4.13.2 (test): Eclipse Public License 1.0
- org.hamcrest:hamcrest-core:1.3 (test): New BSD License
- org.jetbrains.kotlin:kotlin-stdlib-jdk7:1.8.0 (runtime): The Apache License, Version 2.0
- org.jetbrains.kotlin:kotlin-stdlib-jdk8:1.8.0 (runtime): The Apache License, Version 2.0
- org.jetbrains.kotlin:kotlin-stdlib:2.2.10 (runtime): The Apache License, Version 2.0
- org.jetbrains.kotlinx:kotlinx-coroutines-android:1.6.1 (runtime): The Apache Software License, Version 2.0
- org.jetbrains.kotlinx:kotlinx-coroutines-core-jvm:1.6.1 (runtime): The Apache Software License, Version 2.0
- org.jetbrains:annotations:13.0 (runtime): The Apache Software License, Version 2.0

The Gradle 9.6.0 wrapper is Apache-2.0; distribution, AGP, JDK and Android build tools are not included. SkinKit licensing does not replace upstream obligations. Demo artwork provenance is in third-party-licenses/SkinKit-Demo-Assets.txt and the sample theme catalog.
