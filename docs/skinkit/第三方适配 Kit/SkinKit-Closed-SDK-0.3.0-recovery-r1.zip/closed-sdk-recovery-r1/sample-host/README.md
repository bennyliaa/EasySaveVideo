# SkinKit binary-only host sample

This is one standalone Android screen with host-owned glue, not SDK implementation source. It uses only the sibling `maven/` binaries. The app ID is `dev.skinkit.binaryhost`, so it cannot overwrite Theme Lab or Pocket List.

## Build

Requires JDK 21 to run the checked-in Gradle 9.6.0 wrapper, Android SDK 36/build-tools 36.0.0 and AGP 9.4.0. Source/target bytecode is Java 17; minSdk is 26. Set `ANDROID_HOME` or a local `local.properties` file. Build tools are not included in the SDK ZIP; an offline build needs their existing caches.

```sh
./gradlew :app:testDebugUnitTest :app:assembleDebug :app:assembleRelease
./gradlew -PwithAnimation=true :app:testDebugUnitTest :app:assembleRelease
```

The default repository is `../maven`. Override with `-PskinKitRepo=/absolute/path/to/maven` when desired. `--offline` worked in the verified cached build environment. External build-tool repositories explicitly exclude `dev.skinkit`; SDK source projects, source JARs and Maven Central SkinKit artifacts are never consulted.

`assembleRelease` enables R8 and resource shrinking and produces an **unsigned test artifact**, not a store-ready release. Supply your own authorized signing configuration and complete device acceptance before distribution. No signing key is included here.

## Read the source in this order

1. `ShowcaseTheme.kt`: eight host-owned tokens, complete Light/Dark defaults and a typed extension descriptor.
2. `ShowcaseStorage.kt` / `ShowcaseRuntime.kt`: trusted parent/private child storage, asynchronous install/activate/restore and owner lifetimes.
3. `ShowcaseSurfaces.kt`: render pins, resource leases, generation checks, shared image loader/drawable and typed role geometry.
4. `ShowcasePersonal.kt`: the reusable SDK photo editor launcher, schema/directory, per-role focus/scale and applied-profile reads.
5. `AppearanceShowcaseActivity.kt`: one native screen, text protection, system/IME insets, theme list, independent accent selection and lifecycle/rotation forwarding.
6. `BinaryApiTest.kt`: real binary install/activate of all five packaged styles in both modes, default restoration, private-store round trip and stale-render gate checks.

The sample's illustrated packages are public project demo assets with per-resource provenance in `assets/themes/catalog.json`. They are not a user's photos. The ordinary default is resource-free. Personal imports happen only through the SDK's system picker, with app-private normalized copies.

Store, Commerce and Community JARs are included as optional interfaces for compilation; this screen does not configure or contact any server. `-PwithAnimation=true` checks the optional player dependency closure and shrinker; the screen remains a static-capability host and does not claim animation playback qualification.

This sample demonstrates integration, not a universal component framework or a Compose adapter. Every production host still owns its business UI, its complete defaults, accessibility, device-specific layout and lifecycle acceptance. Keep SDK/store operations off the UI thread, discard stale async results, and drain the editor before closing borrowed stores/sessions.
