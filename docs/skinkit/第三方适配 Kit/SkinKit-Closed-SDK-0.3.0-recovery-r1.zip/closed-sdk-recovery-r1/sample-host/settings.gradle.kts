pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        maven { url = uri(providers.gradleProperty("skinKitRepo").getOrElse("../maven")) }
        google { content { excludeGroup("dev.skinkit") } }
        mavenCentral { content { excludeGroup("dev.skinkit") } }
    }
}
rootProject.name = "SkinKitBinaryHost"
include(":app")
