package dev.skinkit.binaryhost.appearance

import android.app.Activity
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.*
import dev.skinkit.appearance.AccentChoice
import dev.skinkit.appearance.AccentPalette
import dev.skinkit.appearance.SurfaceLayoutPolicy
import dev.skinkit.appearance.SurfaceRole
import dev.skinkit.appearance.android.ThemeSurfaceDrawable
import dev.skinkit.appearance.android.AppearanceWindowLayout
import dev.skinkit.contract.ColorMode
import dev.skinkit.contract.VisualConfiguration
import org.json.JSONObject

/** Real second Android host of the shared packages; business data never enters this screen. */
class AppearanceShowcaseActivity : Activity() {
    private val theme = ShowcaseTheme()
    private val gate = ShowcasePresentationGate()
    private lateinit var runtime: ShowcaseRuntime
    private var foreground = false
    private var retainedPersonal: Any? = null
    private var retainedPickerReply = false
    private data class RetainedPersonal(val state: Any?, val pickerReply: Boolean)
    private var note = "Plan something lovely"
    private val accents by lazy {
        val prefs = getSharedPreferences("appearance-showcase-ui", MODE_PRIVATE)
        ShowcaseAccentSelection({ key -> prefs.getString(key, null) }, { key, value ->
            prefs.edit().apply { if (value == null) remove(key) else putString(key, value) }.apply()
        })
    }
    private data class Pack(val file: String, val name: String, val themeId: String, val version: String)
    private val packs by lazy {
        val catalog = assets.open("themes/catalog.json").bufferedReader().use { JSONObject(it.readText()) }.getJSONArray("themes")
        (0 until catalog.length()).map { index -> catalog.getJSONObject(index).let {
            Pack(it.getString("fileName"), it.getString("displayName"), it.getString("themeId"), it.getString("version"))
        } }
    }
    private var scroll: ScrollView? = null
    private fun dp(value: Int) = (resources.displayMetrics.density * value + .5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        (lastNonConfigurationInstance as? RetainedPersonal)?.let {
            retainedPersonal = it.state; retainedPickerReply = it.pickerReply
        }
        if (Build.VERSION.SDK_INT >= 33) onBackInvokedDispatcher.registerOnBackInvokedCallback(
            android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT) { if (!runtime.personal.back()) finish() }
        val prefs = getSharedPreferences("appearance-showcase-ui", MODE_PRIVATE)
        note = savedInstanceState?.getString("note") ?: note
        val systemDark = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
        val dark = prefs.getBoolean("dark", systemDark)
        runtime = ShowcaseRuntime(this, theme, VisualConfiguration(if (dark) ColorMode.DARK else ColorMode.LIGHT,
            resources.configuration.fontScale.toDouble())) { if (foreground && !isDestroyed) render() }
    }
    override fun onStart() { super.onStart(); foreground = true; runtime.personal.setForeground(true); gate.foreground(true); render() }
    override fun onStop() { foreground = false; runtime.personal.setForeground(false); gate.foreground(false); super.onStop() }
    override fun onDestroy() { gate.close(); runtime.close(); super.onDestroy() }
    override fun onSaveInstanceState(outState: Bundle) { outState.putString("note", note); super.onSaveInstanceState(outState) }

    private fun render() {
        if (!foreground || isDestroyed) return
        if (retainedPersonal != null && runtime.ready && !runtime.busy && runtime.personal.available) {
            val retained = retainedPersonal; retainedPersonal = null
            openPersonal(retained)
            if (runtime.personal.isOpen) return
        }
        if (runtime.personal.isOpen) return
        val position = scroll?.scrollY ?: 0
        val ticket = gate.nextRender()
        runtime.provider.pin().use { view ->
            val dark = view.configuration.colorMode == ColorMode.DARK
            val canvas = view.getColor(theme.background).toArgb()
            val surface = view.getColor(theme.surface).toArgb()
            val ink = view.getColor(theme.text).toArgb()
            val accent = accents.choice(runtime.personal.accentIdentity(view.snapshot)) ?: runtime.personal.accent(view.snapshot)
            val palette = AccentPalette.from(accent?.seedArgb ?: view.getColor(theme.accent).toArgb(), dark, canvas, surface)
            val surfaces = ShowcaseSurfaces(view, theme, runtime, resources.displayMetrics.density) { gate.accepts(ticket) }
            fun text(value: String, size: Float = 16f, color: Int = ink) = TextView(this).apply {
                text = value; textSize = size; setTextColor(color)
            }
            fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            fun add(parent: LinearLayout, child: View, gap: Int = 12) {
                parent.addView(child, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(gap) })
            }
            fun solidCard() = column().apply {
                setPadding(dp(16), dp(16), dp(16), dp(16))
                background = GradientDrawable().apply { setColor(surface); cornerRadius = dp(18).toFloat() }
            }
            fun button(label: String, enabled: Boolean = true, reserveArtRow: Boolean = false, click: () -> Unit): Button =
                ShowcaseButton(surfaces, palette, reserveArtRow).apply { text = label; isEnabled = enabled; setOnClickListener { click() } }
            val root = AppearanceWindowLayout(this, canvas).apply {
                background = surfaces.drawable(SurfaceRole.WINDOW, canvas)
                setPadding(dp(16), dp(16), dp(16), dp(16))
                setOnApplyWindowInsetsListener { target, insets ->
                    if (Build.VERSION.SDK_INT >= 30) {
                        val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout() or WindowInsets.Type.ime())
                        val protected = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                        setProtectedInsets(protected.left, protected.top, protected.right, protected.bottom)
                        target.setPadding(dp(16) + bars.left, dp(16) + bars.top, dp(16) + bars.right, dp(16) + bars.bottom)
                    } else {
                        @Suppress("DEPRECATION")
                        setProtectedInsets(insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                            insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
                        @Suppress("DEPRECATION")
                        target.setPadding(dp(16) + insets.systemWindowInsetLeft, dp(16) + insets.systemWindowInsetTop,
                            dp(16) + insets.systemWindowInsetRight, dp(16) + insets.systemWindowInsetBottom)
                    }
                    insets
                }
            }
            val content = column()
            val scroller = ScrollView(this).apply { isFillViewport = true; addView(content) }
            root.addView(scroller, LinearLayout.LayoutParams(-1, -1))
            val intro = solidCard()
            add(intro, text("ONE THEME, ANOTHER APP", 12f, palette.accentOnSurface))
            add(intro, text("Your little corner", 28f))
            add(intro, text("Pocket List · shared SkinKit appearance\nThis showcase has its own selection. Your list stays untouched.", 14f))
            add(intro, text("${view.snapshot.themeId} · ${view.snapshot.themeVersion ?: "app default"}\n${runtime.status}", 13f), 0)
            add(content, intro)
            // This hero has no text over its image. All copy is on solid readable surfaces.
            if (surfaces.hasArt(SurfaceRole.WINDOW)) content.addView(View(this).apply {
                background = surfaces.drawable(SurfaceRole.WINDOW, canvas, 18f)
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }, LinearLayout.LayoutParams(-1, dp(180)).apply { bottomMargin = dp(12) })
            val card = column().apply {
                background = surfaces.drawable(SurfaceRole.CARD, surface, 18f)
                setPadding(dp(16), dp(SurfaceLayoutPolicy.cardTopPadding(surfaces.value(SurfaceRole.CARD))), dp(16), dp(16))
            }
            add(card, text("A quieter kind of to-do", 22f))
            add(card, text("Cards, fields, buttons and the whole window read the same four Common appearance tokens.", 14f))
            val field = EditText(this).apply {
                id = View.generateViewId(); hint = "A small plan"; setText(note); setTextColor(ink); setHintTextColor(palette.accentOnSurface)
                setTextSize(16f); minHeight = dp(56); setSingleLine(false); maxLines = 4
                backgroundTintList = null
                background = StateListDrawable().apply {
                    addState(intArrayOf(android.R.attr.state_focused),
                        surfaces.drawable(SurfaceRole.FORM, surface, 12f, palette.accentOnSurface, 3f))
                    addState(intArrayOf(), surfaces.drawable(SurfaceRole.FORM, surface, 12f, ink, 1f))
                }
                setPaddingRelative(dp(14), dp(14), dp(SurfaceLayoutPolicy.formEndPadding(surfaces.value(SurfaceRole.FORM), 14)), dp(14))
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { note = s?.toString().orEmpty() }
                    override fun afterTextChanged(s: Editable?) = Unit
                })
            }
            add(card, text("Try an editable field", 14f).apply { labelFor = field.id }, 6)
            add(card, field)
            add(card, button("Keep this little plan", reserveArtRow = true) { Toast.makeText(this, "Demo text stays in this showcase.", Toast.LENGTH_SHORT).show() })
            add(card, button("Disabled button", false, true) {}, 0)
            add(content, card)
            val controls = solidCard()
            add(controls, text("Choose your theme", 22f))
            if (runtime.personal.available) add(controls, button("My themes / Create theme", runtime.ready && !runtime.busy) {
                openPersonal()
            })
            packs.forEach { pack ->
                val active = pack.themeId == view.snapshot.themeId
                val outdated = active && pack.version != view.snapshot.themeVersion
                val label = when {
                    outdated -> "Update ${pack.name}: ${view.snapshot.themeVersion} → ${pack.version}"
                    active -> "Reapply ${pack.name} · ${pack.version}"
                    else -> "${pack.name} · ${pack.version}"
                }
                if (outdated) add(controls, text("A newer bundled theme is available. Apply it explicitly; your saved accent stays selected.", 14f))
                add(controls, button(label, runtime.ready && !runtime.busy) { runtime.choose(pack.file) }, 8)
            }
            add(controls, button(if (dark) "Use light mode" else "Use dark mode", runtime.ready && !runtime.busy) {
                getSharedPreferences("appearance-showcase-ui", MODE_PRIVATE).edit().putBoolean("dark", !dark).apply()
                runtime.configuration(VisualConfiguration(if (dark) ColorMode.LIGHT else ColorMode.DARK, resources.configuration.fontScale.toDouble()))
            })
            add(controls, text("Accent · ${accent?.id ?: "theme default"}", 16f, palette.accentOnSurface))
            AccentChoice.entries.forEach { choice ->
                add(controls, button(choice.id.replaceFirstChar(Char::uppercaseChar)) { selectAccent(choice) }, 8)
            }
            add(controls, button("Use theme accent") { selectAccent(null) })
            add(controls, button("Restore app defaults", runtime.ready && !runtime.busy) {
                accents.select(null, null)
                runtime.restore()
            })
            add(controls, button("Back to Pocket List") { finish() }, 0)
            add(content, controls, 0)
            setContentView(root); scroll = scroller
            scroller.post { if (gate.accepts(ticket)) scroller.scrollTo(0, position) }
            root.requestApplyInsets()
            @Suppress("DEPRECATION")
            if (Build.VERSION.SDK_INT < 35) { window.statusBarColor = canvas; window.navigationBarColor = surface }
            if (Build.VERSION.SDK_INT >= 30) {
                val lightBars = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                window.insetsController?.setSystemBarsAppearance(if (dark) 0 else lightBars, lightBars)
            } else {
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = if (dark) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
        }
    }

    private fun openPersonal(restored: Any? = null) {
        runtime.personalSession?.let { session ->
            runtime.personal.open(this, session, runtime.provider.configuration,
                onSaved = { _ -> }, onClosed = { if (foreground && !isDestroyed) render() }, restoredState = restored)
            if (retainedPickerReply) {
                retainedPickerReply = false
                runtime.personal.result(6282, RESULT_CANCELED, null)
            }
        }
    }
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onRetainNonConfigurationInstance(): Any? = (runtime.personal.captureState() ?: retainedPersonal)?.let {
        RetainedPersonal(it, retainedPickerReply)
    }

    @android.annotation.SuppressLint("GestureBackNavigation")
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() { if (!runtime.personal.back()) finish() }
    @Deprecated("Platform result routing avoids an optional AndroidX dependency")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        if (requestCode == 6282 && !runtime.personal.isOpen && retainedPersonal != null) {
            retainedPickerReply = true
            return
        }
        if (runtime.personal.result(requestCode, resultCode, data)) return
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun selectAccent(value: AccentChoice?) {
        accents.select(runtime.personal.accentIdentity(runtime.provider.snapshot), value)
        render()
    }

    /** Native behavior and hit targets; the shared drawable receives label bounds BEFORE drawing. */
    private inner class ShowcaseButton(surfaces: ShowcaseSurfaces, palette: AccentPalette, reserveArtRow: Boolean) : Button(this@AppearanceShowcaseActivity) {
        private val art: List<ThemeSurfaceDrawable>
        init {
            val layout = SurfaceLayoutPolicy.button(surfaces.value(SurfaceRole.BUTTON), reserveArtRow, 56, 12)
            isAllCaps = false; textSize = 16f; gravity = Gravity.CENTER; minHeight = dp(layout.minimumHeightDp)
            minimumHeight = minHeight; setPadding(dp(18), dp(layout.topPaddingDp), dp(18), dp(layout.bottomPaddingDp))
            backgroundTintList = null
            val states = arrayOf(intArrayOf(-android.R.attr.state_enabled), intArrayOf(android.R.attr.state_pressed),
                intArrayOf(android.R.attr.state_focused), intArrayOf())
            val colors = listOf(palette.disabledBackground, palette.pressedBackground, palette.focusedBackground, palette.buttonBackground)
            art = colors.mapIndexed { index, color -> surfaces.drawable(SurfaceRole.BUTTON, color, 14f,
                if (index == 2) palette.focusedForeground else null, if (index == 2) 2f else 0f, if (index == 0) .4f else 1f) }
            background = StateListDrawable().apply { states.indices.forEach { addState(states[it], art[it]) } }
            setTextColor(ColorStateList(states, intArrayOf(palette.disabledForeground, palette.pressedForeground,
                palette.focusedForeground, palette.buttonForeground)))
        }
        override fun draw(canvas: Canvas) {
            val lines = layout
            val rectangle = if (lines == null || lines.lineCount == 0) null else {
                val left = (0 until lines.lineCount).minOf { lines.getLineLeft(it) }
                val right = (0 until lines.lineCount).maxOf { lines.getLineRight(it) }
                val top = extendedPaddingTop + ((height - extendedPaddingTop - extendedPaddingBottom - lines.height) / 2f).coerceAtLeast(0f)
                RectF(compoundPaddingLeft + left, top, compoundPaddingLeft + right, top + lines.height)
            }
            art.forEach { it.setProtectedTextRect(rectangle) }
            super.draw(canvas)
        }
    }
}
