package dev.skinkit.binaryhost.appearance

import dev.skinkit.appearance.AccentChoice

/** Host preferences are namespaced by theme, never a global tint carried into another package. */
internal class ShowcaseAccentSelection(
    private val read: (String) -> String?,
    private val write: (String, String?) -> Unit,
) {
    private fun key(themeId: String?) = "appearance.accent.${themeId ?: "default:${ShowcaseTheme.APP_ID}"}"
    fun choice(themeId: String?): AccentChoice? = AccentChoice.fromId(read(key(themeId)))
    fun select(themeId: String?, choice: AccentChoice?) = write(key(themeId), choice?.id)
}
