package dev.skinkit.binaryhost.appearance

import dev.skinkit.appearance.AppearanceTokens
import dev.skinkit.contract.*
import dev.skinkit.defaults.AppDefaultTheme

/** A second host's own minimal registry. No dependency on laboratory code or its registry. */
internal class ShowcaseTheme {
    companion object { const val APP_ID = "dev.skinkit.binaryhost" }
    private val builder = TokenRegistry.builder(APP_ID)
    val background = builder.color("color.background", ColorRole.BACKGROUND)
    val surface = builder.color("color.surface", ColorRole.BACKGROUND)
    val text = builder.color("color.text.primary")
    val accent = builder.color("color.primary", ColorRole.ACCENT)
    val appearance = AppearanceTokens(builder)
    val registry = builder.apply {
        contrastPair(text, background, 4.5)
        contrastPair(text, surface, 4.5)
    }.build()
    val descriptor = ExtensionDescriptor(APP_ID, "$APP_ID.appearance", Version(1, 0, 0),
        VersionRange(Version(0, 0, 1), Version(0, 1, 0)), registry, emptyList(),
        ResourceLimits(4 * 1024 * 1024L, 1024, 1024))
    val defaults: AppDefaultTheme = AppDefaultTheme.builder(APP_ID, "0.0.1").apply {
        for (mode in ColorMode.entries) {
            fun color(light: Long, dark: Long) = ColorValue.argb((if (mode == ColorMode.DARK) dark else light).toInt())
            val canvas = color(0xfff4f6fa, 0xff111827)
            val card = color(0xffffffff, 0xff1e293b)
            val ink = color(0xff172033, 0xfff1f5f9)
            val primary = color(0xff245bba, 0xffa7c7ff)
            put(mode, background, canvas); put(mode, surface, card)
            put(mode, text, ink); put(mode, accent, primary)
            put(mode, appearance.window, DrawableValue.Solid(canvas))
            put(mode, appearance.card, DrawableValue.Solid(card))
            put(mode, appearance.form, DrawableValue.Solid(card))
            put(mode, appearance.button, DrawableValue.Solid(primary))
        }
    }.build()
}
