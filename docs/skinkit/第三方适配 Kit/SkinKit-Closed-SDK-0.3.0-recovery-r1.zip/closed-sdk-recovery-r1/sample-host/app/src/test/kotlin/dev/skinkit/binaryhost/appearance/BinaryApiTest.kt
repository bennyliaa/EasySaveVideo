package dev.skinkit.binaryhost.appearance
import dev.skinkit.contract.*
import dev.skinkit.core.*
import dev.skinkit.personal.*
import dev.skinkit.creator.CreatorSchema
import dev.skinkit.appearance.SurfaceRole
import org.junit.Assert.*
import org.junit.Test
import java.nio.file.Files
import java.io.File
import java.util.concurrent.TimeUnit
class BinaryApiTest {
    @Test fun defaultsAndAllFiveBinaryPackages() {
        val theme=ShowcaseTheme()
        val root=Files.createTempDirectory("binary-host-test").toFile()
        val store=ShowcaseStorage.open(root,theme)
        CoreThemeSession(CoreThemeProvider(theme.defaults,theme.registry,extensionDescriptor=theme.descriptor),store).use { session ->
            session.start().get(10,TimeUnit.SECONDS)
            val assets=File("src/main/assets/themes").takeIf { it.isDirectory } ?: File("app/src/main/assets/themes")
            val packs=assets.listFiles()!!.filter { it.extension=="skinpack" }
            assertEquals(5,packs.size)
            packs.forEach { file ->
                val info=session.install({ file.inputStream() },PackageOrigin.EXPLICIT_LOCAL_DRAFT).get(10,TimeUnit.SECONDS)
                session.activate(info.archiveDigest).get(10,TimeUnit.SECONDS)
                ColorMode.entries.forEach { mode ->
                    session.updateConfiguration(VisualConfiguration(mode)).get(10,TimeUnit.SECONDS)
                    session.provider.pin().use { view ->
                        listOf(theme.appearance.button,theme.appearance.window,theme.appearance.card,theme.appearance.form).forEach {
                            assertEquals(FallbackLayer.COMMON,view.sourceOf(it)); assertNotNull(view.getDrawable(it))
                        }
                    }
                }
            }
            session.restoreDefault().get(10,TimeUnit.SECONDS)
            assertTrue(session.provider.getDrawable(theme.appearance.button) is DrawableValue.Solid)
        }
        store.drainCleanup().get(10,TimeUnit.SECONDS); root.deleteRecursively()
    }
    @Test fun optionalPersonalStoreRoundTripUsesBinaryApi() {
        val theme=ShowcaseTheme(); val schema=CreatorSchema(theme.registry,theme.descriptor)
        val c=ColorValue.argb(0xff245bba.toInt())
        val roles=PersonalRoleDirectory(schema,listOf(PersonalRole("button","Button",theme.appearance.button,SurfaceRole.BUTTON,c,c)))
        val root=Files.createTempDirectory("binary-personal")
        var id=""
        PersonalThemeStore(root,schema,roles).use { store -> id=store.saveDraft(store.newWorkingCopy("Binary host theme")).theme.id }
        PersonalThemeStore(root,schema,roles).use { store -> assertEquals(id,store.list().single().theme.id) }
        root.toFile().deleteRecursively()
    }
    @Test fun renderGatesRejectStaleCallbacks() {
        val gate=ShowcasePresentationGate(); gate.foreground(true); val first=gate.nextRender()
        assertTrue(gate.accepts(first)); gate.nextRender(); assertFalse(gate.accepts(first)); gate.close()
    }
}
