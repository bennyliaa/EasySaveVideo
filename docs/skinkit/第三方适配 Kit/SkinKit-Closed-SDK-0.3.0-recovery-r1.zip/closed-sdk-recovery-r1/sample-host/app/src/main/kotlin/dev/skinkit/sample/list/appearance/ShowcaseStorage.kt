package dev.skinkit.binaryhost.appearance

import dev.skinkit.contract.CapabilitySnapshot
import dev.skinkit.core.CoreAnimationServices
import dev.skinkit.core.PackageLimits
import dev.skinkit.core.SkinPackLoader
import dev.skinkit.core.ThemeStore
import java.io.File

internal object ShowcaseStorage {
    fun loader(theme: ShowcaseTheme) = SkinPackLoader(theme.registry, PackageLimits(),
        CapabilitySnapshot(CoreAnimationServices.staticCapabilities), theme.descriptor)

    // Android may alias the trusted filesDir through /data/user/0. Resolve only that parent;
    // Core must still reject a substituted symlink at appearance-showcase or inside its store.
    fun open(filesDirectory: File, theme: ShowcaseTheme) =
        ThemeStore(File(filesDirectory.canonicalFile, "appearance-showcase"), loader(theme))
}
