package dev.skinkit.binaryhost.appearance

import android.app.Activity
import android.content.Context
import android.content.Intent
import dev.skinkit.appearance.AccentChoice
import dev.skinkit.appearance.SurfaceRole
import dev.skinkit.contract.*
import dev.skinkit.core.CoreThemeSession
import dev.skinkit.creator.CreatorSchema
import dev.skinkit.personal.*
import dev.skinkit.personal.android.PersonalThemeLauncher
import java.io.File
import java.util.Locale

/** Second host supplies only its trusted directory and session; SDK page/importer are unchanged. */
internal class ShowcasePersonal(private val context: Context, private val theme: ShowcaseTheme) : AutoCloseable {
    @Volatile private var store: PersonalThemeStore? = null
    private var launcher: PersonalThemeLauncher? = null
    val available: Boolean get() = store != null
    val isOpen: Boolean get() = launcher?.isOpen == true
    fun start() {
        val schema = CreatorSchema(theme.registry, theme.descriptor)
        fun color(value: Long) = ColorValue.argb(value.toInt())
        val directory = PersonalRoleDirectory(schema, listOf(
            PersonalRole("button", "按钮", theme.appearance.button, SurfaceRole.BUTTON, color(0xff245bba), color(0xffa7c7ff)),
            PersonalRole("window", "窗口与页面", theme.appearance.window, SurfaceRole.WINDOW, color(0xfff4f6fa), color(0xff111827)),
            PersonalRole("form", "表单与输入框", theme.appearance.form, SurfaceRole.FORM, color(0xffffffff), color(0xff1e293b)),
            PersonalRole("card", "卡片", theme.appearance.card, SurfaceRole.CARD, color(0xffffffff), color(0xff1e293b))
        ))
        store = PersonalThemeStore(File(context.filesDir.canonicalFile, "showcase-personal").toPath(), schema, directory)
    }
    fun accentIdentity(snapshot: ThemeSnapshotInfo): String? = store?.profile(snapshot)?.let { "${it.themeId}:${it.version}" } ?: snapshot.themeId
    fun accent(snapshot: ThemeSnapshotInfo): AccentChoice? = store?.profile(snapshot)?.globalAccent
    fun focus(snapshot: ThemeSnapshotInfo, role: SurfaceRole): Pair<Float, Float> =
        store?.profile(snapshot)?.focus(role.name.lowercase(Locale.ROOT))?.let { it.x.toFloat() to it.y.toFloat() } ?: (.5f to .5f)
    fun presentation(snapshot: ThemeSnapshotInfo, role: SurfaceRole): Pair<Float, Boolean> =
        store?.profile(snapshot)?.presentation(role.name.lowercase(Locale.ROOT))
            ?.let { it.scale.toFloat() to (it.mode == PersonalImageMode.REPEAT) } ?: (1f to false)
    fun open(activity: Activity, session: CoreThemeSession, configuration: VisualConfiguration, onSaved: (String) -> Unit, onClosed: () -> Unit, restoredState: Any? = null) {
        val current = store ?: return
        val open = launcher ?: PersonalThemeLauncher(activity, current, session, 6282,
            onSaved = { saved, applied -> if (applied) onSaved(saved.theme.id) }, onClosed = onClosed).also { launcher = it }
        open.open(configuration, restoredState as? dev.skinkit.personal.android.PersonalThemeLauncherState)
    }
    fun captureState(): Any? = launcher?.captureState()
    fun result(requestCode: Int, resultCode: Int, data: Intent?): Boolean = launcher?.onActivityResult(requestCode, resultCode, data) ?: false
    fun back(): Boolean = launcher?.onBackPressed() ?: false
    fun setForeground(value: Boolean) { launcher?.setForeground(value) }
    fun closeAsync(): java.util.concurrent.CompletableFuture<Void> =
        (launcher?.closeAsync() ?: java.util.concurrent.CompletableFuture.completedFuture<Void>(null))
    fun closeStore() { store?.close() }
    override fun close() { closeAsync().thenRun { closeStore() } }
}
