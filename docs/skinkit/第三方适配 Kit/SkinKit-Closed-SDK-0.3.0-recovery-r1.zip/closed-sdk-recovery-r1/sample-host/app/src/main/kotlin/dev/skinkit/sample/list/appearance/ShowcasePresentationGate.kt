package dev.skinkit.binaryhost.appearance

/** UI-thread lifecycle gate: stale work may finish, but never paints a newer or stopped screen. */
internal class ShowcasePresentationGate {
    private var epoch = 0L
    private var foreground = false
    private var closed = false
    fun foreground(value: Boolean) { foreground = value; epoch++ }
    fun nextRender(): Long = ++epoch
    fun accepts(ticket: Long): Boolean = foreground && !closed && ticket == epoch
    fun close() { closed = true; foreground = false; epoch++ }
}
