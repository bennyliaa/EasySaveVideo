package dev.skinkit.binaryhost.appearance

import android.content.Context
import android.os.Handler
import android.os.Looper
import dev.skinkit.appearance.android.AppearanceImageLoader
import dev.skinkit.contract.*
import dev.skinkit.core.*
import java.util.concurrent.CompletableFuture
import java.util.concurrent.Executors

/** Separate session and store: it never opens Pocket List's theme store or task repository. */
internal class ShowcaseRuntime(context: Context, theme: ShowcaseTheme, configuration: VisualConfiguration,
    private val changed: () -> Unit) : AutoCloseable {
    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    companion object {
        private val lifecycle = Executors.newSingleThreadExecutor { Thread(it, "appearance-showcase-lifecycle").apply { isDaemon = true } }
    }
    val provider = CoreThemeProvider(theme.defaults, theme.registry, configuration, theme.descriptor)
    val images = AppearanceImageLoader()
    val personal = ShowcasePersonal(context, theme)
    val personalSession: CoreThemeSession? get() = session.takeIf { ready && !closed }
    @Volatile private var session: CoreThemeSession? = null
    @Volatile private var closed = false
    var ready = false; private set
    var busy = true; private set
    var status = "Opening the independent theme store…"; private set

    init {
        lifecycle.execute {
            try {
                if (closed) return@execute
                val current = CoreThemeSession(provider, ShowcaseStorage.open(app.filesDir, theme))
                session = current
                try { personal.start() } catch (_: Exception) { /* Optional creator failure must not disable built-in themes. */ }
                if (closed) { personal.close(); current.close(); return@execute }
                current.start().whenComplete { result, error -> main.post {
                    if (closed) return@post
                    busy = false
                    if (error == null) {
                        ready = true
                        status = if (result.recovered) "Saved theme recovered with safe defaults." else "Choose a shared theme package below."
                    } else failure(error)
                    changed()
                } }
            } catch (error: Exception) { main.post {
                if (!closed) { busy = false; failure(error); changed() }
            } }
        }
    }

    fun choose(asset: String) = perform("Validating and applying the shared package…", { current ->
        current.install({ app.assets.open("themes/$asset") }, PackageOrigin.EXPLICIT_LOCAL_DRAFT)
            .thenCompose { info -> current.activate(info.archiveDigest).thenApply { "${info.displayName} · ${info.version}: ${it.status}" } }
    })

    fun configuration(value: VisualConfiguration) = perform("Changing appearance mode…", { current ->
        current.updateConfiguration(value).thenApply { "Appearance mode: ${value.colorMode.name.lowercase()}" }
    })

    fun restore() = perform("Restoring the resource-free app defaults…", { current ->
        current.restoreDefault().thenApply { "App defaults restored: ${it.status}" }
    })

    private fun perform(message: String, action: (CoreThemeSession) -> CompletableFuture<String>) {
        val current = session ?: return
        if (closed || busy || !ready) return
        busy = true; status = message; changed()
        val future = try { action(current) } catch (error: Exception) {
            busy = false; failure(error); changed(); return
        }
        future.whenComplete { result, error -> main.post {
            if (closed) return@post
            busy = false
            if (error == null) status = result else failure(error)
            current.lastPersistenceWarning?.let { status += "\nTheme is usable, but saving its selection was not confirmed." }
            changed()
        } }
    }

    fun resourceFailure(generation: Long, token: DrawableToken, resource: LocalResourceRef) {
        if (closed) return
        session?.reportResourceFailure(generation, token, resource)?.whenComplete { replaced, error -> main.post {
            if (!closed && error == null && replaced == true) {
                status = "A decorative image could not be decoded. Its safe default is now in use."
                changed()
            }
        } }
    }

    private fun failure(error: Throwable) {
        val cause = generateSequence(error) { it.cause?.takeUnless { next -> next === it } }.last()
        status = "The current usable theme was kept. ${cause.javaClass.simpleName}: ${cause.message.orEmpty().take(160)}"
    }

    override fun close() {
        if (closed) return
        closed = true; images.close()
        // Let an explicitly requested editor commit settle before closing its borrowed owners.
        val drain = personal.closeAsync()
        lifecycle.execute {
            try { drain.handle { _, _ -> null }.join() } finally {
                try { personal.closeStore() } finally { session?.close() ?: provider.close() }
            }
        }
    }
}
