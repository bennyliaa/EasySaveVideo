package dev.skinkit.binaryhost.appearance

import android.os.Handler
import android.os.Looper
import dev.skinkit.appearance.SurfaceLayoutPolicy
import dev.skinkit.appearance.SurfaceRole
import dev.skinkit.appearance.android.AppearanceImageException
import dev.skinkit.appearance.android.AppearanceImageFailure
import dev.skinkit.appearance.android.ThemeSurfaceDrawable
import dev.skinkit.contract.ColorMode
import dev.skinkit.contract.DrawableValue
import dev.skinkit.core.CoreThemeReadView

/** Host binding only. The optional SkinKit adapter owns every image and surface algorithm. */
internal class ShowcaseSurfaces(view: CoreThemeReadView, theme: ShowcaseTheme,
    private val runtime: ShowcaseRuntime, private val density: Float, private val current: () -> Boolean) {
    private val main = Handler(Looper.getMainLooper())
    private val generation = view.snapshot.generation
    private val personalFocus = SurfaceRole.entries.associateWith { runtime.personal.focus(view.snapshot, it) }
    private val personalPresentation = SurfaceRole.entries.associateWith { runtime.personal.presentation(view.snapshot, it) }
    private val dark = view.configuration.colorMode == ColorMode.DARK
    private val tokens = mapOf(SurfaceRole.WINDOW to theme.appearance.window, SurfaceRole.BUTTON to theme.appearance.button,
        SurfaceRole.CARD to theme.appearance.card, SurfaceRole.FORM to theme.appearance.form)
    private val values = tokens.mapValues { view.getDrawable(it.value) }
    // load() retains resource ownership synchronously while this immutable read view is open.
    private val images = values.values.filterIsInstance<DrawableValue.Local>().map { it.resource }.distinct()
        .associateWith { runtime.images.load(view, it) }
    private val reported = mutableSetOf<SurfaceRole>()
    fun value(role: SurfaceRole): DrawableValue = values.getValue(role)
    fun hasArt(role: SurfaceRole) = SurfaceLayoutPolicy.hasArtwork(value(role))

    fun drawable(role: SurfaceRole, base: Int, corner: Float = 0f, stroke: Int? = null,
        strokeWidth: Float = 0f, artAlpha: Float = 1f): ThemeSurfaceDrawable {
        val value = values.getValue(role)
        return ThemeSurfaceDrawable(value, role, base, corner * density, density, dark, stroke, strokeWidth * density).also { drawable ->
            drawable.setArtAlpha(artAlpha)
            personalFocus.getValue(role).let { drawable.setCropFocus(it.first, it.second) }
            personalPresentation.getValue(role).let { drawable.setImagePresentation(it.first, it.second) }
            if (value is DrawableValue.Local) images.getValue(value.resource).whenComplete { bitmap, error -> main.post {
                if (!current() || runtime.provider.snapshot.generation != generation) return@post
                if (error == null) drawable.setBitmap(bitmap)
                else {
                    val failure = generateSequence(error) { it.cause?.takeUnless { next -> next === it } }
                        .filterIsInstance<AppearanceImageException>().firstOrNull()
                    if (failure?.reason in setOf(AppearanceImageFailure.RESOURCE_MISSING, AppearanceImageFailure.INVALID_IMAGE) && reported.add(role)) {
                        runtime.resourceFailure(generation, tokens.getValue(role), value.resource)
                    }
                }
            } }
        }
    }
}
