plugins { id("com.android.application") }
android {
    namespace = "dev.skinkit.binaryhost"
    compileSdk = 36
    defaultConfig { applicationId = "dev.skinkit.binaryhost"; minSdk = 26; targetSdk = 36; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    buildTypes { release { isMinifyEnabled = true; isShrinkResources = true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
    testOptions { unitTests.isReturnDefaultValues = true }
    lint { abortOnError = true; disable += "OldTargetApi" }
}
dependencyLocking { lockAllConfigurations(); lockFile.set(file(if (providers.gradleProperty("withAnimation").orNull == "true") "gradle-animation.lockfile" else "gradle.lockfile")) }
dependencies {
    implementation("dev.skinkit:skinkit-personal-android:0.1.0-dev.2")
    implementation("dev.skinkit:skinkit-appearance-android:0.1.0-dev.3")
    // Optional integration interfaces. They do not start any service or configure accounts.
    implementation("dev.skinkit:skinkit-store-core:0.1.0-dev.1")
    implementation("dev.skinkit:skinkit-commerce:0.1.0-dev.1")
    implementation("dev.skinkit:skinkit-community:0.1.0-dev.1")
    if (providers.gradleProperty("withAnimation").orNull == "true") implementation("dev.skinkit:skinkit-animation-android:0.1.0-dev.11")
    testImplementation("junit:junit:4.13.2")
}
tasks.register("runtimeInventory") {
    doLast {
        val config = configurations.getByName("releaseRuntimeClasspath")
        val rows = config.incoming.artifacts.artifacts.sortedBy { it.id.componentIdentifier.toString() }.map {
            "${it.id.componentIdentifier}\t${it.file.name}\t${it.file.absolutePath}"
        }
        layout.buildDirectory.file("runtime-inventory.tsv").get().asFile.apply { parentFile.mkdirs(); writeText(rows.joinToString("\n", postfix="\n")) }
    }
}
