# Direct API use only. No blanket keep rule or disabled R8 optimization.
