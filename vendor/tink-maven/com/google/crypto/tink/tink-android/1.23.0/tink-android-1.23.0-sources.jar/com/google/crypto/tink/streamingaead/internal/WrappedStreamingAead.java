// Copyright 2017 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
////////////////////////////////////////////////////////////////////////////////

package com.google.crypto.tink.streamingaead.internal;

import com.google.crypto.tink.KeyStatus;
import com.google.crypto.tink.KeysetHandleInterface;
import com.google.crypto.tink.StreamingAead;
import com.google.crypto.tink.internal.PrimitiveWrapper.PrimitiveFactory;
import com.google.crypto.tink.internal.Util;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;

/**
 * StreamingAeadWrapper is the implementation of PrimitiveWrapper for the StreamingAead primitive.
 *
 * <p>The returned primitive works with a keyset (rather than a single key). To encrypt a plaintext,
 * it uses the primary key in the keyset. To decrypt, the primitive tries the enabled keys from the
 * keyset to select the right key for decryption. All keys in a keyset of StreamingAead have type
 * {@link com.google.crypto.tink.proto.OutputPrefixType#RAW}.
 */
public class WrappedStreamingAead {

  WrappedStreamingAead() {}

  public static StreamingAead wrap(
      KeysetHandleInterface handle, PrimitiveFactory<StreamingAead> factory)
      throws GeneralSecurityException {
    if (!Util.hasEnabledPrimaryKey(handle)) {
      throw new GeneralSecurityException("keyset doesn't contain a valid primary key");
    }
    List<StreamingAead> allStreamingAeads = new ArrayList<>();
    for (int i = 0; i < handle.size(); i++) {
      KeysetHandleInterface.Entry entry = handle.getAt(i);
      if (entry.getStatus().equals(KeyStatus.ENABLED)) {
        StreamingAead streamingAead = factory.create(entry);
        allStreamingAeads.add(streamingAead);
      }
    }
    KeysetHandleInterface.Entry primaryEntry = handle.getPrimary();
    if (primaryEntry == null) {
      throw new GeneralSecurityException("No primary set");
    }
    StreamingAead primaryStreamingAead = factory.create(primaryEntry);
    if (primaryStreamingAead == null) {
      throw new GeneralSecurityException("No primary set");
    }

    return new StreamingAeadHelper(allStreamingAeads, primaryStreamingAead);
  }
}
