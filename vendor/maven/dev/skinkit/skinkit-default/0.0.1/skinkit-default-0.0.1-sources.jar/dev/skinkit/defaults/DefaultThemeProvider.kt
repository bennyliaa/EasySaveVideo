package dev.skinkit.defaults

import dev.skinkit.contract.*
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.pow

/**
 * Permanent offline executor. Construction/config changes prepare values; getters only read memory.
 * Host factories must be deterministic, immutable, IO-free, and must not call back into this provider.
 * Use pin for a render spanning multiple getters. Closing a pin is idempotent; use-after-close is a host error.
 */
class DefaultThemeProvider @JvmOverloads constructor(
    val defaultTheme: AppDefaultTheme,
    val tokenRegistry: TokenRegistry,
    configuration: VisualConfiguration = VisualConfiguration()
) : ThemeProvider, PinnedThemeSource {
    private val lock = Any()
    private val failedResources = LinkedHashSet<LocalResourceRef>()
    private val observers = LinkedHashSet<ObserverSubscription>()
    @Volatile private var current: Prepared
    @Volatile var completenessReport: ValidationReport
        private set
    val diagnostics: List<Diagnostic> get() = completenessReport.diagnostics
    override val snapshot: ThemeSnapshotInfo get() = current.snapshot
    val configuration: VisualConfiguration get() = current.configuration

    init {
        require(defaultTheme.appId == tokenRegistry.appId) { "Default theme appId does not match registry" }
        defaultTheme.data.values.forEach { values -> values.keys.forEach(tokenRegistry::requireOwned) }
        val prepared = ColorMode.entries.associateWith { prepare(configuration.copy(colorMode = it), 0) }
        current = prepared.getValue(configuration.colorMode)
        completenessReport = ValidationReport(prepared.values.flatMap { it.diagnostics })
    }

    override fun pin(): ThemeReadView = View(current, tokenRegistry)
    override fun getColor(token: ColorToken): ColorValue = current.read(token, ColorValue::class.java, tokenRegistry)
    override fun getTypography(token: TypographyToken): TypographyValue = current.read(token, TypographyValue::class.java, tokenRegistry)
    override fun getDimension(token: DimensionToken): DimensionValue = current.read(token, DimensionValue::class.java, tokenRegistry)
    override fun getDrawable(token: DrawableToken): DrawableValue = current.read(token, DrawableValue::class.java, tokenRegistry)
    override fun getIcon(token: IconToken): IconValue = current.read(token, IconValue::class.java, tokenRegistry)
    override fun getAnimation(token: AnimationToken): AnimationValue = current.read(token, AnimationValue::class.java, tokenRegistry)
    override fun <S : ComponentStyle> getComponentStyle(token: ComponentToken<S>): S = current.read(token, token.schema.styleClass, tokenRegistry)

    /** Atomic publication; old read views retain old values and configuration. No publication on a no-op. */
    fun updateConfiguration(configuration: VisualConfiguration): ThemeSnapshotInfo {
        val published: Prepared
        val targets: List<ObserverSubscription>
        synchronized(lock) {
            if (current.configuration == configuration) return current.snapshot
            val prepared = ColorMode.entries.associateWith { prepare(configuration.copy(colorMode = it), current.snapshot.generation + 1) }
            published = prepared.getValue(configuration.colorMode)
            current = published
            completenessReport = ValidationReport(prepared.values.flatMap { it.diagnostics })
            targets = observers.toList()
        }
        targets.forEach { it.offer(published.snapshot) }
        return published.snapshot
    }

    /**
     * The adapter calls this on its coordinator after local decoding fails. Only a currently selected,
     * matching resource can invalidate a candidate. Stale failures are ignored; old pins stay valid.
     * This in-memory operation publishes a new default generation and performs no resource IO.
     */
    fun reportResourceFailure(expectedGeneration: Long, token: ThemeToken, resource: LocalResourceRef): Boolean {
        tokenRegistry.requireOwned(token)
        val published: Prepared
        val targets: List<ObserverSubscription>
        synchronized(lock) {
            if (current.snapshot.generation != expectedGeneration || resource !in resourcesOf(current.values[token]) || resource in failedResources) return false
            failedResources += resource
            val prepared = ColorMode.entries.associateWith { prepare(current.configuration.copy(colorMode = it), current.snapshot.generation + 1) }
            published = prepared.getValue(current.configuration.colorMode)
            current = published
            completenessReport = ValidationReport(prepared.values.flatMap { it.diagnostics })
            targets = observers.toList()
        }
        targets.forEach { it.offer(published.snapshot) }
        return true
    }

    override fun observeSnapshot(observer: SnapshotObserver): Subscription {
        val subscriber = ObserverSubscription(observer) { subscription -> synchronized(lock) { observers.remove(subscription) } }
        val replay: ThemeSnapshotInfo
        synchronized(lock) { observers += subscriber; replay = current.snapshot }
        subscriber.offer(replay)
        return subscriber
    }

    private fun prepare(config: VisualConfiguration, generation: Long): Prepared {
        val values = LinkedHashMap<ThemeToken, Any>()
        val diagnostics = ArrayList<Diagnostic>()
        val defaults = defaultTheme.data[config.colorMode].orEmpty()
        tokenRegistry.tokens.forEach { token ->
            val appValue = defaults[token]
            var usable = appValue != null
            if (appValue == null) diagnostics += Diagnostic(DiagnosticCode.DEFAULT_MISSING, token.id, config, "No AppDefault value for ${config.colorMode}", token.required)
            if (token is DimensionToken && appValue is DimensionValue && token.purpose != appValue.purpose) {
                usable = false
                diagnostics += Diagnostic(DiagnosticCode.INVALID_VALUE, token.id, config, "Dimension purpose must be ${token.purpose}", token.required)
            }
            if (token is ComponentToken<*>) {
                values[token] = prepareComponent(token, appValue, config, diagnostics)
                return@forEach
            }
            val unavailable = resourcesOf(appValue).filter { it !in defaultTheme.resources.resources || it in failedResources }
            if (unavailable.isNotEmpty()) {
                usable = false
                diagnostics += Diagnostic(DiagnosticCode.RESOURCE_UNAVAILABLE, token.id, config, "Local resource unavailable; using a prepared safe value", token.required)
            }
            // Safe factories are validated once during preparation, even when the App default is complete.
            val safe = safeValue(token, config)
            var resolved = if (usable) requireNotNull(appValue) else safe
            if (!usable) diagnostics += Diagnostic(DiagnosticCode.SAFE_FALLBACK_USED, token.id, config, "Required App defaults must not rely on the fourth fallback layer", token.required)
            if (resolved is AnimationValue.Declarative) {
                resolved = resolved.fallback
                diagnostics += Diagnostic(DiagnosticCode.ANIMATION_UNSUPPORTED, token.id, config, "Default has no animation runtime; using the supplied static fallback", false)
            }
            if (config.reducedMotion && resolved is AnimationValue.Declarative) resolved = resolved.fallback
            values[token] = resolved
        }
        // A token may participate in several contrast constraints. Repair the complete
        // connected group together, so fixing a later pair cannot invalidate an earlier one.
        // The registry's role constraint makes the graph bipartite (foreground/background).
        val rejectedColors = LinkedHashSet<ColorToken>()
        tokenRegistry.contrastPairs.forEach { pair ->
            val foreground = ColorValue::class.java.cast(values.getValue(pair.foreground))
            val background = ColorValue::class.java.cast(values.getValue(pair.background))
            val states = foreground.variants.keys + background.variants.keys + VisualState.NORMAL
            if (states.any { contrast(foreground.forState(it).rgba, background.forState(it).rgba) < pair.minimumRatio }) {
                rejectedColors += pair.foreground
                rejectedColors += pair.background
            }
        }
        var expanded: Boolean
        do {
            val previousSize = rejectedColors.size
            tokenRegistry.contrastPairs.forEach { pair ->
                if (pair.foreground in rejectedColors || pair.background in rejectedColors) {
                    rejectedColors += pair.foreground
                    rejectedColors += pair.background
                }
            }
            expanded = rejectedColors.size != previousSize
        } while (expanded)
        rejectedColors.forEach { token ->
            val light = if (token.role == ColorRole.BACKGROUND) 0xffffffff.toInt() else 0xff000000.toInt()
            val dark = if (token.role == ColorRole.BACKGROUND) 0xff000000.toInt() else 0xffffffff.toInt()
            values[token] = ColorValue.argb(if (config.colorMode == ColorMode.DARK) dark else light)
            diagnostics += Diagnostic(DiagnosticCode.CONTRAST_REJECTED, token.id, config, "Declared contrast group contains an unsafe pair", token.required)
            diagnostics += Diagnostic(DiagnosticCode.SAFE_FALLBACK_USED, token.id, config, "Rebuilt the connected foreground/background safety group together", token.required)
        }
        return Prepared(ThemeSnapshotInfo(generation, "default:${defaultTheme.appId}", defaultTheme.version, SkinKitContract.VERSION), config, immutableMap(values), immutableList(diagnostics))
    }

    private fun safeValue(token: ThemeToken, config: VisualConfiguration): Any = when (token) {
        is ColorToken -> if (token.role == ColorRole.BACKGROUND) SkinKitSafeDefaults.background(config) else SkinKitSafeDefaults.color(config)
        is TypographyToken -> SkinKitSafeDefaults.typography()
        is DimensionToken -> SkinKitSafeDefaults.dimension(token.purpose)
        is DrawableToken -> SkinKitSafeDefaults.drawable(config)
        is IconToken -> SkinKitSafeDefaults.icon(config)
        is AnimationToken -> SkinKitSafeDefaults.animation()
        is ComponentToken<*> -> safeComponent(token, config)
    }
    private fun <S : ComponentStyle> safeComponent(token: ComponentToken<S>, config: VisualConfiguration): S {
        val safe = try { token.schema.freeze(token.schema.safeFactory.create(config)) } catch (failure: Exception) { throw HostContractException("Safe factory for ${token.id} failed: ${failure.javaClass.simpleName}") }
        val failures = token.schema.validate(safe)
        if (failures.isNotEmpty() || resourcesOf(safe).isNotEmpty()) throw HostContractException("Safe factory for ${token.id} must supply complete in-memory values: ${failures.joinToString()}")
        return safe
    }
    /** Resolve the Default -> Safe chain independently for every declared field and state. */
    private fun <S : ComponentStyle> prepareComponent(token: ComponentToken<S>, value: Any?, config: VisualConfiguration, diagnostics: MutableList<Diagnostic>): S {
        val safe = safeComponent(token, config)
        if (value == null) {
            diagnostics += Diagnostic(DiagnosticCode.SAFE_FALLBACK_USED, token.id, config, "Required App defaults must not rely on the fourth fallback layer", token.required)
            return token.schema.create(repairComponentContrast(token, safe.fields, config, diagnostics))
        }
        val app = token.schema.styleClass.cast(value)
        val failures = token.schema.validate(app)
        failures.forEach { diagnostics += Diagnostic(DiagnosticCode.COMPONENT_INCOMPLETE, token.id, config, it, token.required, it.substringBefore(':')) }
        // Schema validation uses canonical "state.field:reason" locations. Unknown fields and
        // undeclared states are diagnosed above, then omitted rather than erasing valid entries.
        val invalidLocations = failures.map { it.substringBefore(':') }.toSet()
        val resolved = StyleValues.builder()
        token.schema.fields.forEach { field ->
            val states = if (field.shared) setOf(VisualState.NORMAL) else token.schema.states.requiredStates
            states.forEach { state ->
                prepareComponentField(token, field, state, app.fields, safe.fields, invalidLocations, config, diagnostics, resolved)
            }
        }
        return token.schema.create(repairComponentContrast(token, resolved.build(), config, diagnostics))
    }

    /** Standard text/background fields form a 4.5:1 safety pair in each declared state. */
    private fun repairComponentContrast(token: ComponentToken<*>, fields: StyleValues, config: VisualConfiguration, diagnostics: MutableList<Diagnostic>): StyleValues {
        if (StandardFields.BACKGROUND !in token.schema.fields || StandardFields.FOREGROUND !in token.schema.fields) return fields
        val unsafeStates = token.schema.states.requiredStates.filter { state ->
            val foreground = fields.get(StandardFields.FOREGROUND, state)
            val background = fields.get(StandardFields.BACKGROUND, state)
            val colorStates = foreground.variants.keys + background.variants.keys + VisualState.NORMAL
            colorStates.any { contrast(foreground.forState(it).rgba, background.forState(it).rgba) < 4.5 }
        }.toSet()
        if (unsafeStates.isEmpty()) return fields
        val repaired = StyleValues.builder()
        fields.fields.forEach { field ->
            fields.states(field).forEach { state -> copyComponentField(fields, field, state, unsafeStates, config, repaired) }
        }
        unsafeStates.forEach { state ->
            listOf(StandardFields.BACKGROUND, StandardFields.FOREGROUND).forEach { field ->
                val location = "${state.name.lowercase()}.${field.id}"
                diagnostics += Diagnostic(DiagnosticCode.CONTRAST_REJECTED, token.id, config, "Standard component foreground/background must meet 4.5:1", token.required, location)
                diagnostics += Diagnostic(DiagnosticCode.SAFE_FALLBACK_USED, token.id, config, "Rebuilt this component state's foreground/background safety pair together", token.required, location)
            }
        }
        return repaired.build()
    }

    private fun <V : Any> copyComponentField(fields: StyleValues, field: StyleField<V>, state: VisualState, unsafeStates: Set<VisualState>, config: VisualConfiguration, repaired: StyleValues.Builder) {
        val selected = if (state in unsafeStates && (field === StandardFields.BACKGROUND || field === StandardFields.FOREGROUND)) {
            val white = (field === StandardFields.BACKGROUND) == (config.colorMode == ColorMode.LIGHT)
            field.type.valueClass.cast(ColorValue.argb(if (white) 0xffffffff.toInt() else 0xff000000.toInt()))
        } else fields.get(field, state)
        repaired.put(field, state, selected)
    }

    private fun <V : Any> prepareComponentField(token: ComponentToken<*>, field: StyleField<V>, state: VisualState, app: StyleValues, safe: StyleValues, invalidLocations: Set<String>, config: VisualConfiguration, diagnostics: MutableList<Diagnostic>, resolved: StyleValues.Builder) {
        val location = "${state.name.lowercase()}.${field.id}"
        val appPatch = app.patch(field, state)
        if (appPatch !is Patch.Value && !field.required) return
        val appValue: V? = if (appPatch is Patch.Value) appPatch.value else null
        val unavailable = resourcesOf(appValue).any { it !in defaultTheme.resources.resources || it in failedResources }
        if (unavailable) diagnostics += Diagnostic(DiagnosticCode.RESOURCE_UNAVAILABLE, token.id, config, "Local component resource unavailable; resolving this field through Safe", token.required, location)
        var selected: V
        if (appValue != null && location !in invalidLocations && !unavailable) {
            selected = appValue
        } else {
            val safePatch = safe.patch(field, state)
            if (safePatch !is Patch.Value) return // A missing optional field is legal; safeComponent checked every required field.
            selected = safePatch.value
            diagnostics += Diagnostic(DiagnosticCode.SAFE_FALLBACK_USED, token.id, config, "Resolved component field through the fourth fallback layer", token.required && field.required, location)
        }
        if (selected is AnimationValue.Declarative) {
            selected = field.type.valueClass.cast(selected.fallback)
            diagnostics += Diagnostic(DiagnosticCode.ANIMATION_UNSUPPORTED, token.id, config, "Default has no animation runtime; using the supplied static fallback", false, location)
        }
        resolved.put(field, state, selected)
    }

    private class View(private val prepared: Prepared, private val registry: TokenRegistry) : ThemeReadView {
        private val released = AtomicBoolean(false)
        private fun checkOpen() { check(!released.get()) { "ThemeReadView has been released; pin again for a new render" } }
        override val snapshot: ThemeSnapshotInfo get() { checkOpen(); return prepared.snapshot }
        override val configuration: VisualConfiguration get() { checkOpen(); return prepared.configuration }
        override fun getColor(token: ColorToken): ColorValue { checkOpen(); return prepared.read(token, ColorValue::class.java, registry) }
        override fun getTypography(token: TypographyToken): TypographyValue { checkOpen(); return prepared.read(token, TypographyValue::class.java, registry) }
        override fun getDimension(token: DimensionToken): DimensionValue { checkOpen(); return prepared.read(token, DimensionValue::class.java, registry) }
        override fun getDrawable(token: DrawableToken): DrawableValue { checkOpen(); return prepared.read(token, DrawableValue::class.java, registry) }
        override fun getIcon(token: IconToken): IconValue { checkOpen(); return prepared.read(token, IconValue::class.java, registry) }
        override fun getAnimation(token: AnimationToken): AnimationValue { checkOpen(); return prepared.read(token, AnimationValue::class.java, registry) }
        override fun <S : ComponentStyle> getComponentStyle(token: ComponentToken<S>): S { checkOpen(); return prepared.read(token, token.schema.styleClass, registry) }
        override fun release() { released.set(true) }
    }
    private data class Prepared(val snapshot: ThemeSnapshotInfo, val configuration: VisualConfiguration, val values: Map<ThemeToken, Any>, val diagnostics: List<Diagnostic>) {
        fun <T : Any> read(token: ThemeToken, type: Class<T>, registry: TokenRegistry): T { registry.requireOwned(token); return type.cast(values.getValue(token)) }
    }

    /** Serialized, monotonic, reentrant-safe callbacks without executing user code under internal locks. */
    private class ObserverSubscription(private val observer: SnapshotObserver, private val onClose: (ObserverSubscription) -> Unit) : Subscription {
        private val gate = Any()
        private var closed = false
        private var draining = false
        private var delivered = -1L
        private var pending: ThemeSnapshotInfo? = null
        fun offer(snapshot: ThemeSnapshotInfo) {
            synchronized(gate) {
                if (closed || snapshot.generation <= delivered || snapshot.generation <= (pending?.generation ?: -1)) return
                pending = snapshot
                if (draining) return
                draining = true
            }
            while (true) {
                val next = synchronized(gate) {
                    if (closed || pending == null) { draining = false; return }
                    requireNotNull(pending).also { pending = null; delivered = it.generation }
                }
                try { observer.onSnapshot(next) } catch (_: Exception) { /* Observers cannot interrupt default rendering/publication. */ }
            }
        }
        override fun close() { synchronized(gate) { if (closed) return; closed = true; pending = null }; onClose(this) }
    }
}

/** Explicit build/startup check across caller-selected light/dark, font-scale and motion configurations. */
object DefaultThemeValidator {
    @JvmStatic @JvmOverloads fun validate(theme: AppDefaultTheme, registry: TokenRegistry, configurations: List<VisualConfiguration> = listOf(VisualConfiguration(ColorMode.LIGHT), VisualConfiguration(ColorMode.DARK), VisualConfiguration(ColorMode.LIGHT, 2.0), VisualConfiguration(ColorMode.DARK, 2.0))): ValidationReport {
        require(configurations.isNotEmpty()) { "Validation needs at least one configuration" }
        val diagnostics = configurations.flatMap { DefaultThemeProvider(theme, registry, it).completenessReport.diagnostics }.distinct()
        return ValidationReport(diagnostics)
    }
}

private fun resourcesOf(value: Any?): Set<LocalResourceRef> = when (value) {
    is DrawableValue.Local -> setOf(value.resource)
    is IconValue -> when (val source = value.source) { is LocalIcon -> setOf(source.resource); else -> emptySet() }
    is TypographyValue -> when (val font = value.font) { is FontRef.Local -> setOf(font.resource); else -> emptySet() }
    is AnimationValue.Static -> resourcesOf(value.drawable)
    is AnimationValue.Declarative -> setOf(value.resource) + resourcesOf(value.fallback)
    is ComponentStyle -> value.fields.fields.flatMap { field -> value.fields.states(field).flatMap { state -> resourcesOfField(value.fields, field, state) } }.toSet()
    else -> emptySet()
}
private fun <V : Any> resourcesOfField(values: StyleValues, field: StyleField<V>, state: VisualState): Set<LocalResourceRef> = when (val result = values.patch(field, state)) { is Patch.Value -> resourcesOf(result.value); else -> emptySet() }

private fun contrast(foreground: Rgba, background: Rgba): Double {
    if (background.alpha != 1.0) return 0.0 // No canvas was declared; do not claim an unknown composite is safe.
    fun channel(value: Double): Double = if (value <= 0.04045) value / 12.92 else ((value + 0.055) / 1.055).pow(2.4)
    fun luminance(color: Rgba): Double = 0.2126 * channel(color.red) + 0.7152 * channel(color.green) + 0.0722 * channel(color.blue)
    val fg = Rgba(foreground.red * foreground.alpha + background.red * (1 - foreground.alpha), foreground.green * foreground.alpha + background.green * (1 - foreground.alpha), foreground.blue * foreground.alpha + background.blue * (1 - foreground.alpha))
    val a = luminance(fg); val b = luminance(background)
    return (maxOf(a, b) + 0.05) / (minOf(a, b) + 0.05)
}
