package dev.skinkit.defaults

import dev.skinkit.contract.*

/** Permanent in-memory fourth-level safety net. These are not app design defaults. */
object SkinKitSafeDefaults {
    @JvmStatic fun color(config: VisualConfiguration): ColorValue = ColorValue.argb(if (config.colorMode == ColorMode.DARK) 0xffeeeeee.toInt() else 0xff202020.toInt())
    @JvmStatic fun background(config: VisualConfiguration): ColorValue = ColorValue.argb(if (config.colorMode == ColorMode.DARK) 0xff202020.toInt() else 0xffeeeeee.toInt())
    @JvmStatic fun typography(): TypographyValue = TypographyValue(FontRef.System(), 16.0, 400, 24.0)
    @JvmStatic @JvmOverloads fun dimension(purpose: DimensionPurpose = DimensionPurpose.SPACING): DimensionValue {
        val text = purpose == DimensionPurpose.TEXT || purpose == DimensionPurpose.LINE_HEIGHT
        val amount = when (purpose) { DimensionPurpose.TEXT -> 16.0; DimensionPurpose.LINE_HEIGHT, DimensionPurpose.ICON -> 24.0; DimensionPurpose.BORDER -> 1.0; else -> 4.0 }
        return DimensionValue(amount, if (text) LogicalUnit.SCALED_TEXT else LogicalUnit.LENGTH, purpose)
    }
    @JvmStatic fun drawable(config: VisualConfiguration): DrawableValue = DrawableValue.Solid(background(config))
    @JvmStatic fun icon(config: VisualConfiguration): IconValue = IconValue(BuiltInIcon.WARNING, DimensionValue(24.0, LogicalUnit.LENGTH, DimensionPurpose.ICON), TintPolicy.Color(color(config)))
    @JvmStatic fun animation(): AnimationValue = AnimationValue.Disabled
}

/** Shared schema definitions bind Contract's fixed typed fields to Default-owned safe factories. */
object StandardSchemas {
    @JvmField val BUTTON: ComponentSchema<ButtonStyle> = ComponentSchema.button(SafeStyleFactory { config ->
        val visual = ButtonVisual(SkinKitSafeDefaults.color(config), SkinKitSafeDefaults.background(config), SkinKitSafeDefaults.typography())
        ButtonStyle.of(StateDomain.BUTTON.requiredStates.associateWith { visual }, DimensionValue(4.0, LogicalUnit.LENGTH, DimensionPurpose.CORNER))
    })
    @JvmField val CARD: ComponentSchema<CardStyle> = ComponentSchema.card(SafeStyleFactory { config ->
        CardStyle.of(SkinKitSafeDefaults.background(config), SkinKitSafeDefaults.color(config), DimensionValue(4.0, LogicalUnit.LENGTH, DimensionPurpose.CORNER))
    })
}
