package dev.skinkit.defaults

import dev.skinkit.contract.*
import java.util.Collections

internal fun <K, V> immutableMap(source: Map<K, V>): Map<K, V> = Collections.unmodifiableMap(LinkedHashMap(source))
internal fun <T> immutableList(source: Collection<T>): List<T> = Collections.unmodifiableList(ArrayList(source))

/** Inventory attested by the host at startup/build time. It never performs resource IO. */
class LocalResourceCatalog(resources: Set<LocalResourceRef>) {
    val resources: Set<LocalResourceRef> = Collections.unmodifiableSet(LinkedHashSet(resources))
    fun contains(resource: LocalResourceRef): Boolean = resource in resources
    companion object { @JvmField val EMPTY = LocalResourceCatalog(emptySet()) }
}

/** App-owned immutable default visual data; always retained even when a future Core is installed. */
class AppDefaultTheme private constructor(val appId: String, val version: String, data: Map<ColorMode, Map<ThemeToken, Any>>, val resources: LocalResourceCatalog) {
    internal val data = immutableMap(data.mapValues { immutableMap(it.value) })
    class Builder internal constructor(private val appId: String, private val version: String) {
        private val data = LinkedHashMap<ColorMode, MutableMap<ThemeToken, Any>>()
        private var resources = LocalResourceCatalog.EMPTY
        init { require(appId.matches(Regex("[a-z][a-z0-9]*(\\.[a-z][a-z0-9]*)*"))); Version.parse(version) }
        private fun putValue(mode: ColorMode, token: ThemeToken, value: Any): Builder = apply {
            val values = data.getOrPut(mode) { LinkedHashMap() }
            require(!values.containsKey(token)) { "Duplicate default for ${token.id} at $mode" }
            values[token] = value
        }
        fun put(mode: ColorMode, token: ColorToken, value: ColorValue): Builder = putValue(mode, token, value)
        fun put(mode: ColorMode, token: TypographyToken, value: TypographyValue): Builder = putValue(mode, token, value)
        fun put(mode: ColorMode, token: DimensionToken, value: DimensionValue): Builder = putValue(mode, token, value)
        fun put(mode: ColorMode, token: DrawableToken, value: DrawableValue): Builder = putValue(mode, token, value)
        fun put(mode: ColorMode, token: IconToken, value: IconValue): Builder = putValue(mode, token, value)
        fun put(mode: ColorMode, token: AnimationToken, value: AnimationValue): Builder = putValue(mode, token, value)
        fun <S : ComponentStyle> put(mode: ColorMode, token: ComponentToken<S>, value: S): Builder = putValue(mode, token, token.schema.freeze(value))
        fun resources(catalog: LocalResourceCatalog): Builder = apply { resources = catalog }
        fun build(): AppDefaultTheme = AppDefaultTheme(appId, version, data, resources)
    }
    companion object { @JvmStatic fun builder(appId: String, version: String): Builder = Builder(appId, version) }
}
