package dev.skinkit.contract

/** The seven getter signatures are the permanent host-facing contract. All reads are prepared in-memory. */
interface ThemeProvider {
    val snapshot: ThemeSnapshotInfo
    fun getColor(token: ColorToken): ColorValue
    fun getTypography(token: TypographyToken): TypographyValue
    fun getDimension(token: DimensionToken): DimensionValue
    fun getDrawable(token: DrawableToken): DrawableValue
    fun getIcon(token: IconToken): IconValue
    fun getAnimation(token: AnimationToken): AnimationValue
    fun <S : ComponentStyle> getComponentStyle(token: ComponentToken<S>): S
}

data class ThemeSnapshotInfo(val generation: Long, val themeId: String?, val themeVersion: String?, val contractVersion: String) {
    init { require(generation >= 0); require((themeId == null) == (themeVersion == null)); require(contractVersion.isNotBlank()) }
}

/** One immutable generation. Retain it until drawing/resource work finishes; close is idempotent. */
interface ThemeReadView : ThemeProvider, AutoCloseable {
    val configuration: VisualConfiguration
    fun release()
    override fun close() = release()
}
fun interface SnapshotObserver { fun onSnapshot(snapshot: ThemeSnapshotInfo) }
fun interface Subscription : AutoCloseable { override fun close() }
interface PinnedThemeSource {
    fun pin(): ThemeReadView
    /** Replays current state immediately. Callbacks run outside internal locks; close cancels future delivery. */
    fun observeSnapshot(observer: SnapshotObserver): Subscription
}
