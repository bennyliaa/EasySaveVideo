package dev.skinkit.contract

/** Numeric semantic-version core. Prerelease/build metadata are not accepted in 0.0.1 ranges. */
data class Version(val major: Int, val minor: Int, val patch: Int) : Comparable<Version> {
    init { require(major >= 0 && minor >= 0 && patch >= 0) }
    override fun compareTo(other: Version): Int = compareValuesBy(this, other, { it.major }, { it.minor }, { it.patch })
    override fun toString(): String = "$major.$minor.$patch"
    companion object {
        @JvmStatic fun parse(value: String): Version {
            require(value.matches(Regex("(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)"))) { "Version must be major.minor.patch" }
            val parts = value.split('.').map { it.toIntOrNull() ?: throw IllegalArgumentException("Version component out of range") }
            return Version(parts[0], parts[1], parts[2])
        }
    }
}
data class VersionRange(val minimum: Version, val maximumExclusive: Version) {
    init { require(minimum < maximumExclusive) { "Empty version range" } }
    operator fun contains(version: Version): Boolean = version >= minimum && version < maximumExclusive
}

enum class CapabilityOwner { HOST, ADAPTER, MODULE }
class CapabilityDescriptor(val capabilityId: String, val version: Version, val owner: CapabilityOwner, val supported: Boolean, limits: Map<String, Long> = emptyMap()) {
    val limits: Map<String, Long> = frozenMap(limits)
    init { require(capabilityId.matches(Regex("[a-z][a-z0-9]*(\\.[a-z][a-z0-9]*)*"))); require(limits.all { it.key.isNotBlank() && it.value >= 0 }) }
}
class CapabilityRequirement @JvmOverloads constructor(val capabilityId: String, val versions: VersionRange, val required: Boolean = false, limits: Map<String, Long> = emptyMap()) {
    val limits: Map<String, Long> = frozenMap(limits)
    init { require(capabilityId.matches(Regex("[a-z][a-z0-9]*(\\.[a-z][a-z0-9]*)*"))); require(limits.all { it.key.isNotBlank() && it.value >= 0 }) }
    /** Explicit numeric limits: provider maximum must meet each requested amount. */
    fun isSatisfiedBy(capability: CapabilityDescriptor): Boolean = capability.capabilityId == capabilityId && capability.supported && capability.version in versions && limits.all { (key, amount) -> (capability.limits[key] ?: -1) >= amount }
}
class CapabilityCheck(requiredMissing: List<CapabilityRequirement>, optionalMissing: List<CapabilityRequirement>) {
    val requiredMissing = frozenList(requiredMissing)
    val optionalMissing = frozenList(optionalMissing)
    val canActivate: Boolean get() = requiredMissing.isEmpty()
}
class CapabilitySnapshot(capabilities: List<CapabilityDescriptor>) {
    val capabilities = frozenList(capabilities)
    init { require(capabilities.map { it.capabilityId }.toSet().size == capabilities.size) { "Capability provider ownership must be unique" } }
    fun check(requirements: List<CapabilityRequirement>): CapabilityCheck {
        val missing = requirements.filter { req -> capabilities.none { req.isSatisfiedBy(it) } }
        return CapabilityCheck(missing.filter { it.required }, missing.filterNot { it.required })
    }
}

enum class FallbackLayer { APP_EXTENSION, COMMON, APP_DEFAULT, SAFE_BUILT_IN }
enum class CandidateFailureCode { MISSING, TYPE_MISMATCH, SCHEMA_INCOMPATIBLE, CAPABILITY_UNSUPPORTED, RESOURCE_UNAVAILABLE, INVALID_VALUE, EXPLICIT_DISABLED_NOT_ALLOWED }
object FallbackProtocol {
    @JvmField val ORDER: List<FallbackLayer> = frozenList(FallbackLayer.entries)
    @JvmStatic fun eligibleLayers(token: ThemeToken, hasExplicitCommonMapping: Boolean): List<FallbackLayer> = if (token.id.startsWith("apps.") && !hasExplicitCommonMapping) frozenList(ORDER.filterNot { it == FallbackLayer.COMMON }) else ORDER
}

/** Mapping is schema- and field-bound; same names alone never establish compatibility. */
class TypedFieldMapping<V : Any, S : ComponentStyle, T : ComponentStyle>(val source: ComponentToken<S>, val sourceField: StyleField<V>, val target: ComponentToken<T>, val targetField: StyleField<V>) {
    init {
        require(!source.id.startsWith("apps.") && target.id.startsWith("apps.")) { "Mapping must go from Common to an App Extension" }
        require(sourceField in source.schema.fields && targetField in target.schema.fields) { "Mapping field must belong to its schema" }
        require(sourceField.type === targetField.type && sourceField.shared == targetField.shared) { "Mapped fields must have the same type and shared/state semantics" }
    }
}
data class ResourceLimits(val maximumBytes: Long, val maximumWidth: Int, val maximumHeight: Int) { init { require(maximumBytes > 0 && maximumWidth > 0 && maximumHeight > 0) } }
class ExtensionDescriptor(
    val appId: String,
    val extensionId: String,
    val extensionVersion: Version,
    val contractRange: VersionRange,
    val registry: TokenRegistry,
    mappings: List<TypedFieldMapping<*, *, *>>,
    val resourceLimits: ResourceLimits,
    editorMetadata: Map<String, String> = emptyMap()
) {
    val tokens: List<ThemeToken> = frozenList(registry.tokens.filter { it.id.startsWith("apps.$appId.") })
    val commonMappings = frozenList(mappings)
    val editorMetadata = frozenMap(editorMetadata)
    init {
        require(appId == registry.appId && extensionId.matches(Regex("[a-z][a-z0-9]*(\\.[a-z][a-z0-9]*)*")))
        require(Version.parse(SkinKitContract.VERSION) in contractRange) { "Extension contract range excludes this SDK" }
        mappings.forEach { registry.requireOwned(it.source); registry.requireOwned(it.target); require(it.target.id.startsWith("apps.$appId.")) }
        require(mappings.map { it.target.id to it.targetField.id }.toSet().size == mappings.size) { "Duplicate target field mapping" }
    }
}

enum class DiagnosticCode { DEFAULT_MISSING, INVALID_VALUE, CONTRAST_REJECTED, COMPONENT_INCOMPLETE, RESOURCE_UNAVAILABLE, SAFE_FALLBACK_USED, ANIMATION_UNSUPPORTED, OBSERVER_FAILED }
data class Diagnostic @JvmOverloads constructor(val code: DiagnosticCode, val tokenId: String, val configuration: VisualConfiguration, val message: String, val required: Boolean, val field: String? = null)
class ValidationReport(diagnostics: List<Diagnostic>) {
    val diagnostics: List<Diagnostic> = frozenList(diagnostics)
    val isComplete: Boolean get() = diagnostics.none { it.required && it.code != DiagnosticCode.ANIMATION_UNSUPPORTED && it.code != DiagnosticCode.OBSERVER_FAILED }
    fun requireComplete() { if (!isComplete) throw HostContractException("Incomplete AppDefaultTheme: " + diagnostics.filter { it.required }.joinToString { "${it.tokenId} (${it.configuration.colorMode}): ${it.message}" }) }
}
