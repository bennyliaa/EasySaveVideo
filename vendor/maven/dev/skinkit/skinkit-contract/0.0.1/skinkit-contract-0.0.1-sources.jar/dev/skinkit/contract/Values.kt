package dev.skinkit.contract

import java.util.Collections

internal fun <K, V> frozenMap(source: Map<K, V>): Map<K, V> = Collections.unmodifiableMap(LinkedHashMap(source))
internal fun <T> frozenList(source: Collection<T>): List<T> = Collections.unmodifiableList(ArrayList(source))
internal fun <T> frozenSet(source: Collection<T>): Set<T> = Collections.unmodifiableSet(LinkedHashSet(source))

/** The SDK version is independent of package, schema and theme versions. */
object SkinKitContract { const val VERSION: String = "0.0.1" }

enum class ColorMode { LIGHT, DARK }
enum class ColorSpace { SRGB }
enum class VisualState { NORMAL, DISABLED, PRESSED, FOCUSED, SELECTED, HOVERED }
enum class LogicalUnit { LENGTH, SCALED_TEXT }
enum class DimensionPurpose { SPACING, PADDING, CORNER, BORDER, ICON, TEXT, LINE_HEIGHT }

/** Configuration belongs to one immutable snapshot. Font scaling is applied once by the adapter. */
data class VisualConfiguration @JvmOverloads constructor(
    val colorMode: ColorMode = ColorMode.LIGHT,
    val fontScale: Double = 1.0,
    val reducedMotion: Boolean = false
) {
    init { require(fontScale.isFinite() && fontScale in 0.5..5.0) { "fontScale must be finite and within 0.5..5.0" } }
}

data class Rgba @JvmOverloads constructor(val red: Double, val green: Double, val blue: Double, val alpha: Double = 1.0) {
    init { require(listOf(red, green, blue, alpha).all { it.isFinite() && it in 0.0..1.0 }) { "RGBA channels must be finite and in 0..1" } }
    fun toArgb(): Int = ((alpha * 255 + .5).toInt() shl 24) or ((red * 255 + .5).toInt() shl 16) or ((green * 255 + .5).toInt() shl 8) or (blue * 255 + .5).toInt()
    companion object {
        @JvmStatic fun argb(argb: Int): Rgba = Rgba(((argb ushr 16) and 255) / 255.0, ((argb ushr 8) and 255) / 255.0, (argb and 255) / 255.0, ((argb ushr 24) and 255) / 255.0)
    }
}

/** Immutable sRGB value; state variants never mutate the base color. */
class ColorValue @JvmOverloads constructor(val rgba: Rgba, variants: Map<VisualState, Rgba> = emptyMap(), val colorSpace: ColorSpace = ColorSpace.SRGB) {
    val variants: Map<VisualState, Rgba> = frozenMap(variants)
    fun forState(state: VisualState): ColorValue = ColorValue(variants[state] ?: rgba)
    fun toArgb(): Int = rgba.toArgb()
    override fun equals(other: Any?): Boolean = other is ColorValue && rgba == other.rgba && variants == other.variants && colorSpace == other.colorSpace
    override fun hashCode(): Int = 31 * rgba.hashCode() + variants.hashCode()
    override fun toString(): String = "ColorValue(${rgba}, variants=$variants)"
    companion object { @JvmStatic fun argb(argb: Int): ColorValue = ColorValue(Rgba.argb(argb)) }
}

data class DimensionValue(val amount: Double, val unit: LogicalUnit, val purpose: DimensionPurpose) {
    init {
        require(amount.isFinite() && amount in 0.0..10000.0) { "dimension amount must be finite and in 0..10000" }
        require((purpose == DimensionPurpose.TEXT || purpose == DimensionPurpose.LINE_HEIGHT) == (unit == LogicalUnit.SCALED_TEXT)) { "text/line-height use SCALED_TEXT; other visual dimensions use LENGTH" }
    }
    fun scaled(fontScale: Double): Double { require(fontScale.isFinite() && fontScale > 0); return if (unit == LogicalUnit.SCALED_TEXT) amount * fontScale else amount }
}

/** A trusted local descriptor, never a URL or absolute filesystem path. It does not perform IO. */
data class LocalResourceRef(val owner: String, val name: String) {
    init {
        require(owner.matches(Regex("[a-z][a-z0-9_.-]*"))) { "resource owner must be a stable lowercase identifier" }
        require(name.matches(Regex("[a-z][a-z0-9_]*(/[a-z][a-z0-9_.-]*)*")) && !name.contains("..")) { "resource name must be a safe relative logical identifier" }
    }
}

sealed interface FontRef {
    data class System @JvmOverloads constructor(val family: String = "sans-serif") : FontRef {
        init { require(family in setOf("sans-serif", "serif", "monospace", "system-ui")) { "unsupported system font family" } }
    }
    data class Local @JvmOverloads constructor(val resource: LocalResourceRef, val fallback: System = System()) : FontRef
}

/** Font size and line height are scaled-text units; the adapter owns platform font fallback. */
data class TypographyValue(val font: FontRef, val fontSize: Double, val weight: Int, val lineHeight: Double) {
    init {
        require(fontSize.isFinite() && fontSize in 1.0..512.0) { "fontSize must be in 1..512 scaled-text units" }
        require(weight in 100..900) { "font weight must be in 100..900" }
        require(lineHeight.isFinite() && lineHeight >= fontSize && lineHeight <= 1024.0) { "lineHeight must be at least fontSize and at most 1024" }
    }
    fun effectiveSize(fontScale: Double): Double { require(fontScale.isFinite() && fontScale > 0); return fontSize * fontScale }
    fun effectiveLineHeight(fontScale: Double): Double { require(fontScale.isFinite() && fontScale > 0); return lineHeight * fontScale }
}

enum class ScaleMode { FIT, FILL, CENTER, TILE }
sealed interface DrawableValue {
    data class Solid(val color: ColorValue) : DrawableValue
    /** The fallback is already drawable in memory; no decoder is needed to show it. */
    data class Local @JvmOverloads constructor(val resource: LocalResourceRef, val fallback: Solid, val scaleMode: ScaleMode = ScaleMode.FIT) : DrawableValue
}

sealed interface IconSource
enum class BuiltInIcon : IconSource { CLOSE, CHECK, ADD, SEARCH, MORE, WARNING }
data class LocalIcon(val resource: LocalResourceRef, val fallback: BuiltInIcon) : IconSource
sealed interface TintPolicy {
    data object Original : TintPolicy
    data class Color(val color: ColorValue) : TintPolicy
}
data class IconValue @JvmOverloads constructor(val source: IconSource, val size: DimensionValue, val tint: TintPolicy = TintPolicy.Original) {
    init { require(size.purpose == DimensionPurpose.ICON && size.amount > 0.0) { "icon size must be a positive ICON dimension" } }
}

sealed interface AnimationValue {
    /** Deliberately off; valid and terminal, unlike Patch.Missing. */
    data object Disabled : AnimationValue
    data class Static(val drawable: DrawableValue) : AnimationValue
    /** Host/adapter capability must support the format; otherwise use the prepared static fallback. */
    data class Declarative(val format: CapabilityRequirement, val resource: LocalResourceRef, val fallback: Static) : AnimationValue
}

/** Input protocol for future resolvers. Null is neither Missing nor ExplicitDisabled. */
sealed interface Patch<out T : Any> {
    data object Missing : Patch<Nothing>
    data class Value<T : Any>(val value: T) : Patch<T>
    data object ExplicitDisabled : Patch<Nothing>
}
