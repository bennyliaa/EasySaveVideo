package dev.skinkit.contract

class HostContractException(message: String) : IllegalArgumentException(message)
enum class ColorRole { FOREGROUND, BACKGROUND, ACCENT, BORDER }
class ContrastPair(val foreground: ColorToken, val background: ColorToken, val minimumRatio: Double) { init { require(foreground !== background); require(minimumRatio.isFinite() && minimumRatio in 1.0..21.0) } }
enum class ValueKind(val prefix: String) { COLOR("color"), TYPOGRAPHY("typography"), DIMENSION("dimension"), DRAWABLE("drawable"), ICON("icon"), ANIMATION("animation"), COMPONENT("component") }

/** Opaque token identity: only the owning frozen registry may be used to read a provider. */
sealed class ThemeToken protected constructor(val id: String, val kind: ValueKind, val required: Boolean) {
    override fun toString(): String = id
}
class ColorToken private constructor(id: String, required: Boolean, val role: ColorRole) : ThemeToken(id, ValueKind.COLOR, required) { companion object { @JvmSynthetic internal fun create(id: String, required: Boolean, role: ColorRole) = ColorToken(id, required, role) } }
class TypographyToken private constructor(id: String, required: Boolean) : ThemeToken(id, ValueKind.TYPOGRAPHY, required) { companion object { @JvmSynthetic internal fun create(id: String, required: Boolean) = TypographyToken(id, required) } }
class DimensionToken private constructor(id: String, required: Boolean, val purpose: DimensionPurpose) : ThemeToken(id, ValueKind.DIMENSION, required) { companion object { @JvmSynthetic internal fun create(id: String, required: Boolean, purpose: DimensionPurpose) = DimensionToken(id, required, purpose) } }
class DrawableToken private constructor(id: String, required: Boolean) : ThemeToken(id, ValueKind.DRAWABLE, required) { companion object { @JvmSynthetic internal fun create(id: String, required: Boolean) = DrawableToken(id, required) } }
class IconToken private constructor(id: String, required: Boolean) : ThemeToken(id, ValueKind.ICON, required) { companion object { @JvmSynthetic internal fun create(id: String, required: Boolean) = IconToken(id, required) } }
class AnimationToken private constructor(id: String, required: Boolean) : ThemeToken(id, ValueKind.ANIMATION, required) { companion object { @JvmSynthetic internal fun create(id: String, required: Boolean) = AnimationToken(id, required) } }
class ComponentToken<S : ComponentStyle> private constructor(id: String, required: Boolean, val schema: ComponentSchema<S>) : ThemeToken(id, ValueKind.COMPONENT, required) { companion object { @JvmSynthetic internal fun <S : ComponentStyle> create(id: String, required: Boolean, schema: ComponentSchema<S>) = ComponentToken(id, required, schema) } }

class TokenRegistry private constructor(val appId: String, tokens: Map<String, ThemeToken>, contrastPairs: List<ContrastPair>) {
    val contrastPairs: List<ContrastPair> = frozenList(contrastPairs)
    private val byId = frozenMap(tokens)
    val tokens: List<ThemeToken> = frozenList(tokens.values)
    fun contains(token: ThemeToken): Boolean = byId[token.id] === token
    fun requireOwned(token: ThemeToken) {
        if (!contains(token)) throw HostContractException("Token '${token.id}' does not belong to this frozen registry for '$appId'. Keep the original registry token instance.")
    }
    class Builder internal constructor(val appId: String) {
        private val tokens = LinkedHashMap<String, ThemeToken>()
        private val schemas = LinkedHashMap<String, ComponentSchema<*>>()
        private val contrastPairs = ArrayList<ContrastPair>()
        private var built = false
        init { require(appId.matches(Regex("[a-z][a-z0-9]*(\\.[a-z][a-z0-9]*)*"))) { "appId must be a stable lowercase dot-separated identifier" } }
        private fun <T : ThemeToken> add(token: T): T {
            check(!built) { "Registry builder has been frozen" }
            require(token.id.matches(Regex("[a-z][a-z0-9]*(\\.[a-z][a-z0-9]*)*"))) { "Token ID must be lowercase dot-separated segments: ${token.id}" }
            require(token.id.startsWith("${token.kind.prefix}.") || token.id.startsWith("apps.$appId.${token.kind.prefix}.")) { "Token ${token.id} must use ${token.kind.prefix}.* or apps.$appId.${token.kind.prefix}.*" }
            require(!tokens.containsKey(token.id)) { "Duplicate token ID ${token.id}" }
            tokens[token.id] = token
            return token
        }
        @JvmOverloads fun color(id: String, required: Boolean = true, role: ColorRole = ColorRole.FOREGROUND): ColorToken = add(ColorToken.create(id, required, role))
        @JvmOverloads fun color(id: String, colorRole: ColorRole, required: Boolean = true): ColorToken = color(id, required, colorRole)
        @JvmOverloads fun typography(id: String, required: Boolean = true): TypographyToken = add(TypographyToken.create(id, required))
        @JvmOverloads fun dimension(id: String, required: Boolean = true, purpose: DimensionPurpose = DimensionPurpose.SPACING): DimensionToken = add(DimensionToken.create(id, required, purpose))
        @JvmOverloads fun dimension(id: String, dimensionPurpose: DimensionPurpose, required: Boolean = true): DimensionToken = dimension(id, required, dimensionPurpose)
        @JvmOverloads fun drawable(id: String, required: Boolean = true): DrawableToken = add(DrawableToken.create(id, required))
        @JvmOverloads fun icon(id: String, required: Boolean = true): IconToken = add(IconToken.create(id, required))
        @JvmOverloads fun animation(id: String, required: Boolean = true): AnimationToken = add(AnimationToken.create(id, required))
        @JvmOverloads fun <S : ComponentStyle> component(id: String, schema: ComponentSchema<S>, required: Boolean = true): ComponentToken<S> {
            val existing = schemas[schema.id]
            require(existing == null || existing === schema) { "Schema ID ${schema.id} has conflicting declarations" }
            if (id.startsWith("apps.")) require(schema.id.startsWith("apps.$appId.") || schema.isStandard) { "Custom schema must belong to apps.$appId" }
            else require(schema.isStandard) { "Common component tokens must use an SDK standard schema; register custom schemas in apps.$appId" }
            val result = add(ComponentToken.create(id, required, schema))
            schemas[schema.id] = schema
            return result
        }
        @JvmOverloads fun contrastPair(foreground: ColorToken, background: ColorToken, minimumRatio: Double = 4.5): Builder = apply {
            check(!built) { "Registry builder has been frozen" }
            require(tokens[foreground.id] === foreground && tokens[background.id] === background) { "Contrast tokens must belong to this registry" }
            require(foreground.role != ColorRole.BACKGROUND && background.role == ColorRole.BACKGROUND) { "Contrast pair must use a foreground role and a BACKGROUND role" }
            require(contrastPairs.none { it.foreground === foreground && it.background === background }) { "Duplicate contrast pair" }
            contrastPairs += ContrastPair(foreground, background, minimumRatio)
        }
        fun build(): TokenRegistry { check(!built) { "Registry builder has already been frozen" }; built = true; return TokenRegistry(appId, tokens, contrastPairs) }
    }
    companion object { @JvmStatic fun builder(appId: String): Builder = Builder(appId) }
}
