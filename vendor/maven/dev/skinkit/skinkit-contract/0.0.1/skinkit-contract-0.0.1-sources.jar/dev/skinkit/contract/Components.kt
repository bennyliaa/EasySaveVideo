package dev.skinkit.contract

/** Explicit state matching order, owned by a schema, not by map iteration order. */
class StateDomain @JvmOverloads constructor(requiredStates: Set<VisualState>, priority: List<VisualState> = requiredStates.toList()) {
    val requiredStates: Set<VisualState> = frozenSet(requiredStates)
    val priority: List<VisualState> = frozenList(priority)
    init {
        require(VisualState.NORMAL in requiredStates) { "state domain must include NORMAL" }
        require(priority.toSet() == requiredStates && priority.size == requiredStates.size) { "state priority must list every state exactly once" }
        require(priority.last() == VisualState.NORMAL) { "NORMAL must be the final state priority" }
    }
    fun resolve(activeStates: Set<VisualState>): VisualState = priority.firstOrNull { it != VisualState.NORMAL && it in activeStates } ?: VisualState.NORMAL
    companion object {
        @JvmField val NORMAL = StateDomain(setOf(VisualState.NORMAL))
        @JvmField val BUTTON = StateDomain(linkedSetOf(VisualState.DISABLED, VisualState.PRESSED, VisualState.FOCUSED, VisualState.NORMAL))
    }
}

/** Field kinds are closed to safe visual values, excluding callbacks, navigation, and layout trees. */
class FieldType<V : Any> private constructor(val name: String, val valueClass: Class<V>) {
    companion object {
        @JvmField val COLOR = FieldType("color", ColorValue::class.java)
        @JvmField val TYPOGRAPHY = FieldType("typography", TypographyValue::class.java)
        @JvmField val DIMENSION = FieldType("dimension", DimensionValue::class.java)
        @JvmField val DRAWABLE = FieldType("drawable", DrawableValue::class.java)
        @JvmField val ICON = FieldType("icon", IconValue::class.java)
        @JvmField val ANIMATION = FieldType("animation", AnimationValue::class.java)
    }
}

class StyleField<V : Any> @JvmOverloads constructor(val id: String, val type: FieldType<V>, val shared: Boolean = false, val required: Boolean = true) {
    init { require(id.matches(Regex("[a-z][a-z0-9]*(\\.[a-z][a-z0-9]*)*"))) { "invalid style field id: $id" } }
    override fun toString(): String = id
}

/** Defensive, immutable typed field storage. There is no public untyped get(String): Any. */
class StyleValues private constructor(values: Map<StyleField<*>, Map<VisualState, Any>>) {
    private val values: Map<StyleField<*>, Map<VisualState, Any>> = frozenMap(values.mapValues { frozenMap(it.value) })
    val fields: Set<StyleField<*>> = frozenSet(values.keys)
    fun <V : Any> get(field: StyleField<V>, state: VisualState): V = when (val result = patch(field, state)) {
        is Patch.Value -> result.value
        else -> throw HostContractException("Missing component field ${field.id} at $state; validate app defaults before rendering")
    }
    fun <V : Any> patch(field: StyleField<V>, state: VisualState): Patch<V> {
        val value = values[field]?.get(if (field.shared) VisualState.NORMAL else state) ?: return Patch.Missing
        return Patch.Value(field.type.valueClass.cast(value))
    }
    fun states(field: StyleField<*>): Set<VisualState> = frozenSet(values[field]?.keys ?: emptySet())
    internal fun raw(field: StyleField<*>, state: VisualState): Any? = values[field]?.get(state)
    fun has(field: StyleField<*>, state: VisualState): Boolean = values[field]?.containsKey(if (field.shared) VisualState.NORMAL else state) == true
    class Builder {
        private val values = LinkedHashMap<StyleField<*>, MutableMap<VisualState, Any>>()
        fun <V : Any> put(field: StyleField<V>, state: VisualState, value: V): Builder = apply {
            require(field.type.valueClass.isInstance(value)) { "Wrong value type for ${field.id}" }
            require(!field.shared || state == VisualState.NORMAL) { "Shared field ${field.id} must use NORMAL" }
            val entries = values.getOrPut(field) { LinkedHashMap() }
            require(!entries.containsKey(state)) { "Duplicate field ${field.id} at $state" }
            entries[state] = value
        }
        fun <V : Any> putShared(field: StyleField<V>, value: V): Builder = put(field, VisualState.NORMAL, value)
        fun build(): StyleValues = StyleValues(values)
    }
    companion object { @JvmStatic fun builder(): Builder = Builder() }
}

/** Implementations wrap immutable StyleValues. Factories are trusted host code, never package code. */
interface ComponentStyle { val fields: StyleValues }
fun interface SafeStyleFactory<S : ComponentStyle> { fun create(configuration: VisualConfiguration): S }
fun interface ComponentStyleFactory<S : ComponentStyle> { fun create(fields: StyleValues): S }

class ComponentSchema<S : ComponentStyle> private constructor(
    val id: String,
    val version: Version,
    val styleClass: Class<S>,
    fields: List<StyleField<*>>,
    val states: StateDomain,
    val safeFactory: SafeStyleFactory<S>,
    private val factory: ComponentStyleFactory<S>,
    internal val isStandard: Boolean
) {
    constructor(id: String, version: Version, styleClass: Class<S>, fields: List<StyleField<*>>, states: StateDomain, safeFactory: SafeStyleFactory<S>, factory: ComponentStyleFactory<S>) : this(id, version, styleClass, fields, states, safeFactory, factory, false)
    val fields: List<StyleField<*>> = frozenList(fields)
    init {
        require(id.matches(Regex("[a-z][a-z0-9]*(\\.[a-z][a-z0-9]*)*"))) { "Invalid component schema id" }
        require(fields.isNotEmpty() && fields.any { it.required }) { "Component schema needs required visual fields" }
        require(fields.map { it.id }.toSet().size == fields.size) { "Duplicate schema field" }
    }
    /** Rebuild through the registered typed constructor. No mutable host style is retained. */
    fun freeze(style: S): S {
        require(styleClass.isInstance(style)) { "Style does not match schema $id" }
        return checkedCreate(style.fields)
    }
    fun create(fields: StyleValues): S {
        val failures = validate(fields)
        require(failures.isEmpty()) { "Invalid component $id: ${failures.joinToString()}" }
        return checkedCreate(fields)
    }
    private fun checkedCreate(fields: StyleValues): S {
        val result = factory.create(fields)
        require(styleClass.isInstance(result) && result.fields === fields) { "Factory for $id must wrap supplied immutable fields without rewriting them" }
        return result
    }
    fun validate(style: S): List<String> = validate(style.fields)
    fun validate(values: StyleValues): List<String> {
        val errors = ArrayList<String>()
        values.fields.filter { it !in fields }.forEach { errors += "unknown field:${it.id}" }
        fields.forEach { field ->
            val declared = if (field.shared) setOf(VisualState.NORMAL) else states.requiredStates
            values.states(field).filterNot { it in declared }.forEach { errors += "${it.name.lowercase()}.${field.id}:undeclared state" }
            values.states(field).forEach { state ->
                val value = values.raw(field, state)
                if (field === StandardFields.CORNER && value is DimensionValue && value.purpose != DimensionPurpose.CORNER) errors += "${state.name.lowercase()}.${field.id}:must use CORNER purpose"
            }
        }
        fields.filter { it.required }.forEach { field ->
            val statesToCheck = if (field.shared) setOf(VisualState.NORMAL) else states.requiredStates
            statesToCheck.filterNot { values.has(field, it) }.forEach { errors += "${it.name.lowercase()}.${field.id}:missing" }
        }
        return frozenList(errors)
    }
    companion object {
        @JvmStatic fun button(safeFactory: SafeStyleFactory<ButtonStyle>): ComponentSchema<ButtonStyle> = ComponentSchema("component.button", Version(1, 0, 0), ButtonStyle::class.java, listOf(StandardFields.BACKGROUND, StandardFields.FOREGROUND, StandardFields.TYPOGRAPHY, StandardFields.CORNER), StateDomain.BUTTON, safeFactory, ComponentStyleFactory { ButtonStyle(it) }, true)
        @JvmStatic fun card(safeFactory: SafeStyleFactory<CardStyle>): ComponentSchema<CardStyle> = ComponentSchema("component.card", Version(1, 0, 0), CardStyle::class.java, listOf(StandardFields.BACKGROUND, StandardFields.FOREGROUND, StandardFields.CORNER), StateDomain.NORMAL, safeFactory, ComponentStyleFactory { CardStyle(it) }, true)
    }

}

data class ButtonVisual(val background: ColorValue, val foreground: ColorValue, val typography: TypographyValue)
class ButtonStyle internal constructor(override val fields: StyleValues) : ComponentStyle {
    val corner: DimensionValue get() = fields.get(StandardFields.CORNER, VisualState.NORMAL)
    fun forState(state: VisualState): ButtonVisual = ButtonVisual(fields.get(StandardFields.BACKGROUND, state), fields.get(StandardFields.FOREGROUND, state), fields.get(StandardFields.TYPOGRAPHY, state))
    companion object {
        @JvmStatic fun of(states: Map<VisualState, ButtonVisual>, corner: DimensionValue): ButtonStyle {
            require(corner.purpose == DimensionPurpose.CORNER) { "Button corner must use CORNER purpose" }
            val builder = StyleValues.builder().putShared(StandardFields.CORNER, corner)
            states.forEach { (state, visual) -> builder.put(StandardFields.BACKGROUND, state, visual.background).put(StandardFields.FOREGROUND, state, visual.foreground).put(StandardFields.TYPOGRAPHY, state, visual.typography) }
            return ButtonStyle(builder.build())
        }
    }
}

class CardStyle internal constructor(override val fields: StyleValues) : ComponentStyle {
    val background: ColorValue get() = fields.get(StandardFields.BACKGROUND, VisualState.NORMAL)
    val foreground: ColorValue get() = fields.get(StandardFields.FOREGROUND, VisualState.NORMAL)
    val corner: DimensionValue get() = fields.get(StandardFields.CORNER, VisualState.NORMAL)
    companion object {
        @JvmStatic fun of(background: ColorValue, foreground: ColorValue, corner: DimensionValue): CardStyle {
            require(corner.purpose == DimensionPurpose.CORNER)
            return CardStyle(StyleValues.builder().put(StandardFields.BACKGROUND, VisualState.NORMAL, background).put(StandardFields.FOREGROUND, VisualState.NORMAL, foreground).putShared(StandardFields.CORNER, corner).build())
        }
    }
}

object StandardFields {
    @JvmField val BACKGROUND = StyleField("background", FieldType.COLOR)
    @JvmField val FOREGROUND = StyleField("foreground", FieldType.COLOR)
    @JvmField val TYPOGRAPHY = StyleField("typography", FieldType.TYPOGRAPHY)
    @JvmField val CORNER = StyleField("corner", FieldType.DIMENSION, shared = true)
}
