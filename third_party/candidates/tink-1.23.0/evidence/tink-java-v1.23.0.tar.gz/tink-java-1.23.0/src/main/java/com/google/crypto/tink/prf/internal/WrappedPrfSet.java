// Copyright 2020 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
////////////////////////////////////////////////////////////////////////////////
package com.google.crypto.tink.prf.internal;

import com.google.crypto.tink.KeyStatus;
import com.google.crypto.tink.KeysetHandleInterface;
import com.google.crypto.tink.internal.LegacyProtoKey;
import com.google.crypto.tink.internal.MonitoringAnnotations;
import com.google.crypto.tink.internal.MonitoringClient;
import com.google.crypto.tink.internal.MonitoringUtil;
import com.google.crypto.tink.internal.MutableMonitoringRegistry;
import com.google.crypto.tink.internal.PrimitiveWrapper;
import com.google.crypto.tink.internal.Util;
import com.google.crypto.tink.prf.Prf;
import com.google.crypto.tink.prf.PrfSet;
import com.google.errorprone.annotations.Immutable;
import java.security.GeneralSecurityException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/** An implementation of PrfSet for a keyset. */
@Immutable
public final class WrappedPrfSet {
  private static class WrappedPrfSetImpl extends PrfSet {
    // This map is constructed using Collections.unmodifiableMap
    @SuppressWarnings("Immutable")
    private final Map<Integer, Prf> keyIdToPrfMap;

    private final int primaryKeyId;

    @Immutable
    private static class PrfWithMonitoring implements Prf {
      private final Prf prf;
      private final int keyId;

      @SuppressWarnings("Immutable")
      private final MonitoringClient.Logger logger;

      @Override
      public byte[] compute(byte[] input, int outputLength) throws GeneralSecurityException {
        try {
          byte[] output = prf.compute(input, outputLength);
          logger.log(keyId, input.length);
          return output;
        } catch (GeneralSecurityException e) {
          logger.logFailure();
          throw e;
        }
      }

      public PrfWithMonitoring(Prf prf, int keyId, MonitoringClient.Logger logger) {
        this.prf = prf;
        this.keyId = keyId;
        this.logger = logger;
      }
    }

    private WrappedPrfSetImpl(Map<Integer, Prf> keyIdToPrfMap, int primaryKeyId) {
      this.keyIdToPrfMap = keyIdToPrfMap;
      this.primaryKeyId = primaryKeyId;
    }

    @Override
    public int getPrimaryId() {
      return primaryKeyId;
    }

    @Override
    public Map<Integer, Prf> getPrfs() throws GeneralSecurityException {
      return keyIdToPrfMap;
    }
  }

  public static PrfSet create(
      KeysetHandleInterface keysetHandle, PrimitiveWrapper.PrimitiveFactory<Prf> factory)
      throws GeneralSecurityException {
    if (!Util.hasEnabledPrimaryKey(keysetHandle)) {
      throw new GeneralSecurityException("keyset doesn't contain a valid primary key");
    }
    MonitoringClient.Logger logger;
    MonitoringAnnotations annotations =
        keysetHandle.getAnnotationsOrNull(MonitoringAnnotations.class);
    if (annotations != null && !annotations.isEmpty()) {
      MonitoringClient client = MutableMonitoringRegistry.globalInstance().getMonitoringClient();
      logger = client.createLogger(keysetHandle, annotations, "prf", "compute");
    } else {
      logger = MonitoringUtil.DO_NOTHING_LOGGER;
    }

    Map<Integer, Prf> mutablePrfMap = new HashMap<>();
    for (int i = 0; i < keysetHandle.size(); i++) {
      KeysetHandleInterface.Entry entry = keysetHandle.getAt(i);
      if (entry.getStatus().equals(KeyStatus.ENABLED)) {
        if (entry.getKey() instanceof LegacyProtoKey) {
          LegacyProtoKey legacyProtoKey = (LegacyProtoKey) entry.getKey();
          if (legacyProtoKey.getOutputPrefix().size() != 0) {
            throw new GeneralSecurityException(
                "Cannot build PrfSet with keys with non-empty output prefix");
          }
        }
        Prf prf = factory.create(entry);
        // Likewise, the key IDs of the PrfSet passed
        mutablePrfMap.put(
            entry.getId(), new WrappedPrfSetImpl.PrfWithMonitoring(prf, entry.getId(), logger));
      }
    }
    return new WrappedPrfSetImpl(
        Collections.unmodifiableMap(mutablePrfMap), keysetHandle.getPrimary().getId());
  }

  private WrappedPrfSet() {}
}
