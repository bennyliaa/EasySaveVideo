// Copyright 2022 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
////////////////////////////////////////////////////////////////////////////////

package com.google.crypto.tink.internal;

import com.google.crypto.tink.Parameters;
import com.google.crypto.tink.ProtoParametersSerialization;
import java.security.GeneralSecurityException;

/**
 * Serializes {@code Parameters} objects into {@code Serialization} objects of a certain kind.
 *
 * <p>This class should eventually be in Tinks public API -- however, it might still change before
 * that.
 */
public abstract class ParametersSerializer<ParametersT extends Parameters> {
  /**
   * A function which serializes a Parameters object.
   *
   * <p>This interface exists only so we have a type we can reference in {@link #create}. Users
   * should not use this directly; see the explanation in {@link #create}.
   */
  public interface ParametersSerializationFunction<ParametersT extends Parameters> {
    ProtoParametersSerialization serializeParameters(ParametersT key) throws GeneralSecurityException;
  }

  private final Class<ParametersT> parametersClass;
  private final Class<ProtoParametersSerialization> serializationClass;

  private ParametersSerializer(
      Class<ParametersT> parametersClass, Class<ProtoParametersSerialization> serializationClass) {
    this.parametersClass = parametersClass;
    this.serializationClass = serializationClass;
  }

  public abstract ProtoParametersSerialization serializeParameters(ParametersT parameters)
      throws GeneralSecurityException;

  public Class<ParametersT> getParametersClass() {
    return parametersClass;
  }

  public Class<ProtoParametersSerialization> getSerializationClass() {
    return serializationClass;
  }

  /**
   * Creates a ParametersSerializer object.
   *
   * <p>In order to create a ParametersSerializer object, one typically writes a function
   *
   * <pre>{@code
   * class MyClass {
   *   private static ProtoParametersSerialization serializeParameters(MyParameters Parameters)
   *             throws GeneralSecurityException {
   *     ...
   *   }
   * }
   * }</pre>
   *
   * This function can then be used to create a {@code ParametersSerializer}:
   *
   * <pre>{@code
   * ParametersSerializer<MyParameters> serializer =
   *       ParametersSerializer.create(MyClass::serializeParameters, MyParameters.class);
   * }</pre>
   */
  public static <ParametersT extends Parameters>
      ParametersSerializer<ParametersT> create(
          ParametersSerializationFunction<ParametersT> function,
          Class<ParametersT> parametersClass) {
    return new ParametersSerializer<ParametersT>(
        parametersClass, ProtoParametersSerialization.class) {
      @Override
      public ProtoParametersSerialization serializeParameters(ParametersT parameters)
          throws GeneralSecurityException {
        return function.serializeParameters(parameters);
      }
    };
  }

}
