// Copyright 2023 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
////////////////////////////////////////////////////////////////////////////////

package com.google.crypto.tink;

import java.security.GeneralSecurityException;
import javax.annotation.Nullable;

/**
 * An object implementing this interface represents a collection of algorithms that a user wants
 * Tink to understand. For most users, one of the predefined {@link Configuration} objects is to be
 * used at primitive creation time.
 */
public interface Configuration {
  default <P> P createPrimitive(KeysetHandleInterface keysetHandle, Class<P> clazz)
      throws GeneralSecurityException {
    throw new GeneralSecurityException("createPrimitive is unimplemented");
  }

  @Nullable
  default <P> P getOrNull(Class<P> clazz) {
    return null;
  }

  default Key createKey(Parameters parameters, @Nullable Integer idRequirement)
      throws GeneralSecurityException {
    throw new GeneralSecurityException("createKey is unimplemented");
  }
}
