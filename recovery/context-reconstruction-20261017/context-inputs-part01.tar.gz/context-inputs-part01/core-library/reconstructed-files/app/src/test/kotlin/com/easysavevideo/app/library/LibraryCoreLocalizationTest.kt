package com.easysavevideo.app.library

import com.easysavevideo.app.R
import com.easysavevideo.library.*
import java.io.File
import java.lang.reflect.Modifier
import java.util.Locale
import org.junit.Assert.*
import org.junit.Test

class LibraryCoreLocalizationTest {
    private val en = LibraryCoreTestResources(Locale.ENGLISH)
    private val zh = LibraryCoreTestResources(Locale.SIMPLIFIED_CHINESE)
    private val root = listOf(File("."), File("app")).first { File(it, "src/main/kotlin").isDirectory }
    private fun source(name: String) = File(root, "src/main/kotlin/com/easysavevideo/app/library/$name.kt").readText()

    @Test fun allFixedMessagesResolveFromTheSameRetainedTokenInBothLocales() {
        assertEquals(17, LibraryNoticeKind.entries.size)
        for (kind in LibraryNoticeKind.entries) {
            val token = LibraryNotice.Fixed(kind)
            val english = libraryNoticeText(token, en.locale, en)
            val chinese = libraryNoticeText(token, zh.locale, zh)
            assertTrue(english.isNotBlank()); assertTrue(chinese.isNotBlank())
            assertNotEquals(english, chinese); assertEquals(token, token.copy())
            assertFalse(Regex("[\\p{IsHan}]").containsMatchIn(english))
        }
        assertTrue(libraryNoticeText(LibraryNotice.Fixed(LibraryNoticeKind.DELETE_PENDING), en.locale, en).contains("not complete"))
        assertTrue(libraryNoticeText(LibraryNotice.Fixed(LibraryNoticeKind.DELETE_STATE_UNKNOWN), en.locale, en).contains("unconfirmed"))
        assertTrue(libraryNoticeText(LibraryNotice.Fixed(LibraryNoticeKind.PROCESSING), en.locale, en).contains("not yet confirmed"))
    }

    @Test fun everyDomainErrorUsesItsExactCopyGroupWithoutDiscardingItsIdentity() {
        val groups = mapOf(
            R.string.library_core_error_invalid_item_query to listOf(LibraryError.INVALID_ID, LibraryError.INVALID_QUERY),
            R.string.library_core_error_invalid_name to listOf(LibraryError.INVALID_NAME),
            R.string.library_core_error_not_found to listOf(LibraryError.NOT_FOUND),
            R.string.library_core_error_stale to listOf(LibraryError.STALE_REVISION, LibraryError.STALE_PAGE),
            R.string.library_core_error_already_exists to listOf(LibraryError.ALREADY_EXISTS),
            R.string.library_core_error_folder_not_empty to listOf(LibraryError.FOLDER_NOT_EMPTY),
            R.string.library_core_error_folder_cycle to listOf(LibraryError.FOLDER_CYCLE),
            R.string.library_core_error_depth_limit to listOf(LibraryError.DEPTH_LIMIT),
            R.string.library_core_error_folder_limit to listOf(LibraryError.FOLDER_LIMIT),
            R.string.library_core_error_confirmation_required to listOf(LibraryError.CONFIRMATION_REQUIRED),
            R.string.library_core_error_busy to listOf(LibraryError.BUSY),
            R.string.library_core_error_storage_failure to listOf(LibraryError.STORAGE_FAILURE),
            R.string.library_core_error_release_unconfirmed to listOf(LibraryError.RESOURCE_RELEASE_UNCONFIRMED),
            R.string.library_core_error_idempotency_conflict to listOf(LibraryError.IDEMPOTENCY_CONFLICT),
            R.string.library_core_error_recovery_required to listOf(LibraryError.RECOVERY_REQUIRED),
        )
        assertEquals(17, LibraryError.entries.size)
        assertEquals(LibraryError.entries.toSet(), groups.values.flatten().toSet())
        assertEquals(17, groups.values.sumOf { it.size })
        groups.forEach { (resource, codes) -> codes.forEach { code ->
            assertEquals(resource, libraryErrorResource(code))
            assertEquals(LibraryNotice.Failure(code), libraryFailureNotice(code))
            for (resources in listOf(en, zh)) {
                assertEquals(resources.text(resource), libraryNoticeText(libraryFailureNotice(code), resources.locale, resources))
            }
        } }
    }

    @Test fun independentCountsSelectEnglishSingularAndPluralAndPreserveZero() {
        assertEquals("1 video · 1 subfolder", libraryFolderContents(1, 1, en.locale, en))
        assertEquals("0 videos · 2 subfolders", libraryFolderContents(0, 2, en.locale, en))
        assertEquals("1 个视频 · 2 个子文件夹", libraryFolderContents(1, 2, zh.locale, zh))
        assertTrue(libraryNoticeText(LibraryNotice.NonEmptyFolder(1, 2), en.locale, en).contains("1 video and 2 subfolders"))
        assertTrue(libraryNoticeText(LibraryNotice.NonEmptyFolder(0, 0), en.locale, en).contains("0 videos and 0 subfolders"))
        assertEquals("1 confirmed deletion is still awaiting cleanup; it is not complete.",
            en.quantity(R.plurals.library_core_pending_deletes, 1, "1"))
        assertEquals("0 confirmed deletions are still awaiting cleanup; they are not complete.",
            en.quantity(R.plurals.library_core_pending_deletes, 0, "0"))
        assertEquals("Page 1 · Up to 1 video per page", en.quantity(R.plurals.library_core_video_page, 1, "1", "1"))
        assertEquals("Page 2 · Up to 50 videos per page", en.quantity(R.plurals.library_core_video_page, 50, "2", "50"))
    }

    @Test fun mixedBatchSummaryRetainsAllSixResultsAndFormatsWithoutReferences() {
        val results = BatchMoveStatus.entries.flatMapIndexed { index, status ->
            (0..index).map { BatchMoveItemResult(MediaReadRef("private-$index-$it", 1, 1), status) }
        }
        val token = libraryBatchMoveSummary(results)
        assertEquals(LibraryNotice.BatchMoveSummary(1, 2, 3, 4, 5, 6), token)
        assertEquals("Per-item move results: moved 1; already at destination 2; expired 3; unavailable 4; unconfirmed 5; cancelled before start 6.", libraryNoticeText(token, en.locale, en))
        assertEquals("逐项移动结果：已移动 1；原已在目标 2；失效 3；不可用 4；未确认 5；取消后未开始 6。", libraryNoticeText(token, zh.locale, zh))
        assertFalse(libraryNoticeText(token, en.locale, en).contains("private-"))
        assertEquals(LibraryNotice.BatchMoveSummary(0, 0, 0, 0, 0, 0), libraryBatchMoveSummary(emptyList()))
    }

    @Test fun externalNamesAreArgumentsAndNeverTranslatedOrReinterpreted() {
        val name = "A 100% 中文 \"quoted\".mp4"
        for (resources in listOf(en, zh)) {
            for (id in listOf(R.string.library_core_location_folder, R.string.library_core_move_name)) {
                assertTrue(resources.text(id, name).endsWith(name))
            }
        }
        val screen = source("LibraryScreen")
        for (literal in listOf("EsvText(folder.displayName", "EsvText(media.displayName", "EsvText(selection.name", "EsvText(target.name)", "LibraryField(editor.name")) assertTrue(literal, screen.contains(literal))
        assertTrue(screen.contains("state.folder?.displayName ?: stringResource(R.string.library_core_folder_loading)"))
    }

    @Test fun noticePayloadFieldsAreImmutableTypedFactsWithoutPrivateTextOrAuthority() {
        val expected = mapOf(
            LibraryNotice.Fixed::class.java to mapOf("kind" to LibraryNoticeKind::class.java),
            LibraryNotice.Failure::class.java to mapOf("code" to LibraryError::class.java),
            LibraryNotice.NonEmptyFolder::class.java to mapOf("videos" to Int::class.javaPrimitiveType, "subfolders" to Int::class.javaPrimitiveType),
            LibraryNotice.BatchMoveSummary::class.java to listOf("moved", "alreadyAtTarget", "stale", "unavailable", "unconfirmed", "cancelledBeforeStart").associateWith { Int::class.javaPrimitiveType },
        )
        assertEquals(expected.keys, LibraryNotice::class.java.declaredClasses.toSet())
        expected.forEach { (type, fields) ->
            val actual = type.declaredFields.filterNot { it.isSynthetic || Modifier.isStatic(it.modifiers) }
            assertEquals(fields, actual.associate { it.name to it.type })
            assertTrue(actual.all { Modifier.isFinal(it.modifiers) })
        }
        assertEquals("LibraryNotice.NonEmptyFolder([redacted])", LibraryNotice.NonEmptyFolder(17, 23).toString())
        assertEquals("LibraryNotice.BatchMoveSummary([redacted])", LibraryNotice.BatchMoveSummary(1, 2, 3, 4, 5, 6).toString())
    }

    @Test fun bilingualResourcesHaveMatchingKeysParametersAndExplicitPluralForms() {
        assertEquals(52, en.strings.size); assertEquals(4, en.plurals.size)
        assertEquals(en.strings.keys, zh.strings.keys); assertEquals(en.plurals.keys, zh.plurals.keys)
        val formats = Regex("%[0-9]+\\$[ds]")
        en.strings.keys.forEach { key ->
            assertEquals(key, formats.findAll(en.strings.getValue(key)).map { it.value }.toList(),
                formats.findAll(zh.strings.getValue(key)).map { it.value }.toList())
        }
        en.plurals.keys.forEach { key ->
            assertEquals(setOf("one", "other"), en.plurals.getValue(key).keys)
            assertEquals(en.plurals.getValue(key).keys, zh.plurals.getValue(key).keys)
            en.plurals.getValue(key).keys.forEach { form ->
                assertEquals(key, formats.findAll(en.plurals.getValue(key).getValue(form)).map { it.value }.toList(),
                    formats.findAll(zh.plurals.getValue(key).getValue(form)).map { it.value }.toList())
            }
        }
    }

    @Test fun directResourceAndSourceReadsAreRegisteredAsTestInputs() {
        val build = File(root, "build.gradle.kts").readText()
        val resources = build.substringAfter("val contractResourceInputs =").substringBefore("val contractSourceInputs =")
        assertTrue(resources.contains("\"values\", \"values-zh-rCN\""))
        assertTrue(resources.contains("\"library_core.xml\""))
        assertTrue(resources.contains("\"library_multi.xml\""))
        val sources = build.substringAfter("val contractSourceInputs =").substringBefore("tasks.withType<Test>()")
        for (name in listOf("AndroidLibraryRuntime", "LibraryScreen", "LibraryNoticeResources", "LibraryPresentation", "LibraryMultiSelectionToolbar")) {
            assertTrue(name, sources.contains("src/main/kotlin/com/easysavevideo/app/library/$name.kt"))
        }
        assertTrue(build.contains("inputs.files(contractResourceInputs)"))
        assertTrue(build.contains("inputs.files(contractSourceInputs)"))
    }

    @Test fun compositionResolvesRetainedFactsAndKeepsOperationAndUnknownStateFences() {
        val runtime = source("AndroidLibraryRuntime")
        assertTrue(runtime.contains("val notice: LibraryNotice? = null"))
        assertTrue(runtime.contains("private fun mutate(successNotice: LibraryNotice,"))
        assertFalse(runtime.contains("libraryNoticeText(")); assertFalse(runtime.contains("Locale"))
        assertFalse(Regex("[\\p{IsHan}]").containsMatchIn(runtime))
        val resources = source("LibraryNoticeResources")
        assertTrue(resources.contains("LocalConfiguration.current")); assertTrue(resources.contains("LocalContext.current.createConfigurationContext(configuration).resources"))
        val screen = source("LibraryScreen")
        assertFalse(Regex("[\\p{IsHan}]").containsMatchIn(screen))
        assertEquals(4, Regex("libraryNoticeText\\(it\\)").findAll(screen).count())
        assertTrue(screen.contains("state.ready && !state.loading && state.items.isEmpty()"))
        assertTrue(screen.contains("state.deletion != null -> DeleteDialog(runtime, state.deletion)"))
        assertTrue(runtime.contains("state.deletion != confirmation || !confirmation.matches(state.selected)"))
        assertTrue(runtime.contains("generation != token ||"))
        assertTrue(runtime.contains("catch (_: Exception) { Result.failure(LibraryFailure(LibraryError.STORAGE_FAILURE)) }"))
        assertTrue(screen.contains("heightIn(max = 720.dp)")); assertTrue(screen.contains("FlowRow("))
        val presentation = source("LibraryPresentation")
        assertTrue(presentation.contains("if (millis == null) return unknownLabel"))
        assertTrue(presentation.contains("if (media.width == null || media.height == null) unknownLabel"))
        val toolbar = source("LibraryMultiSelectionToolbar")
        assertTrue(toolbar.contains("libraryInteger(count.toLong(), LocalConfiguration.current.locales[0])"))
    }
}
