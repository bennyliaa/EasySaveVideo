package com.easysavevideo.app.library

import com.easysavevideo.app.R
import java.io.File
import java.util.Locale
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Element

/** XML-backed adapter exercises the production resolver without mocking localized output. */
internal class LibraryCoreTestResources(val locale: Locale) : LibraryTextResources {
    private val folder = if (locale.language == "zh") "values-zh-rCN" else "values"
    private val root = listOf(File("src/main/res"), File("app/src/main/res")).first { it.isDirectory }
    private val factory = DocumentBuilderFactory.newInstance().apply {
        setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
    }
    val strings: Map<String, String>
    val plurals: Map<String, Map<String, String>>
    init {
        val document = factory.newDocumentBuilder().parse(File(root, "$folder/library_core.xml"))
        val stringNodes = document.getElementsByTagName("string")
        strings = (0 until stringNodes.length).associate {
            val element = stringNodes.item(it) as Element
            element.getAttribute("name") to element.textContent
        }
        val pluralNodes = document.getElementsByTagName("plurals")
        plurals = (0 until pluralNodes.length).associate {
            val element = pluralNodes.item(it) as Element
            val items = element.getElementsByTagName("item")
            element.getAttribute("name") to (0 until items.length).associate { index ->
                val item = items.item(index) as Element
                item.getAttribute("quantity") to item.textContent
            }
        }
    }
    private val stringNames = R.string::class.java.fields.associate { it.getInt(null) to it.name }
    private val pluralNames = R.plurals::class.java.fields.associate { it.getInt(null) to it.name }
    override fun text(id: Int, vararg arguments: Any): String = String.format(locale, strings.getValue(stringNames.getValue(id)), *arguments)
    override fun quantity(id: Int, count: Int, vararg arguments: Any): String {
        val forms = plurals.getValue(pluralNames.getValue(id))
        val category = if (locale.language == "en" && count == 1) "one" else "other"
        return String.format(locale, forms.getValue(category), *arguments)
    }
}
