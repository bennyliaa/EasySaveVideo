package com.easysavevideo.app.library

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import com.easysavevideo.app.R
import com.easysavevideo.library.LibraryError
import java.util.Locale

/** The same resource adapter is used by current Composition and locale-independent JVM contracts. */
internal interface LibraryTextResources {
    fun text(id: Int, vararg arguments: Any): String
    fun quantity(id: Int, count: Int, vararg arguments: Any): String
}

@Composable
private fun libraryTextResources(): LibraryTextResources {
    // EsvLocaleHost owns the localized context, including API31/32. Read configuration to recompose.
    val configuration = LocalConfiguration.current
    val resources = LocalContext.current.createConfigurationContext(configuration).resources
    return object : LibraryTextResources {
        override fun text(id: Int, vararg arguments: Any) = resources.getString(id, *arguments)
        override fun quantity(id: Int, count: Int, vararg arguments: Any) = resources.getQuantityString(id, count, *arguments)
    }
}

@Composable
internal fun libraryNoticeText(notice: LibraryNotice): String =
    libraryNoticeText(notice, LocalConfiguration.current.locales[0], libraryTextResources())

internal fun libraryNoticeText(notice: LibraryNotice, locale: Locale, resources: LibraryTextResources): String = when (notice) {
    is LibraryNotice.Fixed -> resources.text(libraryFixedNoticeResource(notice.kind))
    is LibraryNotice.Failure -> resources.text(libraryErrorResource(notice.code))
    is LibraryNotice.NonEmptyFolder -> resources.text(R.string.library_core_nonempty_folder,
        resources.quantity(R.plurals.library_core_videos_count, notice.videos, libraryInteger(notice.videos.toLong(), locale)),
        resources.quantity(R.plurals.library_core_subfolders_count, notice.subfolders, libraryInteger(notice.subfolders.toLong(), locale)))
    is LibraryNotice.BatchMoveSummary -> resources.text(R.string.library_core_batch_move_summary,
        *listOf(notice.moved, notice.alreadyAtTarget, notice.stale, notice.unavailable, notice.unconfirmed, notice.cancelledBeforeStart)
            .map { libraryInteger(it.toLong(), locale) }.toTypedArray())
}

@Composable
internal fun libraryFolderContents(videos: Int, subfolders: Int): String =
    libraryFolderContents(videos, subfolders, LocalConfiguration.current.locales[0], libraryTextResources())

internal fun libraryFolderContents(videos: Int, subfolders: Int, locale: Locale, resources: LibraryTextResources): String =
    resources.text(R.string.library_core_folder_contents,
        resources.quantity(R.plurals.library_core_videos_count, videos, libraryInteger(videos.toLong(), locale)),
        resources.quantity(R.plurals.library_core_subfolders_count, subfolders, libraryInteger(subfolders.toLong(), locale)))

internal fun libraryFixedNoticeResource(kind: LibraryNoticeKind): Int = when (kind) {
    LibraryNoticeKind.SEARCH_UNSUPPORTED -> R.string.library_core_notice_search_unsupported
    LibraryNoticeKind.NAME_SAVED -> R.string.library_core_notice_name_saved
    LibraryNoticeKind.MOVE_INTO_SELF -> R.string.library_core_notice_move_into_self
    LibraryNoticeKind.MOVED -> R.string.library_core_notice_moved
    LibraryNoticeKind.BATCH_MOVE_PROCESSING -> R.string.library_core_notice_batch_move_processing
    LibraryNoticeKind.DELETE_CAPACITY -> R.string.library_core_notice_delete_capacity
    LibraryNoticeKind.DELETED -> R.string.library_core_notice_deleted
    LibraryNoticeKind.VAULT_UNAVAILABLE -> R.string.library_core_notice_vault_unavailable
    LibraryNoticeKind.EXPORT_UNAVAILABLE -> R.string.library_core_notice_export_unavailable
    LibraryNoticeKind.DELETE_STATE_UNKNOWN -> R.string.library_core_notice_delete_state_unknown
    LibraryNoticeKind.DELETE_CLEANUP_FAILED -> R.string.library_core_notice_delete_cleanup_failed
    LibraryNoticeKind.DELETE_COMPLETE -> R.string.library_core_notice_delete_complete
    LibraryNoticeKind.DELETE_WAITING -> R.string.library_core_notice_delete_waiting
    LibraryNoticeKind.PROCESSING -> R.string.library_core_notice_processing
    LibraryNoticeKind.DELETE_PENDING -> R.string.library_core_notice_delete_pending
    LibraryNoticeKind.SELECTION_CHANGED -> R.string.library_core_notice_selection_changed
    LibraryNoticeKind.NAME_REQUIREMENTS -> R.string.library_core_notice_name_requirements
}

internal fun libraryErrorResource(error: LibraryError): Int = when (error) {
    LibraryError.INVALID_ID, LibraryError.INVALID_QUERY -> R.string.library_core_error_invalid_item_query
    LibraryError.INVALID_NAME -> R.string.library_core_error_invalid_name
    LibraryError.NOT_FOUND -> R.string.library_core_error_not_found
    LibraryError.STALE_REVISION, LibraryError.STALE_PAGE -> R.string.library_core_error_stale
    LibraryError.ALREADY_EXISTS -> R.string.library_core_error_already_exists
    LibraryError.FOLDER_NOT_EMPTY -> R.string.library_core_error_folder_not_empty
    LibraryError.FOLDER_CYCLE -> R.string.library_core_error_folder_cycle
    LibraryError.DEPTH_LIMIT -> R.string.library_core_error_depth_limit
    LibraryError.FOLDER_LIMIT -> R.string.library_core_error_folder_limit
    LibraryError.CONFIRMATION_REQUIRED -> R.string.library_core_error_confirmation_required
    LibraryError.BUSY -> R.string.library_core_error_busy
    LibraryError.STORAGE_FAILURE -> R.string.library_core_error_storage_failure
    LibraryError.RESOURCE_RELEASE_UNCONFIRMED -> R.string.library_core_error_release_unconfirmed
    LibraryError.IDEMPOTENCY_CONFLICT -> R.string.library_core_error_idempotency_conflict
    LibraryError.RECOVERY_REQUIRED -> R.string.library_core_error_recovery_required
}
