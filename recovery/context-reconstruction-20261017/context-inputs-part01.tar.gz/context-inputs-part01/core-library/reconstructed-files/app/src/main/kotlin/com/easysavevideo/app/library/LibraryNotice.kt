package com.easysavevideo.app.library

import com.easysavevideo.library.BatchMoveItemResult
import com.easysavevideo.library.BatchMoveStatus
import com.easysavevideo.library.LibraryError
import com.easysavevideo.library.LibraryFailure
import com.easysavevideo.library.LibraryNames

/** Locale-independent display facts only; no names, locators, exceptions or operation authority. */
sealed interface LibraryNotice {
    data class Fixed(val kind: LibraryNoticeKind) : LibraryNotice
    data class Failure(val code: LibraryError) : LibraryNotice
    data class NonEmptyFolder(val videos: Int, val subfolders: Int) : LibraryNotice {
        override fun toString() = "LibraryNotice.NonEmptyFolder([redacted])"
    }
    data class BatchMoveSummary(val moved: Int, val alreadyAtTarget: Int, val stale: Int,
        val unavailable: Int, val unconfirmed: Int, val cancelledBeforeStart: Int) : LibraryNotice {
        override fun toString() = "LibraryNotice.BatchMoveSummary([redacted])"
    }
}

enum class LibraryNoticeKind {
    SEARCH_UNSUPPORTED,
    NAME_SAVED,
    MOVE_INTO_SELF,
    MOVED,
    BATCH_MOVE_PROCESSING,
    DELETE_CAPACITY,
    DELETED,
    VAULT_UNAVAILABLE,
    EXPORT_UNAVAILABLE,
    DELETE_STATE_UNKNOWN,
    DELETE_CLEANUP_FAILED,
    DELETE_COMPLETE,
    DELETE_WAITING,
    PROCESSING,
    DELETE_PENDING,
    SELECTION_CHANGED,
    NAME_REQUIREMENTS,
}

internal fun libraryFailureNotice(error: LibraryError): LibraryNotice = LibraryNotice.Failure(error)

internal fun libraryNameError(value: String): LibraryNotice? = try {
    LibraryNames.validate(value); null
} catch (_: LibraryFailure) { LibraryNotice.Fixed(LibraryNoticeKind.NAME_REQUIREMENTS) }

internal fun libraryBatchMoveSummary(results: List<BatchMoveItemResult>): LibraryNotice.BatchMoveSummary {
    fun count(status: BatchMoveStatus) = results.count { it.status == status }
    return LibraryNotice.BatchMoveSummary(count(BatchMoveStatus.MOVED), count(BatchMoveStatus.ALREADY_AT_TARGET),
        count(BatchMoveStatus.STALE), count(BatchMoveStatus.UNAVAILABLE),
        count(BatchMoveStatus.FAILED_UNCONFIRMED), count(BatchMoveStatus.CANCELLED_BEFORE_START))
}
