package com.easysavevideo.app.library

import com.easysavevideo.library.MediaItem
import java.text.DateFormat
import java.text.NumberFormat
import java.util.Date
import java.util.Locale

/** Explicit locale arguments keep metadata formatting independent of the process default. */
internal fun libraryInteger(value: Long, locale: Locale): String = NumberFormat.getIntegerInstance(locale).format(value)

internal fun libraryDuration(millis: Long?, unknownLabel: String, locale: Locale = Locale.ROOT): String {
    if (millis == null) return unknownLabel
    val seconds = millis.coerceAtLeast(0) / 1_000
    return String.format(locale, "%02d:%02d:%02d", seconds / 3_600, seconds / 60 % 60, seconds % 60)
}

/** Binary unit symbols are technical notation; numeric fields follow the current UI locale. */
internal fun libraryBytes(bytes: Long, locale: Locale = Locale.ROOT): String = when {
    bytes >= 1_073_741_824 -> String.format(locale, "%.2f GiB", bytes / 1_073_741_824.0)
    bytes >= 1_048_576 -> String.format(locale, "%.1f MiB", bytes / 1_048_576.0)
    bytes >= 1_024 -> String.format(locale, "%.1f KiB", bytes / 1_024.0)
    else -> String.format(locale, "%d B", bytes)
}

internal fun libraryResolution(media: MediaItem, unknownLabel: String, locale: Locale = Locale.ROOT): String =
    if (media.width == null || media.height == null) unknownLabel else String.format(locale, "%d × %d", media.width, media.height)

internal fun libraryDate(media: MediaItem, locale: Locale): String =
    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, locale).format(Date(media.createdAtMillis))
