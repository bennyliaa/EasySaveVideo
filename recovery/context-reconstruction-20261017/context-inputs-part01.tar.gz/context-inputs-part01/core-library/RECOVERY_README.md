# Core Library preservation: context-reconstructed / unverified

Status: isolated preservation only, 2026-10-17. The original execution workspace reset before the parent completed the first focused compilation/test run. These files are reconstructed solely from this worker's own executed tool inputs and visible source/diff output in the current conversation. They are not a recovered checkout or a verified copy of the original 3034-file baseline or 3049-file candidate.

No original per-file hash survived in this worker's visible context. Any hashes in this preservation package describe the reconstructed bytes only. They do not establish equality to lost source bytes, compilation, JVM tests, lint, APKs, devices, publication, runtime behavior, or completed review.

## Complete new files preserved

The `reconstructed-files/` tree contains seven complete new files:

- app/src/main/kotlin/com/easysavevideo/app/library/LibraryNotice.kt
- app/src/main/kotlin/com/easysavevideo/app/library/LibraryNoticeResources.kt
- app/src/main/kotlin/com/easysavevideo/app/library/LibraryPresentation.kt
- app/src/main/res/values/library_core.xml
- app/src/main/res/values-zh-rCN/library_core.xml
- app/src/test/kotlin/com/easysavevideo/app/library/LibraryCoreLocalizationTest.kt
- app/src/test/kotlin/com/easysavevideo/app/library/LibraryCoreTestResources.kt

`reconstruct_new_core_files.py` preserves the executed generation logic for the three main Kotlin files and the paired resource XML. It writes with exclusive creation and does not overwrite existing files. The two full new test files were transcribed from visible executed tool inputs, incorporating the final visible build-input contract addition.

## Exact transformations preserved, original files not fabricated

`patches/transform_existing_core_files.py` preserves old/new snippets and fail-closed occurrence checks for eight existing files. It does not contain or invent their unobserved baseline content:

- app/src/main/kotlin/com/easysavevideo/app/library/AndroidLibraryRuntime.kt
- app/src/main/kotlin/com/easysavevideo/app/library/LibraryScreen.kt
- app/src/main/kotlin/com/easysavevideo/app/library/LibraryMultiSelectionToolbar.kt
- app/src/main/res/values/library_multi.xml
- app/src/main/res/values-zh-rCN/library_multi.xml
- app/src/test/kotlin/com/easysavevideo/app/library/LibraryRuntimeTest.kt
- app/src/test/kotlin/com/easysavevideo/app/library/LibraryPresentationTest.kt
- app/src/test/kotlin/com/easysavevideo/app/library/LibraryMultiSelectionTest.kt

The two `.additions.txt` files preserve exact inserted test bodies. The transformation program only reads an independently recovered baseline and writes a new isolated output directory after all required snippets match. It does not modify the baseline. It has not been applied to a verified baseline here. The script has additional fail-closed snippet-count checks as recovery packaging, not as a claim of verified baseline correspondence.

## Contract and integration notes

- Public `LibraryViewState.notice` becomes public sealed `LibraryNotice`, with fixed IDs, exact `LibraryError` code facts, non-empty-folder counts and six batch-move result counts. Rendering occurs against current Composition locale resources.
- Stable formatter signature: `libraryBytes(bytes: Long, locale: Locale = Locale.ROOT): String`.
- `library_multi_count` and `library_batch_move_count` remain string keys, switching to locale-formatted `%1$s`; English batch label becomes count-neutral.
- `library_batch_move_item` remains `%1$d` / `%2$s` for the export consumer.
- New resources: 52 strings and 4 plurals in each locale.
- New localization contract class contains nine tests, not ten. There are four new runtime tests and one new formatter test, with the old assertions converted to equivalent or stronger typed checks.
- Parent owned `app/build.gradle.kts`; no recovered build script is fabricated here. It must register paired `library_core.xml`, retain paired `library_multi.xml`, and register the directly read Runtime, Screen, NoticeResources, Presentation and Toolbar files. The test also reads the build script itself.
- Parent owned all Gradle execution. This worker performed no Gradle/APK/device/network operation before or during reconstruction.

## Checks allowed during preservation

Only Python syntax parsing, XML parsing, paired keys/placeholders/plural forms, inventory and current-byte hashing are checked here. They are checks on reconstruction package consistency only. All project compilation, JVM tests, lint, runtime review and original byte correspondence remain unverified.
