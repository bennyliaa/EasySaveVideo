"""Context-reconstructed/unverified exact text transformations from executed worker inputs.
Usage (only once a trustworthy original baseline is independently recovered):
  python transform_existing_core_files.py BASELINE_ROOT FRESH_OUTPUT_ROOT
Reads 8 existing baseline files and writes patched copies to a NEW isolated output root.
Does not overwrite the baseline. Requires exact old snippets; does not fabricate missing source.
No compilation, installation, device access, network or execution of project code.
"""
from pathlib import Path
import sys, importlib.util
here=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('new_core',here.parent/'reconstruct_new_core_files.py')
new_core=importlib.util.module_from_spec(spec);spec.loader.exec_module(new_core)

def change(s,old,new,count=1):
    actual=s.count(old)
    assert actual==count, f'Expected {count} copies, found {actual}: {old[:100]!r}'
    return s.replace(old,new)

def runtime(s):
    old_batch='''internal fun libraryBatchMoveSummary(results: List<BatchMoveItemResult>): String {
    fun count(status: BatchMoveStatus) = results.count { it.status == status }
    return "逐项移动结果：已移动 ${count(BatchMoveStatus.MOVED)}；原已在目标 ${count(BatchMoveStatus.ALREADY_AT_TARGET)}；" +
        "失效 ${count(BatchMoveStatus.STALE)}；不可用 ${count(BatchMoveStatus.UNAVAILABLE)}；" +
        "未确认 ${count(BatchMoveStatus.FAILED_UNCONFIRMED)}；取消后未开始 ${count(BatchMoveStatus.CANCELLED_BEFORE_START)}。"
}

'''
    s=change(s,old_batch,'')
    old_tail='''internal fun libraryNameError(value: String): String? = try {
    LibraryNames.validate(value); null
} catch (_: LibraryFailure) { "名称不能为空，不能包含路径分隔符、控制字符、无效 Unicode 或 . / ..，且 UTF-8 最多 255 字节。" }

internal fun libraryErrorText(error: LibraryError): String = when (error) {
    LibraryError.INVALID_ID, LibraryError.INVALID_QUERY -> "项目或搜索无效，请刷新后重试。"
    LibraryError.INVALID_NAME -> "名称无效，请检查字符与长度。"
    LibraryError.NOT_FOUND -> "项目已不存在或不再可用，已保留其他媒体。"
    LibraryError.STALE_REVISION, LibraryError.STALE_PAGE -> "媒体库已变化，请查看刷新后的内容并重新操作。"
    LibraryError.ALREADY_EXISTS -> "此位置已有同名项目，请换一个名称。"
    LibraryError.FOLDER_NOT_EMPTY -> "文件夹仍有内容。请先移动其中的视频和子文件夹；不会递归删除。"
    LibraryError.FOLDER_CYCLE -> "不能移入自身或自己的子文件夹。"
    LibraryError.DEPTH_LIMIT -> "超过支持的文件夹深度，请选择较上层的位置。"
    LibraryError.FOLDER_LIMIT -> "已达到本版本的文件夹数量上限。"
    LibraryError.CONFIRMATION_REQUIRED -> "请重新核对当前项目并确认删除。"
    LibraryError.BUSY -> "媒体正在被读取或操作队列已满，请关闭预览并稍后重试。"
    LibraryError.STORAGE_FAILURE -> "本地存储暂不可用，操作未确认完成。可刷新核对。"
    LibraryError.RESOURCE_RELEASE_UNCONFIRMED -> "现有媒体读取尚未确认退出，文件保留等待清理。"
    LibraryError.IDEMPOTENCY_CONFLICT -> "此操作与已有记录不一致，请刷新核对。"
    LibraryError.RECOVERY_REQUIRED -> "媒体库需要恢复检查；文件已保留，不会假报完成。"
}
'''
    assert s.endswith(old_tail)
    s=change(s,old_tail,'')
    s=change(s,'val notice: String? = null','val notice: LibraryNotice? = null')
    for kind,chinese,_ in new_core.fixed:
        if kind!='NAME_REQUIREMENTS':s=change(s,'"'+chinese+'"',f'LibraryNotice.Fixed(LibraryNoticeKind.{kind})')
    s=change(s,'"此文件夹仍有 ${selected.folder.itemCount} 个视频、${selected.folder.childFolderCount} 个子文件夹。请先逐项移动内容；本版本只删除空文件夹。"','LibraryNotice.NonEmptyFolder(selected.folder.itemCount, selected.folder.childFolderCount)')
    s=change(s,'libraryErrorText(','libraryFailureNotice(',5)
    s=change(s,'private fun mutate(successText: String,','private fun mutate(successNotice: LibraryNotice,')
    s=change(s,'if (pending == null) successText else','if (pending == null) successNotice else')
    return s

def screen(s):
    s=change(s,'import androidx.compose.ui.res.stringResource','import androidx.compose.ui.res.stringResource\nimport androidx.compose.ui.res.pluralStringResource')
    for imp in ['import java.text.DateFormat\n','import java.util.Date\n','import java.util.Locale\n']:s=change(s,imp,'')
    s=change(s,'@Composable\nfun LibraryScreen(', '@OptIn(ExperimentalLayoutApi::class)\n@Composable\nfun LibraryScreen(')
    s=change(s,'    val state = runtime.state\n    val v = LocalEsvVisuals.current\n    var grid','    val state = runtime.state\n    val v = LocalEsvVisuals.current\n    val locale = LocalConfiguration.current.locales[0]\n    var grid')
    replacements=[
('EsvText(if (state.query.folderId == null) "位置：媒体库根目录" else "位置：${state.folder?.displayName ?: "正在读取文件夹…"}",','EsvText(if (state.query.folderId == null) stringResource(R.string.library_core_location_root) else stringResource(R.string.library_core_location_folder, state.folder?.displayName ?: stringResource(R.string.library_core_folder_loading)),',1),
('if (move.batchRefs.isEmpty()) "移动：${move.target.name}" else stringResource(R.string.library_batch_move_count, move.batchRefs.size)','if (move.batchRefs.isEmpty()) stringResource(R.string.library_core_move_name, move.target.name) else stringResource(R.string.library_batch_move_count, libraryInteger(move.batchRefs.size.toLong(), locale))',1),
('EsvText(it, style = v.captionTextStyle)\n                                EsvButton','EsvText(libraryNoticeText(it), style = v.captionTextStyle)\n                                EsvButton',1),
('EsvText("${state.pendingDeleteCount} 个已确认删除的项目仍待清理；尚未完成。",','EsvText(pluralStringResource(R.plurals.library_core_pending_deletes, state.pendingDeleteCount, libraryInteger(state.pendingDeleteCount.toLong(), locale)),',1),
('EsvText("文件夹（${state.folders.size}）",','EsvText(stringResource(R.string.library_core_folder_heading, libraryInteger(state.folders.size.toLong(), locale)),',1),
('EsvText("${folder.itemCount} 个视频 · ${folder.childFolderCount} 个子文件夹",','EsvText(libraryFolderContents(folder.itemCount, folder.childFolderCount),',1),
('EsvText(if (state.query.text.isEmpty()) "视频" else "当前文件夹搜索结果",','EsvText(stringResource(if (state.query.text.isEmpty()) R.string.library_core_videos else R.string.library_core_search_results),',1),
('EsvText(if (state.query.text.isEmpty()) "此文件夹暂无已入库视频。" else stringResource(R.string.flow_library_no_match),','EsvText(stringResource(if (state.query.text.isEmpty()) R.string.library_core_empty_folder else R.string.flow_library_no_match),',1),
('EsvText("MP4 · ${durationLabel(media.durationMillis)} · ${libraryBytes(media.sizeBytes)}",','EsvText(stringResource(R.string.library_core_media_metadata, durationLabel(media.durationMillis), libraryBytes(media.sizeBytes, locale)),',1),
('EsvText("第 ${(state.query.cursor?.offset ?: 0) / state.query.pageSize + 1} 页 · 每页最多 ${state.query.pageSize} 个视频",','EsvText(pluralStringResource(R.plurals.library_core_video_page, state.query.pageSize,\n                                    libraryInteger(((state.query.cursor?.offset ?: 0) / state.query.pageSize + 1).toLong(), locale),\n                                    libraryInteger(state.query.pageSize.toLong(), locale)),',1),
('stringResource(R.string.library_multi_count, currentMulti.count)','stringResource(R.string.library_multi_count, libraryInteger(currentMulti.count.toLong(), locale))',1),
('EsvText("已验证的本地 MP4 · ${libraryBytes(media.sizeBytes)}")','EsvText(stringResource(R.string.library_core_verified_mp4, libraryBytes(media.sizeBytes, LocalConfiguration.current.locales[0])))',1),
('EsvText("${durationLabel(media.durationMillis)} · ${resolutionLabel(media)}")','EsvText(stringResource(R.string.library_core_duration_resolution, durationLabel(media.durationMillis), resolutionLabel(media)))',1),
('EsvText("${selection.folder.itemCount} 个视频 · ${selection.folder.childFolderCount} 个子文件夹")','EsvText(libraryFolderContents(selection.folder.itemCount, selection.folder.childFolderCount))',1),
('EsvButton(if (selection is LibrarySelection.Folder) "删除空文件夹…" else "删除本地视频…",','EsvButton(stringResource(if (selection is LibrarySelection.Folder) R.string.library_core_delete_folder else R.string.library_core_delete_video),',1),
('runtime.state.notice?.let { EsvText(it, style = v.captionTextStyle) }','runtime.state.notice?.let { EsvText(libraryNoticeText(it), style = v.captionTextStyle) }',2),
('EsvText(if (editor.target == null) "新建文件夹" else "重命名",','EsvText(stringResource(if (editor.target == null) R.string.flow_libraryscreen_8 else R.string.flow_libraryscreen_41),',1),
('LibraryField(editor.name, runtime::editName, "名称",','LibraryField(editor.name, runtime::editName, stringResource(R.string.library_core_name_label),',1),
('libraryNameError(editor.name)?.let { EsvText(it,','libraryNameError(editor.name)?.let { EsvText(libraryNoticeText(it),',1),
('EsvText(if (target is LibrarySelection.Media) "永久删除这个本地视频？" else "删除这个空文件夹？",','EsvText(stringResource(if (target is LibrarySelection.Media) R.string.library_core_confirm_delete_video else R.string.library_core_confirm_delete_folder),',1),
('EsvText("项目 ${target.id} · 版本 ${target.revision}",','EsvText(stringResource(R.string.library_core_item_revision, target.id, libraryInteger(target.revision, LocalConfiguration.current.locales[0])),',1),
]
    for old,new,count in replacements:s=change(s,old,new,count)
    s=change(s,'Row(horizontalArrangement = Arrangement.spacedBy(v.spacingSmall)) {','FlowRow(horizontalArrangement = Arrangement.spacedBy(v.spacingSmall), verticalArrangement = Arrangement.spacedBy(v.spacingSmall)) {',5)
    old_suffix='''@Composable private fun durationLabel(millis:Long?)=libraryDuration(millis,stringResource(R.string.finite_duration_unknown))
@Composable private fun resolutionLabel(media:MediaItem)=libraryResolution(media,stringResource(R.string.finite_resolution_unknown))
@Composable private fun dateLabel(media:MediaItem):String = stringResource(
    if(media.dateKind==MediaDateKind.IMPORTED)R.string.finite_imported_at else R.string.finite_saved_at,
    libraryDate(media,LocalConfiguration.current.locales[0]))
internal fun libraryDuration(millis: Long?, unknownLabel:String): String {
    if (millis == null) return unknownLabel
    val seconds = millis.coerceAtLeast(0) / 1_000
    return String.format(Locale.ROOT, "%02d:%02d:%02d", seconds / 3_600, seconds / 60 % 60, seconds % 60)
}
internal fun libraryBytes(bytes: Long): String = when {
    bytes >= 1_073_741_824 -> String.format(Locale.ROOT, "%.2f GiB", bytes / 1_073_741_824.0)
    bytes >= 1_048_576 -> String.format(Locale.ROOT, "%.1f MiB", bytes / 1_048_576.0)
    bytes >= 1_024 -> String.format(Locale.ROOT, "%.1f KiB", bytes / 1_024.0)
    else -> "$bytes B"
}
internal fun libraryResolution(media: MediaItem,unknownLabel:String): String = if (media.width == null) unknownLabel else "${media.width} × ${media.height}"
internal fun libraryDate(media: MediaItem,locale:Locale): String =
    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT,locale).format(Date(media.createdAtMillis))
'''
    assert s.endswith(old_suffix)
    new_suffix='''@Composable private fun durationLabel(millis: Long?) = libraryDuration(millis,
    stringResource(R.string.finite_duration_unknown), LocalConfiguration.current.locales[0])
@Composable private fun resolutionLabel(media: MediaItem) = libraryResolution(media,
    stringResource(R.string.finite_resolution_unknown), LocalConfiguration.current.locales[0])
@Composable private fun dateLabel(media: MediaItem): String = stringResource(
    if (media.dateKind == MediaDateKind.IMPORTED) R.string.finite_imported_at else R.string.finite_saved_at,
    libraryDate(media, LocalConfiguration.current.locales[0]))
'''
    return change(s,old_suffix,new_suffix)

def toolbar(s):
    s=change(s,'import androidx.compose.ui.res.stringResource','import androidx.compose.ui.res.stringResource\nimport androidx.compose.ui.platform.LocalConfiguration')
    return change(s,'stringResource(R.string.library_multi_count, count)','stringResource(R.string.library_multi_count, libraryInteger(count.toLong(), LocalConfiguration.current.locales[0]))')

def multi_en(s):
    return change(change(s,'Selected: %1$d','Selected: %1$s'),'Move %1$d selected videos','Selected videos to move: %1$s')

def multi_zh(s):
    return change(change(s,'已选择 %1$d 项','已选择 %1$s 项'),'移动 %1$d 个所选视频','待移动的所选视频：%1$s')

def runtime_test(s):
    stales=['STALE_PAGE','STALE_REVISION','STALE_PAGE','STALE_PAGE','STALE_REVISION','STALE_PAGE']
    old='assertTrue(h.runtime.state.notice.orEmpty().contains("变化"))'
    assert s.count(old)==len(stales)
    for code in stales:s=s.replace(old,f'assertEquals(LibraryNotice.Failure(LibraryError.{code}), h.runtime.state.notice)',1)
    replacements={
'assertTrue(h.runtime.state.notice.orEmpty().contains("尚未确认完成"))':'assertEquals(LibraryNotice.Fixed(LibraryNoticeKind.PROCESSING), h.runtime.state.notice)',
'assertTrue(h.runtime.state.notice.orEmpty().contains("删除已完成"))':'assertEquals(LibraryNotice.Fixed(LibraryNoticeKind.DELETE_COMPLETE), h.runtime.state.notice)',
'assertTrue(h.runtime.state.notice.orEmpty().contains("暂不可核实"))':'assertEquals(LibraryNotice.Fixed(LibraryNoticeKind.DELETE_STATE_UNKNOWN), h.runtime.state.notice)',
'assertTrue(h.runtime.state.notice.orEmpty().contains("2 个视频、3 个子文件夹"))':'assertEquals(LibraryNotice.NonEmptyFolder(2, 3), h.runtime.state.notice)',
'assertTrue(h.runtime.state.notice.orEmpty().contains("队列已满"))':'assertEquals(LibraryNotice.Failure(LibraryError.BUSY), h.runtime.state.notice)',
}
    for old,new in replacements.items():s=change(s,old,new)
    old='assertTrue(h.runtime.state.notice.orEmpty().contains("尚未完成"))';assert s.count(old)==2
    s=s.replace(old,'assertEquals(LibraryNotice.Fixed(LibraryNoticeKind.DELETE_PENDING), h.runtime.state.notice)',1)
    s=s.replace(old,'assertEquals(LibraryNotice.Fixed(LibraryNoticeKind.DELETE_WAITING), h.runtime.state.notice)',1)
    return change(s,'    private fun pickerPageHarness(', (here/'LibraryRuntimeTest.additions.txt').read_text()+'    private fun pickerPageHarness(')

def presentation_test(s):
    old='''            val text = libraryErrorText(error)
            assertTrue(text.isNotBlank())
            assertFalse(text.contains("Exception"))
            assertFalse(text.contains("/data/"))'''
    new='''            for (locale in listOf(Locale.ENGLISH, Locale.SIMPLIFIED_CHINESE)) {
                val text = libraryNoticeText(libraryFailureNotice(error), locale, LibraryCoreTestResources(locale))
                assertTrue(text.isNotBlank())
                assertFalse(text.contains("Exception"))
                assertFalse(text.contains("/data/"))
            }'''
    s=change(s,old,new)
    return change(s,'    @Test fun allDomainErrors',(here/'LibraryPresentationTest.additions.txt').read_text()+'    @Test fun allDomainErrors')

def multi_test(s):
    needle='        val format=Regex("%[0-9]+\\\\$[ds]")'
    addition='''        // Count-neutral labels accept already localized numeric text; shared item ordinal stays numeric.
        for (values in listOf(en, zh)) {
            assertTrue(values.getValue("library_multi_count").contains("%1\\$s"))
            assertTrue(values.getValue("library_batch_move_count").contains("%1\\$s"))
            assertTrue(values.getValue("library_batch_move_item").contains("%1\\$d"))
            assertTrue(values.getValue("library_batch_move_item").contains("%2\\$s"))
        }
'''
    return change(s,needle,addition+needle)

transforms={
'app/src/main/kotlin/com/easysavevideo/app/library/AndroidLibraryRuntime.kt':runtime,
'app/src/main/kotlin/com/easysavevideo/app/library/LibraryScreen.kt':screen,
'app/src/main/kotlin/com/easysavevideo/app/library/LibraryMultiSelectionToolbar.kt':toolbar,
'app/src/main/res/values/library_multi.xml':multi_en,
'app/src/main/res/values-zh-rCN/library_multi.xml':multi_zh,
'app/src/test/kotlin/com/easysavevideo/app/library/LibraryRuntimeTest.kt':runtime_test,
'app/src/test/kotlin/com/easysavevideo/app/library/LibraryPresentationTest.kt':presentation_test,
'app/src/test/kotlin/com/easysavevideo/app/library/LibraryMultiSelectionTest.kt':multi_test,
}

if __name__=='__main__':
    assert len(sys.argv)==3, 'Provide independently recovered baseline and NEW output directory'
    source=Path(sys.argv[1]).resolve();output=Path(sys.argv[2]).resolve()
    assert source.is_dir() and not output.exists()
    results={relative:transform((source/relative).read_text()) for relative,transform in transforms.items()}
    output.mkdir(parents=True,exist_ok=False)
    for relative,text in results.items():
        path=output/relative;path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('x',encoding='utf-8') as stream:stream.write(text)
    print(f'Wrote {len(results)} context-reconstructed/unverified patched files to fresh output; baseline untouched.')
