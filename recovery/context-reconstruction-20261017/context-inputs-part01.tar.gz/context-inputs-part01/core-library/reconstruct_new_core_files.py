"""Context-reconstructed/unverified. Reproduces only new files from this worker's visible tool inputs.
No original baseline or original content hashes survived. Never overwrite existing files.
"""
from pathlib import Path
from xml.sax.saxutils import escape
root=Path(__file__).resolve().parent/'reconstructed-files'
base=root/'app/src/main/kotlin/com/easysavevideo/app/library'
def write(path,text):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as stream:stream.write(text)
fixed=[
('SEARCH_UNSUPPORTED','搜索内容包含不支持的字符。','The search contains unsupported characters.'),
('NAME_SAVED','名称已保存。','Name saved.'),
('MOVE_INTO_SELF','不能将文件夹移动到其自身。','A folder cannot be moved into itself.'),
('MOVED','已移动到所选文件夹。','Moved to the selected folder.'),
('BATCH_MOVE_PROCESSING','正在逐项移动，尚未确认完成。','Moving items one at a time; completion is not yet confirmed.'),
('DELETE_CAPACITY','已有较多删除等待清理，请等待完成后再删除其他项目。','Too many confirmed deletions are awaiting cleanup. Wait for cleanup before deleting more items.'),
('DELETED','已删除。','Deleted.'),
('VAULT_UNAVAILABLE','Vault 将保持免费。此开发阶段尚未提供加密存储或解锁，当前普通媒体库不具有 Vault 保护。','Vault will remain free. Encrypted storage and unlocking are not available at this development stage. The ordinary library does not have Vault protection.'),
('EXPORT_UNAVAILABLE','导出服务尚未就绪。原视频仍在应用普通媒体库中。','Export is not ready. The original video remains in the ordinary library.'),
('DELETE_STATE_UNKNOWN','部分已确认删除的项目状态暂不可核实，未确认完成。请刷新重试。','The state of some confirmed deletions cannot currently be verified. Completion is unconfirmed. Refresh to retry.'),
('DELETE_CLEANUP_FAILED','部分已确认删除仍待清理，尚未完成。可稍后刷新重试。','Some confirmed deletions still need cleanup and are not complete. Refresh later to retry.'),
('DELETE_COMPLETE','已确认的删除已完成。','Confirmed deletions are complete.'),
('DELETE_WAITING','已确认的删除仍在等待清理，尚未完成。','Confirmed deletions are still awaiting cleanup and are not complete.'),
('PROCESSING','正在处理操作，尚未确认完成。','Processing the operation; completion is not yet confirmed.'),
('DELETE_PENDING','已从媒体库移除，文件仍待现有读取退出并完成清理。删除尚未完成。','Removed from the library. File cleanup is waiting for existing readers to close. Deletion is not complete.'),
('SELECTION_CHANGED','所选项目已变化，请重新打开并确认。','The selected item has changed. Open it again and reconfirm.'),
('NAME_REQUIREMENTS','名称不能为空，不能包含路径分隔符、控制字符、无效 Unicode 或 . / ..，且 UTF-8 最多 255 字节。','A name cannot be blank, contain path separators, control characters or invalid Unicode, or be a single or double period. It must fit within 255 UTF-8 bytes.'),
]
errors=[
('INVALID_ID, INVALID_QUERY','invalid_item_query','项目或搜索无效，请刷新后重试。','The item or search is invalid. Refresh and try again.'),
('INVALID_NAME','invalid_name','名称无效，请检查字符与长度。','The name is invalid. Check its characters and length.'),
('NOT_FOUND','not_found','项目已不存在或不再可用，已保留其他媒体。','The item no longer exists or is unavailable. Other media has been preserved.'),
('STALE_REVISION, STALE_PAGE','stale','媒体库已变化，请查看刷新后的内容并重新操作。','The library has changed. Review the refreshed content and try again.'),
('ALREADY_EXISTS','already_exists','此位置已有同名项目，请换一个名称。','An item with this name already exists here. Choose another name.'),
('FOLDER_NOT_EMPTY','folder_not_empty','文件夹仍有内容。请先移动其中的视频和子文件夹；不会递归删除。','The folder still contains items. Move its videos and subfolders first. Contents will not be recursively deleted.'),
('FOLDER_CYCLE','folder_cycle','不能移入自身或自己的子文件夹。','A folder cannot be moved into itself or one of its subfolders.'),
('DEPTH_LIMIT','depth_limit','超过支持的文件夹深度，请选择较上层的位置。','The folder depth limit would be exceeded. Choose a higher-level folder.'),
('FOLDER_LIMIT','folder_limit','已达到本版本的文件夹数量上限。','The folder limit for this version has been reached.'),
('CONFIRMATION_REQUIRED','confirmation_required','请重新核对当前项目并确认删除。','Review the current item again and confirm deletion.'),
('BUSY','busy','媒体正在被读取或操作队列已满，请关闭预览并稍后重试。','Media is being read or the operation queue is full. Close the preview and try again later.'),
('STORAGE_FAILURE','storage_failure','本地存储暂不可用，操作未确认完成。可刷新核对。','Local storage is unavailable. Completion is unconfirmed. Refresh to check.'),
('RESOURCE_RELEASE_UNCONFIRMED','release_unconfirmed','现有媒体读取尚未确认退出，文件保留等待清理。','Existing media readers have not confirmed release. The file is preserved while cleanup waits.'),
('IDEMPOTENCY_CONFLICT','idempotency_conflict','此操作与已有记录不一致，请刷新核对。','This operation conflicts with an existing record. Refresh to check.'),
('RECOVERY_REQUIRED','recovery_required','媒体库需要恢复检查；文件已保留，不会假报完成。','The library needs a recovery check. Files are preserved; completion has not been confirmed.'),
]
strings={}
for kind,zh,en in fixed:strings['library_core_notice_'+kind.lower()]=(en,zh)
for codes,key,zh,en in errors:strings['library_core_error_'+key]=(en,zh)
strings.update({
'library_core_nonempty_folder':('This folder still contains %1$s and %2$s. Move its contents individually first. Only empty folders can be deleted in this version.','此文件夹仍有 %1$s、%2$s。请先逐项移动内容；本版本只删除空文件夹。'),
'library_core_batch_move_summary':('Per-item move results: moved %1$s; already at destination %2$s; expired %3$s; unavailable %4$s; unconfirmed %5$s; cancelled before start %6$s.','逐项移动结果：已移动 %1$s；原已在目标 %2$s；失效 %3$s；不可用 %4$s；未确认 %5$s；取消后未开始 %6$s。'),
'library_core_location_root':('Location: Library root','位置：媒体库根目录'),
'library_core_location_folder':('Location: %1$s','位置：%1$s'),
'library_core_folder_loading':('Reading folder…','正在读取文件夹…'),
'library_core_move_name':('Move: %1$s','移动：%1$s'),
'library_core_folder_heading':('Folders (%1$s)','文件夹（%1$s）'),
'library_core_folder_contents':('%1$s · %2$s','%1$s · %2$s'),
'library_core_videos':('Videos','视频'),
'library_core_search_results':('Search results in this folder','当前文件夹搜索结果'),
'library_core_empty_folder':('No videos have been added to this folder.','此文件夹暂无已入库视频。'),
'library_core_media_metadata':('MP4 · %1$s · %2$s','MP4 · %1$s · %2$s'),
'library_core_verified_mp4':('Verified local MP4 · %1$s','已验证的本地 MP4 · %1$s'),
'library_core_duration_resolution':('%1$s · %2$s','%1$s · %2$s'),
'library_core_delete_folder':('Delete empty folder…','删除空文件夹…'),
'library_core_delete_video':('Delete local video…','删除本地视频…'),
'library_core_name_label':('Name','名称'),
'library_core_confirm_delete_video':('Permanently delete this local video?','永久删除这个本地视频？'),
'library_core_confirm_delete_folder':('Delete this empty folder?','删除这个空文件夹？'),
'library_core_item_revision':('Item %1$s · Revision %2$s','项目 %1$s · 版本 %2$s'),
})
plurals={
'library_core_videos_count':('%1$s video','%1$s videos','%1$s 个视频'),
'library_core_subfolders_count':('%1$s subfolder','%1$s subfolders','%1$s 个子文件夹'),
'library_core_pending_deletes':('%1$s confirmed deletion is still awaiting cleanup; it is not complete.','%1$s confirmed deletions are still awaiting cleanup; they are not complete.','%1$s 个已确认删除的项目仍待清理；尚未完成。'),
'library_core_video_page':('Page %1$s · Up to %2$s video per page','Page %1$s · Up to %2$s videos per page','第 %1$s 页 · 每页最多 %2$s 个视频'),
}
if __name__ == '__main__':
    for index,folder in enumerate(['values','values-zh-rCN']):
        xml=['<resources>']
        for key,values in strings.items():xml.append(f'    <string name="{key}">{escape(values[index])}</string>')
        for key,(one,other,zh) in plurals.items():
            xml += [f'    <plurals name="{key}">',f'        <item quantity="one">{escape(one if index==0 else zh)}</item>',f'        <item quantity="other">{escape(other if index==0 else zh)}</item>','    </plurals>']
        xml+=['</resources>','']
        write(root/f'app/src/main/res/{folder}/library_core.xml','\n'.join(xml))
    model='''package com.easysavevideo.app.library

import com.easysavevideo.library.BatchMoveItemResult
import com.easysavevideo.library.BatchMoveStatus
import com.easysavevideo.library.LibraryError
import com.easysavevideo.library.LibraryFailure
import com.easysavevideo.library.LibraryNames

/** Locale-independent display facts only; no names, locators, exceptions or operation authority. */
sealed interface LibraryNotice {
    data class Fixed(val kind: LibraryNoticeKind) : LibraryNotice
    data class Failure(val code: LibraryError) : LibraryNotice
    data class NonEmptyFolder(val videos: Int, val subfolders: Int) : LibraryNotice {
        override fun toString() = "LibraryNotice.NonEmptyFolder([redacted])"
    }
    data class BatchMoveSummary(val moved: Int, val alreadyAtTarget: Int, val stale: Int,
        val unavailable: Int, val unconfirmed: Int, val cancelledBeforeStart: Int) : LibraryNotice {
        override fun toString() = "LibraryNotice.BatchMoveSummary([redacted])"
    }
}

enum class LibraryNoticeKind {
'''+''.join(f'    {kind},\n' for kind,_,_ in fixed)+'''}

internal fun libraryFailureNotice(error: LibraryError): LibraryNotice = LibraryNotice.Failure(error)

internal fun libraryNameError(value: String): LibraryNotice? = try {
    LibraryNames.validate(value); null
} catch (_: LibraryFailure) { LibraryNotice.Fixed(LibraryNoticeKind.NAME_REQUIREMENTS) }

internal fun libraryBatchMoveSummary(results: List<BatchMoveItemResult>): LibraryNotice.BatchMoveSummary {
    fun count(status: BatchMoveStatus) = results.count { it.status == status }
    return LibraryNotice.BatchMoveSummary(count(BatchMoveStatus.MOVED), count(BatchMoveStatus.ALREADY_AT_TARGET),
        count(BatchMoveStatus.STALE), count(BatchMoveStatus.UNAVAILABLE),
        count(BatchMoveStatus.FAILED_UNCONFIRMED), count(BatchMoveStatus.CANCELLED_BEFORE_START))
}
'''
    write(base/'LibraryNotice.kt',model)
    resources='''package com.easysavevideo.app.library

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import com.easysavevideo.app.R
import com.easysavevideo.library.LibraryError
import java.util.Locale

/** The same resource adapter is used by current Composition and locale-independent JVM contracts. */
internal interface LibraryTextResources {
    fun text(id: Int, vararg arguments: Any): String
    fun quantity(id: Int, count: Int, vararg arguments: Any): String
}

@Composable
private fun libraryTextResources(): LibraryTextResources {
    // EsvLocaleHost owns the localized context, including API31/32. Read configuration to recompose.
    val configuration = LocalConfiguration.current
    val resources = LocalContext.current.createConfigurationContext(configuration).resources
    return object : LibraryTextResources {
        override fun text(id: Int, vararg arguments: Any) = resources.getString(id, *arguments)
        override fun quantity(id: Int, count: Int, vararg arguments: Any) = resources.getQuantityString(id, count, *arguments)
    }
}

@Composable
internal fun libraryNoticeText(notice: LibraryNotice): String =
    libraryNoticeText(notice, LocalConfiguration.current.locales[0], libraryTextResources())

internal fun libraryNoticeText(notice: LibraryNotice, locale: Locale, resources: LibraryTextResources): String = when (notice) {
    is LibraryNotice.Fixed -> resources.text(libraryFixedNoticeResource(notice.kind))
    is LibraryNotice.Failure -> resources.text(libraryErrorResource(notice.code))
    is LibraryNotice.NonEmptyFolder -> resources.text(R.string.library_core_nonempty_folder,
        resources.quantity(R.plurals.library_core_videos_count, notice.videos, libraryInteger(notice.videos.toLong(), locale)),
        resources.quantity(R.plurals.library_core_subfolders_count, notice.subfolders, libraryInteger(notice.subfolders.toLong(), locale)))
    is LibraryNotice.BatchMoveSummary -> resources.text(R.string.library_core_batch_move_summary,
        *listOf(notice.moved, notice.alreadyAtTarget, notice.stale, notice.unavailable, notice.unconfirmed, notice.cancelledBeforeStart)
            .map { libraryInteger(it.toLong(), locale) }.toTypedArray())
}

@Composable
internal fun libraryFolderContents(videos: Int, subfolders: Int): String =
    libraryFolderContents(videos, subfolders, LocalConfiguration.current.locales[0], libraryTextResources())

internal fun libraryFolderContents(videos: Int, subfolders: Int, locale: Locale, resources: LibraryTextResources): String =
    resources.text(R.string.library_core_folder_contents,
        resources.quantity(R.plurals.library_core_videos_count, videos, libraryInteger(videos.toLong(), locale)),
        resources.quantity(R.plurals.library_core_subfolders_count, subfolders, libraryInteger(subfolders.toLong(), locale)))

internal fun libraryFixedNoticeResource(kind: LibraryNoticeKind): Int = when (kind) {
'''+''.join(f'    LibraryNoticeKind.{kind} -> R.string.library_core_notice_{kind.lower()}\n' for kind,_,_ in fixed)+'''}

internal fun libraryErrorResource(error: LibraryError): Int = when (error) {
'''+''.join('    '+', '.join('LibraryError.'+c for c in codes.split(', '))+f' -> R.string.library_core_error_{key}\n' for codes,key,_,_ in errors)+'''}
'''
    write(base/'LibraryNoticeResources.kt',resources)
    write(base/'LibraryPresentation.kt','''package com.easysavevideo.app.library

import com.easysavevideo.library.MediaItem
import java.text.DateFormat
import java.text.NumberFormat
import java.util.Date
import java.util.Locale

/** Explicit locale arguments keep metadata formatting independent of the process default. */
internal fun libraryInteger(value: Long, locale: Locale): String = NumberFormat.getIntegerInstance(locale).format(value)

internal fun libraryDuration(millis: Long?, unknownLabel: String, locale: Locale = Locale.ROOT): String {
    if (millis == null) return unknownLabel
    val seconds = millis.coerceAtLeast(0) / 1_000
    return String.format(locale, "%02d:%02d:%02d", seconds / 3_600, seconds / 60 % 60, seconds % 60)
}

/** Binary unit symbols are technical notation; numeric fields follow the current UI locale. */
internal fun libraryBytes(bytes: Long, locale: Locale = Locale.ROOT): String = when {
    bytes >= 1_073_741_824 -> String.format(locale, "%.2f GiB", bytes / 1_073_741_824.0)
    bytes >= 1_048_576 -> String.format(locale, "%.1f MiB", bytes / 1_048_576.0)
    bytes >= 1_024 -> String.format(locale, "%.1f KiB", bytes / 1_024.0)
    else -> String.format(locale, "%d B", bytes)
}

internal fun libraryResolution(media: MediaItem, unknownLabel: String, locale: Locale = Locale.ROOT): String =
    if (media.width == null || media.height == null) unknownLabel else String.format(locale, "%d × %d", media.width, media.height)

internal fun libraryDate(media: MediaItem, locale: Locale): String =
    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, locale).format(Date(media.createdAtMillis))
''')
