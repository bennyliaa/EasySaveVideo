# ESV search-report view: context-reconstructed/unverified

All files in this directory are **context-reconstructed/unverified**. This is an isolated transcription of this worker's still-visible, previously executed code-writing tool inputs. It is not a recovered checkout, independently verified original bytes, or a complete restoration of build 3034 or 3049.

## Preserved implementation snapshot

The five source/resource/test files under `app/` represent the latest source state visible to this worker, frozen around 2026-10-17 21:21:39 UTC:

- `app/src/main/kotlin/com/easysavevideo/app/discovery/DiscoverySessionReportPresentation.kt`
- `app/src/main/kotlin/com/easysavevideo/app/ui/DiscoverySessionReportContent.kt`
- `app/src/main/res/values/discovery_session_report.xml`
- `app/src/main/res/values-zh-rCN/discovery_session_report.xml`
- `app/src/test/kotlin/com/easysavevideo/app/discovery/DiscoverySessionReportPresentationTest.kt`

The test file includes the original visible nine `DiscoverySessionReportPresentationTest` methods and two `DiscoverySessionReportResourceContractTest` methods. These are reconstructed test sources, not current passing-test evidence.

Known visible patches already incorporated:

1. Explicit independent upstream search-engine count “not established by this report.”
2. Compact per-provider verification totals plus missing/omitted observations.
3. English Save wording: “Save trials and Save success rates are not collected in this report.”
4. EN/ZH capture bound clarified as the first 500 unique accepted exact pages.
5. Trailing whitespace removal in the presentation Kotlin file.

## Known missing later patches

The parent reports that later main-thread edits changed two English hidden-row strings to count-neutral wording, added hidden-count 0/1/2 boundary coverage, and added seven-control-resource/direct-input tests. Their final patch text and bytes are not visible to this worker. They are **not reconstructed or guessed** here.

Consequently the preserved resource strings and assertions still contain the earlier visible forms:

- `MATERIALIZATION_HIDDEN`: “Showing the last %1$d of %2$d retained observations; %3$d earlier observations are hidden in this view.”
- `OMITTED_ROWS`: “%1$d further rows are hidden by this display limit.”

There may be other parent/integration changes after this worker's freeze that are not visible here. This directory does not include the dialog wrapper, lifecycle owner, controller/screen integration, control-resource file, project dependencies, build scripts, APKs, SDKs, signing material, build logs, or device evidence.

## Verification boundary

No original file SHA-256 values were visible to this worker, so no independent original-byte comparison is possible. Hashes in `manifest.json` identify only these newly transcribed recovery files. They must not be presented as original build-3034 or build-3049 hashes.

The recovery pass performed only local XML parsing, paired resource-key/placeholder checks, source key/count checks, and new-file hashing. It did not build, run JVM/Android tests, contact a network service, access the user's computer, or read denied session paths. Prior historical test/build claims are not proof that this reconstructed snapshot passes now.

`context-reconstruction-helper-fragment.py.txt` is a new helper fragment used for this transcription. It is not an original source artifact or the complete original generator; do not run it as a restoration script, because its presentation output contains only the file header and enum. The complete presentation body was separately transcribed into the Kotlin file.

Review and reconcile with independently recovered originals and missing patches before any integration or build.
