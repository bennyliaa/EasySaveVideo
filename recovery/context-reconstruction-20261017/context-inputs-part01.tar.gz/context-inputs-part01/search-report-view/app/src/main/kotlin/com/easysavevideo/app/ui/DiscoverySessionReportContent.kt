package com.easysavevideo.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import com.easysavevideo.app.discovery.DiscoverySessionReportPresentationPolicy
import com.easysavevideo.app.discovery.DiscoverySessionReportText
import com.easysavevideo.app.theme.EsvText
import com.easysavevideo.app.theme.LocalEsvVisuals
import com.easysavevideo.discovery.DiscoverySessionMetrics
import java.util.Locale

/** Display only. The owning dialog provides scrolling, refresh, dismissal and session fencing. */
@Composable
internal fun DiscoverySessionReportContent(metrics: DiscoverySessionMetrics, demo: Boolean) {
    val visuals = LocalEsvVisuals.current
    val resources = LocalContext.current.resources
    // Locale is read on every composition, so the same snapshot can be reformatted without work.
    val locale = LocalConfiguration.current.locales[0] ?: Locale.getDefault()
    val text = DiscoverySessionReportText { key, arguments -> resources.getString(key.resource, *arguments) }
    val report = DiscoverySessionReportPresentationPolicy.present(metrics, demo, text, locale)
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(visuals.spacingSmall)) {
        report.notices.forEach { EsvText(it, style = visuals.captionTextStyle) }
        report.sections.forEach { section ->
            EsvText(section.title,
                modifier = Modifier.fillMaxWidth().padding(top = visuals.spacingMedium).semantics { heading() },
                style = visuals.sectionTextStyle)
            section.lines.forEach { line ->
                EsvText(line, modifier = Modifier.fillMaxWidth(), style = visuals.bodyTextStyle)
            }
        }
    }
}
