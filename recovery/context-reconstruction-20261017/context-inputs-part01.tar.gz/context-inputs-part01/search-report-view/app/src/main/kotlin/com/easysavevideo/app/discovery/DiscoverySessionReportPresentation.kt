package com.easysavevideo.app.discovery

import com.easysavevideo.app.R
import com.easysavevideo.discovery.*
import java.text.NumberFormat
import java.util.Locale

/** Closed copy keys and count/enum-only presentation. No coordinator, store, network or inventory. */
enum class DiscoverySessionReportCopy(val resource: Int) {
    SCOPE(R.string.discovery_session_report_scope),
    DEMO(R.string.discovery_session_report_demo),
    SAVE_NOTICE(R.string.discovery_session_report_save_notice),
    OVERVIEW(R.string.discovery_session_report_overview),
    PAGES(R.string.discovery_session_report_pages),
    HOSTNAMES(R.string.discovery_session_report_hostnames),
    HOSTNAME_NOTE(R.string.discovery_session_report_hostname_note),
    ELAPSED(R.string.discovery_session_report_elapsed),
    FIRST_AVAILABLE(R.string.discovery_session_report_first_available),
    FIRST_VISIBLE(R.string.discovery_session_report_first_visible),
    TIMING_NOTE(R.string.discovery_session_report_timing_note),
    REQUESTS(R.string.discovery_session_report_requests),
    CAPTURE_COMPLETE(R.string.discovery_session_report_capture_complete),
    CAPTURE_INCOMPLETE(R.string.discovery_session_report_capture_incomplete),
    UNRETAINED(R.string.discovery_session_report_unretained),
    UPSTREAM_UNKNOWN(R.string.discovery_session_report_upstream_unknown),
    PROVIDER_VERIFICATION(R.string.discovery_session_report_provider_verification),
    PROVIDERS(R.string.discovery_session_report_providers),
    PROVIDER_NOTE(R.string.discovery_session_report_provider_note),
    NO_PROVIDERS(R.string.discovery_session_report_no_providers),
    PROVIDER(R.string.discovery_session_report_provider),
    UNKNOWN_PROVIDER(R.string.discovery_session_report_unknown_provider),
    SOURCE_LANE(R.string.discovery_session_report_source_lane),
    VALIDATION_LANE(R.string.discovery_session_report_validation_lane),
    LANE_COUNTS(R.string.discovery_session_report_lane_counts),
    LANE_LATENCY(R.string.discovery_session_report_lane_latency),
    LANE_OUTPUT(R.string.discovery_session_report_lane_output),
    LANE_ERRORS(R.string.discovery_session_report_lane_errors),
    LANE_NOTE(R.string.discovery_session_report_lane_note),
    RAW(R.string.discovery_session_report_raw),
    ADAPTER_RETURN(R.string.discovery_session_report_adapter_return),
    ATTRIBUTION(R.string.discovery_session_report_attribution),
    ATTRIBUTION_NOTE(R.string.discovery_session_report_attribution_note),
    CATEGORY(R.string.discovery_session_report_category),
    CATEGORY_UNKNOWN(R.string.discovery_session_report_category_unknown),
    ENGINE_SECTION(R.string.discovery_session_report_engine_section),
    ENGINE_NOTE(R.string.discovery_session_report_engine_note),
    VERIFICATION_TOTALS(R.string.discovery_session_report_verification_totals),
    VERIFICATION_MISSING(R.string.discovery_session_report_verification_missing),
    VERIFICATION_OMITTED(R.string.discovery_session_report_verification_omitted),
    NO_ENGINES(R.string.discovery_session_report_no_engines),
    ENGINE(R.string.discovery_session_report_engine),
    UNKNOWN_ENGINE(R.string.discovery_session_report_unknown_engine),
    ENGINE_DESCRIPTOR(R.string.discovery_session_report_engine_descriptor),
    ENGINE_COUNTS(R.string.discovery_session_report_engine_counts),
    ENGINE_OUTCOMES(R.string.discovery_session_report_engine_outcomes),
    ENGINE_EVIDENCE(R.string.discovery_session_report_engine_evidence),
    ENGINE_CONSUMPTION(R.string.discovery_session_report_engine_consumption),
    ENGINE_BUDGET(R.string.discovery_session_report_engine_budget),
    BUDGET_NOTE(R.string.discovery_session_report_budget_note),
    CONTRIBUTORS(R.string.discovery_session_report_contributors),
    CONTRIBUTOR_NOTE(R.string.discovery_session_report_contributor_note),
    CONTRIBUTOR_UNOBSERVED(R.string.discovery_session_report_contributor_unobserved),
    CONTRIBUTOR_PAGES(R.string.discovery_session_report_contributor_pages),
    CONTRIBUTOR_COMPLETE(R.string.discovery_session_report_contributor_complete),
    CONTRIBUTOR_INCOMPLETE(R.string.discovery_session_report_contributor_incomplete),
    CONTRIBUTOR_HISTORY(R.string.discovery_session_report_contributor_history),
    CONTRIBUTOR_OMITTED(R.string.discovery_session_report_contributor_omitted),
    CONTRIBUTOR_PROVIDER(R.string.discovery_session_report_contributor_provider),
    CONTRIBUTOR_COUNTS(R.string.discovery_session_report_contributor_counts),
    CONTRIBUTOR_FLAGS(R.string.discovery_session_report_contributor_flags),
    CONTRIBUTOR_COVERAGE(R.string.discovery_session_report_contributor_coverage),
    CONTRIBUTOR_NO_LABELS(R.string.discovery_session_report_contributor_no_labels),
    MATERIALIZATIONS(R.string.discovery_session_report_materializations),
    MATERIALIZATION_NOTE(R.string.discovery_session_report_materialization_note),
    MATERIALIZATION(R.string.discovery_session_report_materialization),
    MATERIALIZATION_HIDDEN(R.string.discovery_session_report_materialization_hidden),
    NO_MATERIALIZATIONS(R.string.discovery_session_report_no_materializations),
    MS(R.string.discovery_session_report_ms),
    UNOBSERVED(R.string.discovery_session_report_unobserved),
    NONE(R.string.discovery_session_report_none),
    OMITTED_ROWS(R.string.discovery_session_report_omitted_rows);
}

fun interface DiscoverySessionReportText {
    fun render(key: DiscoverySessionReportCopy, arguments: Array<out Any>): String
    fun get(key: DiscoverySessionReportCopy, vararg arguments: Any): String = render(key, arguments)
}

data class DiscoverySessionReportSection(val title: String, val lines: List<String>)
data class DiscoverySessionReportPresentation(val notices: List<String>, val sections: List<DiscoverySessionReportSection>)

/** Pure formatting of one detached snapshot. Unknown strings never pass through to the UI. */
object DiscoverySessionReportPresentationPolicy {
    const val DISPLAYED_PAGE_OBSERVATIONS = 20
    private const val MAX_PROVIDER_ROWS = 32
    private const val MAX_ENGINE_ROWS = 16
    private val nativeProviderIds = setOf("wikimedia-commons", "local-demo", "searxng-1", "searxng-2", "searxng-3")
    private val nativeEngineIds = setOf("android-local", "optional-scrapling-service")

    fun present(metrics: DiscoverySessionMetrics, demo: Boolean, text: DiscoverySessionReportText,
                locale: Locale): DiscoverySessionReportPresentation {
        val f = Formatter(text, locale)
        val sections = mutableListOf<DiscoverySessionReportSection>()
        sections += DiscoverySessionReportSection(text.get(DiscoverySessionReportCopy.OVERVIEW), buildList {
            add(text.get(DiscoverySessionReportCopy.PAGES, metrics.uniqueDiscoveredPages, metrics.uniqueConfirmedResults, metrics.uniquePendingCandidates))
            add(text.get(DiscoverySessionReportCopy.HOSTNAMES, metrics.distinctDiscoveredHostnames, metrics.distinctConfirmedHostnames, metrics.distinctPendingHostnames))
            add(text.get(DiscoverySessionReportCopy.HOSTNAME_NOTE))
            add(text.get(DiscoverySessionReportCopy.ELAPSED, f.duration(metrics.elapsedMillis)))
            add(text.get(DiscoverySessionReportCopy.FIRST_AVAILABLE, f.duration(metrics.firstConfirmedAvailableElapsedMillis)))
            add(text.get(DiscoverySessionReportCopy.FIRST_VISIBLE, f.duration(metrics.firstConfirmedVisibleElapsedMillis)))
            add(text.get(DiscoverySessionReportCopy.TIMING_NOTE))
            add(text.get(DiscoverySessionReportCopy.REQUESTS, metrics.explicitRequestMoreCount, metrics.maximumInFlightAttempts))
            add(text.get(DiscoverySessionReportCopy.UPSTREAM_UNKNOWN))
            add(text.get(if (metrics.exactPageCaptureComplete) DiscoverySessionReportCopy.CAPTURE_COMPLETE else DiscoverySessionReportCopy.CAPTURE_INCOMPLETE))
            add(text.get(DiscoverySessionReportCopy.UNRETAINED, metrics.unretainedExactPageObservations))
        })
        sections += DiscoverySessionReportSection(text.get(DiscoverySessionReportCopy.PROVIDERS), buildList {
            add(text.get(DiscoverySessionReportCopy.PROVIDER_NOTE))
            add(text.get(DiscoverySessionReportCopy.LANE_NOTE))
            add(text.get(DiscoverySessionReportCopy.ATTRIBUTION_NOTE))
            if (metrics.providerMetrics.isEmpty()) add(text.get(DiscoverySessionReportCopy.NO_PROVIDERS))
        })
        metrics.providerMetrics.take(MAX_PROVIDER_ROWS).forEachIndexed { index, provider ->
            sections += DiscoverySessionReportSection(f.providerName(provider.providerId, index), buildList {
                addAll(f.lane(provider.sourceMetrics, DiscoverySessionReportCopy.SOURCE_LANE))
                addAll(f.lane(provider.validationMetrics, DiscoverySessionReportCopy.VALIDATION_LANE))
                add(text.get(DiscoverySessionReportCopy.RAW,
                    f.knownCount(provider.rawResponseItemCount, provider.pagesWithKnownRawResponseItemCount),
                    provider.pagesWithKnownRawResponseItemCount, provider.pagesWithUnknownRawResponseItemCount))
                add(text.get(DiscoverySessionReportCopy.ADAPTER_RETURN, provider.providerReturnedItemCount))
                add(text.get(DiscoverySessionReportCopy.ATTRIBUTION, provider.attributedConfirmedResults, provider.attributedPendingCandidates,
                    provider.attributedDiscoveredHostnames, provider.attributedConfirmedHostnames, provider.attributedPendingHostnames))
                provider.sourceCategoryMetrics.take(ProviderSearchCategory.entries.size).forEach { category ->
                    add(text.get(DiscoverySessionReportCopy.CATEGORY, category.category.name, category.observedPages, f.codes(category.statuses)))
                }
                add(text.get(DiscoverySessionReportCopy.CATEGORY_UNKNOWN, provider.completedSourceAttemptsWithoutCategoryObservation))
                add(text.get(DiscoverySessionReportCopy.PROVIDER_VERIFICATION))
                val observed = provider.verificationMetrics
                add(text.get(DiscoverySessionReportCopy.VERIFICATION_TOTALS, observed.reportedValidationCount, observed.recordedEngineInvocations))
                add(text.get(DiscoverySessionReportCopy.VERIFICATION_MISSING, observed.validationsWithoutAttemptTrace,
                    observed.validationTracesWithNoEngineInvocation, observed.pipelineTerminationsWithoutVerificationObservation))
                add(text.get(DiscoverySessionReportCopy.VERIFICATION_OMITTED, observed.omittedEngineInvocations, observed.engineRowOverflowInvocations))
            })
        }
        f.appendOmission(sections, metrics.providerMetrics.size, MAX_PROVIDER_ROWS)
        val verification = metrics.verificationMetrics
        sections += DiscoverySessionReportSection(text.get(DiscoverySessionReportCopy.ENGINE_SECTION), buildList {
            add(text.get(DiscoverySessionReportCopy.ENGINE_NOTE))
            add(text.get(DiscoverySessionReportCopy.BUDGET_NOTE))
            add(text.get(DiscoverySessionReportCopy.VERIFICATION_TOTALS, verification.reportedValidationCount, verification.recordedEngineInvocations))
            add(text.get(DiscoverySessionReportCopy.VERIFICATION_MISSING, verification.validationsWithoutAttemptTrace,
                verification.validationTracesWithNoEngineInvocation, verification.pipelineTerminationsWithoutVerificationObservation))
            add(text.get(DiscoverySessionReportCopy.VERIFICATION_OMITTED, verification.omittedEngineInvocations, verification.engineRowOverflowInvocations))
            if (verification.engineMetrics.isEmpty()) add(text.get(DiscoverySessionReportCopy.NO_ENGINES))
        })
        verification.engineMetrics.take(MAX_ENGINE_ROWS).forEachIndexed { index, engine ->
            sections += DiscoverySessionReportSection(text.get(DiscoverySessionReportCopy.ENGINE, index + 1,
                engine.engineId.takeIf { it in nativeEngineIds } ?: text.get(DiscoverySessionReportCopy.UNKNOWN_ENGINE)), listOf(
                text.get(DiscoverySessionReportCopy.ENGINE_DESCRIPTOR,
                    engine.capabilities.sortedBy { it.ordinal }.joinToString { it.name }.ifEmpty { text.get(DiscoverySessionReportCopy.NONE) }, engine.accessBoundary.name),
                text.get(DiscoverySessionReportCopy.ENGINE_COUNTS, engine.recordedInvocations, f.duration(engine.totalInvocationElapsedMillis), f.duration(engine.maximumInvocationElapsedMillis)),
                text.get(DiscoverySessionReportCopy.ENGINE_OUTCOMES, f.codes(engine.outcomes)),
                text.get(DiscoverySessionReportCopy.ENGINE_EVIDENCE, f.codes(engine.evidence)),
                text.get(DiscoverySessionReportCopy.ENGINE_CONSUMPTION, engine.invocationsWithKnownConsumption, engine.invocationsWithUnknownConsumption),
                text.get(DiscoverySessionReportCopy.ENGINE_BUDGET,
                    f.knownCount(engine.engineReportedRequestBudgetConsumed, engine.invocationsWithKnownConsumption),
                    f.knownCount(engine.engineReportedByteBudgetConsumed, engine.invocationsWithKnownConsumption)),
            ))
        }
        f.appendOmission(sections, verification.engineMetrics.size, MAX_ENGINE_ROWS)
        sections += DiscoverySessionReportSection(text.get(DiscoverySessionReportCopy.CONTRIBUTORS), buildList {
            add(text.get(DiscoverySessionReportCopy.CONTRIBUTOR_NOTE))
            val reports = metrics.endpointReportedSearchContributors
            if (reports == null) add(text.get(DiscoverySessionReportCopy.CONTRIBUTOR_UNOBSERVED)) else {
                add(text.get(DiscoverySessionReportCopy.CONTRIBUTOR_PAGES, reports.acceptedPagesWithReports))
                add(text.get(if (reports.captureIncomplete) DiscoverySessionReportCopy.CONTRIBUTOR_INCOMPLETE else DiscoverySessionReportCopy.CONTRIBUTOR_COMPLETE))
                if (reports.historyUnobserved) add(text.get(DiscoverySessionReportCopy.CONTRIBUTOR_HISTORY))
                add(text.get(DiscoverySessionReportCopy.CONTRIBUTOR_OMITTED, reports.unretainedReportObservations))
                reports.providers.take(MAX_PROVIDER_ROWS).forEach { provider ->
                    val index = metrics.providerMetrics.indexOfFirst { it.providerId == provider.providerId }
                    val name = if (index >= 0) f.providerName(provider.providerId, index) else text.get(DiscoverySessionReportCopy.UNKNOWN_PROVIDER)
                    add(text.get(DiscoverySessionReportCopy.CONTRIBUTOR_PROVIDER, name, provider.acceptedPageCount))
                    val counts = provider.observations
                    add(text.get(DiscoverySessionReportCopy.CONTRIBUTOR_COUNTS, counts.reportObservationCount,
                        counts.unreportedObservationCount, counts.invalidObservationCount, counts.unrecognizedObservationCount, counts.omittedObservationCount))
                    add(text.get(DiscoverySessionReportCopy.CONTRIBUTOR_FLAGS,
                        counts.flags.sortedBy { it.ordinal }.joinToString { it.name }.ifEmpty { text.get(DiscoverySessionReportCopy.NONE) }))
                    if (provider.acceptedPageCoverage.isEmpty()) add(text.get(DiscoverySessionReportCopy.CONTRIBUTOR_NO_LABELS))
                    provider.acceptedPageCoverage.toSortedMap(compareBy { it.ordinal }).forEach { (id, pages) ->
                        add(text.get(DiscoverySessionReportCopy.CONTRIBUTOR_COVERAGE, id.technicalId, pages))
                    }
                }
                if (reports.providers.size > MAX_PROVIDER_ROWS) add(text.get(DiscoverySessionReportCopy.OMITTED_ROWS, reports.providers.size - MAX_PROVIDER_ROWS))
            }
        })
        sections += DiscoverySessionReportSection(text.get(DiscoverySessionReportCopy.MATERIALIZATIONS), buildList {
            add(text.get(DiscoverySessionReportCopy.MATERIALIZATION_NOTE))
            val pages = metrics.materializedPages
            if (pages.isEmpty()) add(text.get(DiscoverySessionReportCopy.NO_MATERIALIZATIONS))
            val hidden = (pages.size - DISPLAYED_PAGE_OBSERVATIONS).coerceAtLeast(0)
            if (hidden > 0) add(text.get(DiscoverySessionReportCopy.MATERIALIZATION_HIDDEN, DISPLAYED_PAGE_OBSERVATIONS, pages.size, hidden))
            pages.takeLast(DISPLAYED_PAGE_OBSERVATIONS).forEachIndexed { index, page ->
                add(text.get(DiscoverySessionReportCopy.MATERIALIZATION, hidden + index + 1, page.pageIndex, page.resultCount, f.duration(page.elapsedMillis)))
            }
        })
        return DiscoverySessionReportPresentation(buildList {
            add(text.get(DiscoverySessionReportCopy.SCOPE))
            if (demo) add(text.get(DiscoverySessionReportCopy.DEMO))
            add(text.get(DiscoverySessionReportCopy.SAVE_NOTICE))
        }, sections.toList())
    }

    private class Formatter(val text: DiscoverySessionReportText, locale: Locale) {
        private val numbers = NumberFormat.getIntegerInstance(locale)
        fun duration(value: Long?): String = value?.let { text.get(DiscoverySessionReportCopy.MS, it) }
            ?: text.get(DiscoverySessionReportCopy.UNOBSERVED)
        fun knownCount(value: Long, knownObservations: Long): String = if (knownObservations > 0) numbers.format(value)
            else text.get(DiscoverySessionReportCopy.UNOBSERVED)
        fun providerName(id: String, index: Int): String = text.get(DiscoverySessionReportCopy.PROVIDER, index + 1,
            id.takeIf { it in nativeProviderIds } ?: text.get(DiscoverySessionReportCopy.UNKNOWN_PROVIDER))
        fun <E : Enum<E>> codes(counts: Map<E, Long>): String = counts.entries.sortedBy { it.key.ordinal }
            .joinToString { "${it.key.name}: ${numbers.format(it.value)}" }.ifEmpty { text.get(DiscoverySessionReportCopy.NONE) }
        fun lane(value: DiscoveryAttemptMetrics, label: DiscoverySessionReportCopy): List<String> {
            val name = text.get(label)
            val errorCount = value.errors.values.fold(0L) { total, count -> total + count.coerceIn(0, Long.MAX_VALUE - total) }
            return buildList {
                add(text.get(DiscoverySessionReportCopy.LANE_COUNTS, name, value.attempts, value.completedAttempts,
                    value.pipelineCompletedAttempts, errorCount, value.cancelledAttempts))
                add(text.get(DiscoverySessionReportCopy.LANE_LATENCY, name,
                    duration(value.totalAttemptElapsedMillis.takeIf { value.completedAttempts > 0 }),
                    duration(value.maximumAttemptElapsedMillis.takeIf { value.completedAttempts > 0 }), duration(value.lastAttemptElapsedMillis)))
                add(text.get(DiscoverySessionReportCopy.LANE_OUTPUT, name, value.validatedConfirmedItemCount, value.validatedPendingItemCount))
                if (value.errors.isNotEmpty()) add(text.get(DiscoverySessionReportCopy.LANE_ERRORS, name, codes(value.errors)))
            }
        }
        fun appendOmission(sections: MutableList<DiscoverySessionReportSection>, size: Int, limit: Int) {
            if (size > limit) {
                val last = sections.last()
                sections[sections.lastIndex] = last.copy(lines = last.lines + text.get(DiscoverySessionReportCopy.OMITTED_ROWS, size - limit))
            }
        }
    }
}
