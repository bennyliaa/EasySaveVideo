package com.easysavevideo.app.discovery

import com.easysavevideo.core.model.EpochClock
import com.easysavevideo.discovery.*
import java.io.File
import java.util.Locale
import javax.xml.parsers.DocumentBuilderFactory
import org.junit.Assert.*
import org.junit.Test

private fun reportResourceRoot() = listOf(File("src/main/res"), File("app/src/main/res")).first { it.isDirectory }
private fun reportStrings(folder: String): Map<String, String> {
    val factory = DocumentBuilderFactory.newInstance()
    factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
    val nodes = factory.newDocumentBuilder().parse(File(reportResourceRoot(), "$folder/discovery_session_report.xml"))
        .getElementsByTagName("string")
    return (0 until nodes.length).associate { index ->
        val node = nodes.item(index)
        node.attributes.getNamedItem("name").nodeValue to node.textContent.replace("\\'", "'")
    }.also { assertEquals("No duplicate resource names", nodes.length, it.size) }
}
private fun reportText(folder: String): DiscoverySessionReportText {
    val strings = reportStrings(folder)
    return DiscoverySessionReportText { key, arguments -> String.format(
        if (folder == "values") Locale.US else Locale.SIMPLIFIED_CHINESE,
        strings.getValue("discovery_session_report_${key.name.lowercase(Locale.ROOT)}"), *arguments) }
}
private fun DiscoverySessionReportPresentation.allText(): String =
    (notices + sections.flatMap { listOf(it.title) + it.lines }).joinToString("\n")

class DiscoverySessionReportPresentationTest {
    private val noVerification = DiscoveryVerificationMetrics(0, 0, 0, 0, 0, 0, 0, emptyList())
    private val noLane = DiscoveryAttemptMetrics(0, 0, 0, 0, emptyMap(), 0, 0, null, 0, 0)
    private fun metrics() = DiscoverySessionMetrics(
        elapsedMillis = 999, firstConfirmedAvailableElapsedMillis = null, firstConfirmedVisibleElapsedMillis = null,
        uniqueConfirmedResults = 0, uniquePendingCandidates = 0, uniqueDiscoveredPages = 0,
        explicitRequestMoreCount = 0, maximumInFlightAttempts = 0, providerMetrics = emptyList(), materializedPages = emptyList(),
        distinctDiscoveredHostnames = 0, distinctConfirmedHostnames = 0, distinctPendingHostnames = 0,
        verificationMetrics = noVerification, exactPageCaptureComplete = true, unretainedExactPageObservations = 0,
    )
    private fun provider(id: String = "searxng-1", source: DiscoveryAttemptMetrics = noLane,
                         validation: DiscoveryAttemptMetrics = noLane) = DiscoveryProviderMetrics(
        providerId = id, searchRequestAttempts = source.attempts, candidateValidationAttempts = validation.attempts,
        totalCompletedAttempts = 0, totalPipelineCompletedAttempts = 0, totalCancelledAttempts = 0, totalErrors = emptyMap(),
        totalAttemptElapsedMillis = 0, maximumAttemptElapsedMillis = 0, lastAttemptElapsedMillis = null,
        providerReturnedItemCount = 11, rawResponseItemCount = 29, pagesWithKnownRawResponseItemCount = 1,
        pagesWithUnknownRawResponseItemCount = 2, totalValidatedConfirmedItemCount = 0, totalValidatedPendingItemCount = 0,
        attributedConfirmedResults = 2, attributedPendingCandidates = 3, attributedDiscoveredHostnames = 4,
        attributedConfirmedHostnames = 2, attributedPendingHostnames = 3,
        sourceMetrics = source, validationMetrics = validation, verificationMetrics = noVerification,
        sourceCategoryMetrics = listOf(DiscoveryCategoryMetrics(ProviderSearchCategory.VIDEOS, 1,
            mapOf(ProviderCategoryStatus.UNREPORTED to 1L))), completedSourceAttemptsWithoutCategoryObservation = 3,
    )
    private fun engine(id: String = "android-local") = DiscoveryVerificationEngineMetrics(
        id, setOf(EngineCapability.STATIC_PAGE), EngineAccessBoundary.LOCAL_TARGET, 3,
        mapOf(EngineOutcome.DENIED to 2L, EngineOutcome.UNKNOWN to 1L), mapOf(EngineEvidence.NONE to 3L),
        100, 90, 0, 3, 0, 0,
    )
    private fun present(value: DiscoverySessionMetrics, folder: String = "values", demo: Boolean = false) =
        DiscoverySessionReportPresentationPolicy.present(value, demo, reportText(folder),
            if (folder == "values") Locale.US else Locale.SIMPLIFIED_CHINESE)

    @Test fun noSourcesNullTimingsAndMissingEngineObservationsStayExplicit() {
        for (folder in listOf("values", "values-zh-rCN")) {
            val text = reportText(folder)
            val report = present(metrics(), folder)
            val all = report.allText()
            assertTrue(all.contains(text.get(DiscoverySessionReportCopy.FIRST_AVAILABLE, text.get(DiscoverySessionReportCopy.UNOBSERVED))))
            assertTrue(all.contains(text.get(DiscoverySessionReportCopy.FIRST_VISIBLE, text.get(DiscoverySessionReportCopy.UNOBSERVED))))
            for (key in listOf(DiscoverySessionReportCopy.NO_PROVIDERS, DiscoverySessionReportCopy.NO_ENGINES,
                DiscoverySessionReportCopy.NO_MATERIALIZATIONS, DiscoverySessionReportCopy.UPSTREAM_UNKNOWN,
                DiscoverySessionReportCopy.CONTRIBUTOR_UNOBSERVED, DiscoverySessionReportCopy.SAVE_NOTICE)) assertTrue(all.contains(text.get(key)))
            assertFalse(all.contains(text.get(DiscoverySessionReportCopy.DEMO)))
            assertFalse(all.contains("%"))
        }
    }

    @Test fun sourceAndCandidateValidationNeverBorrowAggregateCountsOrLatency() {
        val source = noLane.copy(attempts = 8, completedAttempts = 7, pipelineCompletedAttempts = 4,
            cancelledAttempts = 1, errors = mapOf(DiscoveryError.DEADLINE_EXCEEDED to 2L),
            totalAttemptElapsedMillis = 130, maximumAttemptElapsedMillis = 70, lastAttemptElapsedMillis = 20,
            validatedConfirmedItemCount = 5, validatedPendingItemCount = 6)
        val validation = noLane.copy(attempts = 10, completedAttempts = 9, pipelineCompletedAttempts = 8,
            cancelledAttempts = 0, errors = mapOf(DiscoveryError.INVALID_RESULT to 1L),
            totalAttemptElapsedMillis = 410, maximumAttemptElapsedMillis = 80, lastAttemptElapsedMillis = 50,
            validatedConfirmedItemCount = 2, validatedPendingItemCount = 7)
        val value = metrics().copy(providerMetrics = listOf(provider(source = source, validation = validation)))
        val output = present(value).allText()
        assertTrue(output.contains("SOURCE: attempts 8 · finished 7 · pipeline completed 4 · errors 2 · cancelled 1"))
        assertTrue(output.contains("CANDIDATE_VALIDATION: attempts 10 · finished 9 · pipeline completed 8 · errors 1 · cancelled 0"))
        assertTrue(output.contains("SOURCE elapsed: total 130 ms · max 70 ms · last 20 ms"))
        assertTrue(output.contains("CANDIDATE_VALIDATION elapsed: total 410 ms · max 80 ms · last 50 ms"))
        assertTrue(output.contains("DEADLINE_EXCEEDED: 2"))
        assertTrue(output.contains("INVALID_RESULT: 1"))
        assertTrue(output.contains("raw response items (known pages only): 29 · known-count pages: 1 · unknown-count pages: 2"))
        assertTrue(output.contains("SOURCE adapter-return items: 11"))
        assertTrue(output.contains("Verification observations scheduled under this source"))
    }

    @Test fun unknownRawCountsAndBudgetConsumptionCannotBecomeFalseZeroMeasurements() {
        val unknownRaw = provider().copy(pagesWithKnownRawResponseItemCount = 0, rawResponseItemCount = 0)
        val verification = noVerification.copy(reportedValidationCount = 4, validationsWithoutAttemptTrace = 1,
            recordedEngineInvocations = 3, omittedEngineInvocations = 2, engineRowOverflowInvocations = 1,
            engineMetrics = listOf(engine()))
        val value = metrics().copy(providerMetrics = listOf(unknownRaw), verificationMetrics = verification)
        val output = present(value).allText()
        assertTrue(output.contains("raw response items (known pages only): Unobserved"))
        assertTrue(output.contains("request-budget units: Unobserved · byte-budget units: Unobserved"))
        assertTrue(output.contains("known budget consumption: 0 · unknown: 3"))
        assertTrue(output.contains("Validations without trace: 1"))
        assertTrue(output.contains("Invocations omitted from traces: 2 · recorded invocations without an engine row: 1"))
        assertTrue(output.contains("not measured HTTP requests or transferred bytes"))
        assertTrue(output.contains("DENIED: 2"))
        val knownZero = engine().copy(invocationsWithKnownConsumption = 1, invocationsWithUnknownConsumption = 2)
        val zero = present(value.copy(verificationMetrics = verification.copy(engineMetrics = listOf(knownZero)))).allText()
        assertTrue(zero.contains("request-budget units: 0 · byte-budget units: 0"))
    }

    @Test fun overlappingAttributionNeverReplacesUniqueTotalsAndIncompleteCaptureIsProminent() {
        val value = metrics().copy(uniqueConfirmedResults = 2, uniquePendingCandidates = 3, uniqueDiscoveredPages = 5,
            distinctDiscoveredHostnames = 4, distinctConfirmedHostnames = 2, distinctPendingHostnames = 3,
            providerMetrics = listOf(provider(), provider("searxng-2")), exactPageCaptureComplete = false,
            unretainedExactPageObservations = 9)
        val output = present(value).allText()
        assertTrue(output.contains("Retained unique exact pages: 5 · confirmed: 2 · pending: 3"))
        assertTrue(output.contains("Exact normalized hostnames: 4 · confirmed: 2 · pending: 3"))
        assertTrue(output.contains("Exact-page capture is incomplete"))
        assertTrue(output.contains("Unretained exact-page observations: 9"))
        assertTrue(output.contains("Provider attribution overlaps"))
        assertTrue(output.contains("www and other subdomains stay distinct"))
        assertFalse(output.contains("Exact-page capture: complete"))
    }

    @Test fun identifiersAreNativeAllowlistedAndUnknownStringsNeverReachPresentation() {
        val secret = "https://secret.invalid/title?query=private user data\nexception"
        val value = metrics().copy(providerMetrics = listOf(provider(secret), provider("harmless-looking-private-id")),
            verificationMetrics = noVerification.copy(engineMetrics = listOf(engine(secret), engine("private-engine"))))
        for (folder in listOf("values", "values-zh-rCN")) {
            val output = present(value, folder).allText()
            for (privateString in listOf(secret, "secret.invalid", "harmless-looking-private-id", "private-engine"))
                assertFalse(output.contains(privateString))
            assertTrue(output.contains(reportText(folder).get(DiscoverySessionReportCopy.UNKNOWN_PROVIDER)))
            assertTrue(output.contains(reportText(folder).get(DiscoverySessionReportCopy.UNKNOWN_ENGINE)))
        }
        assertTrue(present(metrics().copy(providerMetrics = listOf(provider()))).allText().contains("searxng-1"))
    }

    @Test fun pageMaterializationsKeepRepeatedIndexesAndExplicitlyLimitDisplayOnly() {
        val pages = (0 until 500).map { DiscoveryMaterializedPageMetrics(it % 2, it + 1, it.toLong()) }
        val value = metrics().copy(materializedPages = pages, firstConfirmedAvailableElapsedMillis = 0, firstConfirmedVisibleElapsedMillis = 12)
        val report = present(value)
        val pageSection = report.sections.last()
        assertEquals(20, pageSection.lines.count { it.startsWith("Observation ") })
        assertTrue(pageSection.lines.any { it.startsWith("Observation 481 · page index 0") })
        assertTrue(pageSection.lines.any { it.startsWith("Observation 500 · page index 1") })
        assertTrue(pageSection.lines.any { it.contains("Showing the last 20 of 500 retained observations; 480 earlier") })
        assertTrue(report.allText().contains("First confirmed result available: 0 ms"))
        assertTrue(report.allText().contains("First accepted UI SHOWN event: 12 ms"))
        assertEquals(500, value.materializedPages.size)
    }

    @Test fun everyRefreshFormatsOnlyItsOwnSnapshotAndLanguageSwitchHasNoAccumulation() {
        val first = metrics().copy(uniqueDiscoveredPages = 1, uniqueConfirmedResults = 1)
        val second = metrics().copy(uniqueDiscoveredPages = 2, uniqueConfirmedResults = 2)
        val firstReport = present(first)
        val secondReport = present(second)
        assertEquals(firstReport, present(first))
        assertEquals(secondReport, present(second))
        assertTrue(secondReport.allText().contains("Retained unique exact pages: 2 · confirmed: 2 · pending: 0"))
        assertTrue(present(second, "values-zh-rCN").allText().contains("已保留的唯一精确页面：2"))
        assertEquals(firstReport, present(first))
        assertTrue(present(first, demo = true).notices.contains(reportText("values").get(DiscoverySessionReportCopy.DEMO)))
    }

    @Test fun excessiveDisplayRowsAreBoundedAndOmissionsRemainExplicit() {
        val value = metrics().copy(providerMetrics = (0 until 40).map { provider("private-$it") },
            verificationMetrics = noVerification.copy(engineMetrics = (0 until 20).map { engine("private-$it") }))
        val report = present(value)
        assertEquals(32, report.sections.count { it.title.startsWith("Source ") && !it.title.startsWith("Source adapters") })
        assertEquals(16, report.sections.count { it.title.startsWith("Engine ") })
        assertTrue(report.allText().contains("8 further rows are hidden"))
        assertTrue(report.allText().contains("4 further rows are hidden"))
    }

    @Test fun endpointReportedContributorsStayClaimsWithClosedLabelsAndUncertainty() {
        val clock = EpochClock { 1_000L }
        var completion: (() -> Unit)? = null
        val source = object : VideoSearchProvider {
            override val descriptor = ProviderDescriptor("searxng-1", "1")
            override fun search(request: SearchRequest, operation: DiscoveryOperation): ProviderPage = error("No network")
        }
        val runtime = object : ProviderRuntime {
            override fun execute(provider: VideoSearchProvider, request: SearchRequest, operation: DiscoveryOperation,
                                 callback: (ProviderOutcome) -> Unit): CancellationHandle {
                completion = {
                    val reports = ReportedSearchContributors(setOf(ReportedSearchContributorId.GOOGLE, ReportedSearchContributorId.GOOGLE_VIDEOS),
                        reportObservationCount = 7, unreportedObservationCount = 1, invalidObservationCount = 2,
                        unrecognizedObservationCount = 3, omittedObservationCount = 4)
                    val page = ProviderPage(candidates = listOf(CandidateUrl("https://owned.invalid/page", reportedSearchContributors = reports)), exhausted = true)
                    val result = ValidationPipeline(clock = clock, retainUnvalidatedCandidates = true)
                        .validate(provider.descriptor.id, page, request.profile.filters, operation)
                    callback(ProviderOutcome.Success(result))
                }
                return CancellationHandle {}
            }
        }
        val timer = object : DiscoveryTimer {
            override fun schedule(delayMillis: Long, action: () -> Unit) = CancellationHandle {}
        }
        VideoDiscoveryCoordinator(ProviderRegistry(listOf(source)), runtime, InMemoryDiscoveryStore(), timer, clock).use { coordinator ->
            coordinator.setVisibility(true, true)
            coordinator.start("private-session-identifier", SearchProfile("private-profile", "private query"))
            requireNotNull(completion).invoke()
            val value = requireNotNull(coordinator.sessionMetrics())
            assertNotNull(value.endpointReportedSearchContributors)
            val output = present(value).allText()
            assertTrue(output.contains("endpoint claims"))
            assertTrue(output.contains("Claimed contributor google · accepted page coverage: 1"))
            assertTrue(output.contains("Claimed contributor google videos · accepted page coverage: 1"))
            assertTrue(output.contains("Report rows: 7 · unreported: 1 · invalid: 2 · unrecognized: 3 · omitted: 4"))
            assertTrue(output.contains("UNRECOGNIZED"))
            for (secret in listOf("owned.invalid", "private-session-identifier", "private-profile", "private query")) assertFalse(output.contains(secret))
        }
    }
}

class DiscoverySessionReportResourceContractTest {
    @Test fun bothLocalesCoverAllKeysAndMatchNumberedPlaceholderContracts() {
        val en = reportStrings("values")
        val zh = reportStrings("values-zh-rCN")
        assertEquals(DiscoverySessionReportCopy.entries.map { "discovery_session_report_${it.name.lowercase(Locale.ROOT)}" }.toSet(), en.keys)
        assertEquals(en.keys, zh.keys)
        val placeholders = Regex("%[0-9]+\\$[sd]")
        for (key in en.keys) {
            assertEquals(key, placeholders.findAll(en.getValue(key)).map { it.value }.sorted().toList(),
                placeholders.findAll(zh.getValue(key)).map { it.value }.sorted().toList())
            assertFalse(key, en.getValue(key).any { it in '\u4e00'..'\u9fff' })
            for (strings in listOf(en, zh)) {
                assertFalse(key, strings.getValue(key).contains('\uFFFD'))
                assertFalse(key, placeholders.replace(strings.getValue(key), "").contains('%'))
            }
        }
    }

    @Test fun statelessContentWrapsTextAndDelegatesScrollingAndActionsToOwner() {
        val root = listOf(File("src/main/kotlin/com/easysavevideo/app"), File("app/src/main/kotlin/com/easysavevideo/app")).first { it.isDirectory }
        val content = File(root, "ui/DiscoverySessionReportContent.kt").readText()
        val policy = File(root, "discovery/DiscoverySessionReportPresentation.kt").readText()
        assertTrue(content.contains("LocalConfiguration.current.locales[0]"))
        assertTrue(content.contains("resources.getString(key.resource, *arguments)"))
        assertTrue(content.contains(".semantics { heading() }"))
        assertTrue(content.contains("EsvText(line, modifier = Modifier.fillMaxWidth()"))
        for (forbidden in listOf("maxLines =", "horizontalScroll", "verticalScroll", "Row(", "width(",
            "rememberSaveable", "LaunchedEffect", "DisposableEffect", "SideEffect", "AndroidDiscoveryController", "onRefresh", "sessionEvaluation(", "recordSeen(")) {
            assertFalse(forbidden, content.contains(forbidden))
        }
        for (forbidden in listOf("java.net.", "canonicalPageSha256", "sessionStamp", "queryKey", "print(", "Log.", "writeText", "SharedPreferences"))
            assertFalse(forbidden, policy.contains(forbidden))
    }
}
