# Library localization review: recovery observations

Recorded 2026-10-17 after the original workspace disappeared. This is a recovery note, not a completed independent review, test result, approval, source backup, or patch. No source is reconstructed here.

## Interruption and evidence limits

- The last successful source/evidence reads were around 22:27 UTC. At 22:28 UTC, the assigned reviewer confirmed that `/workspace/scratch/df6c1284d5ab/esv-runtime-copy-20261015` was missing. It remained missing at 22:32 UTC.
- The main build owner reported that the source was frozen at 3,049 files and that the first focused run had started. The reviewer did not observe that run finish and cannot establish its result.
- The full 3,049-file current-source and 3,034-file baseline hash-check command failed before starting because its working directory no longer existed. Neither manifest was independently rehashed by this reviewer. No final `INDEPENDENT_REVIEW.md` or `INDEPENDENT_REVIEW_HASHES.json` was produced.
- The 32-path change inventory in `RECORDED_CHANGE_INVENTORY.json` was read from the then-visible `evidence/SOURCE_CHANGES.json`: 15 added, 17 modified, zero removed. This record does not establish that those source bytes survive or match a future restoration.
- Recorded manifest identifiers came from the parent/frozen configuration, not a successful independent digest calculation. The one per-file digest retained below was seen in the manifest output and also was not independently recomputed.

## Baseline invariants observed before the interruption

1. `LibraryDeleteSelection.matches` compares the complete target. `confirmDelete` checks both the current confirmation and exact selected target before creating one operation ID. Media deletion passes the exact `MediaReadRef`, including its revision/representation generation.
2. `AndroidLibraryRuntime` uses one bounded work lane, read generations, explicit user-intent epochs, foreground admission, and picker lifecycle/page-return checks. Accepted durable writes finish/reconcile without a second tap duplicating them. Pending-delete unknown and cleanup-failure conditions precede the completion branch.
3. `unverifiedCleanupStillCurrent` requires foreground, not busy, cleanup capability, and membership by whole-row equality. The UI clears a confirmation when its exact row disappears. Runtime cleanup selects the operation ID and then checks exact source equality and `READBACK_UNSUPPORTED`; it does not substitute a nearby row.
4. Export picker, cancellation, directory-batch, recovery, grant, journal, source-revision and share-capacity/lifetime gates are separate from presentation. A cancelled SAF picker with no output has distinct copy from a known-cleaned cancellation. Copied-unverified, cleanup-pending and recovery-required states must not become success. Opening a share chooser is not delivery, and revocation cannot recall received content.
5. `AndroidExportPort.destinationLabel` was called only from `readReviews`. Its lookup was metadata-only: sanitized provider label, then sanitized authority, then owned fallback. Label lookup did not open documents or restore grants.

## Source observations actually made

The read preliminary core and export diffs showed no concrete new safety blocker in those portions. This statement is narrower than a final review of the frozen tree.

- Core runtime changes replaced rendered sentences with typed notices while retaining the compared operation branches and guards. Public `LibraryNotice`/`LibraryNoticeKind` are compatible with the visibility of public `LibraryViewState`.
- New core notice payloads contain fixed kinds, exact `LibraryError`, or integer counts. They do not retain names, exceptions, paths, URLs, or operation authority. Count-bearing notices have redacted `toString` implementations.
- The inspected screen renders owned templates using resources, passes external names as arguments/literals, and obtains current-composition locale for formatting. Action rows changed to `FlowRow` without changing the compared action-admission conditions. The existing single vertical dialog scroll owner remains.
- Export runtime differences were outcome substitutions plus decomposition of review labels into retained facts. Public `ExportNotice` has 39 closed outcomes; `UnverifiedExportStatus` has three closed outcomes. The typed phase/error mapping retained the baseline branches.
- `UnverifiedExportView` retains operation ID, exact source reference, source name, sanitized provider label, record order, capability, and typed status in data-class equality. Its `toString` remains redacted. Locale rendering changes text without changing the row or cleanup identity.
- The port's inspected change replaces only the owned fallback with null. Metadata lookup, sanitizer, 80-character bound, provider-label/authority fallback order and exception fallback remain. The UI resolves null to localized owned copy.
- The inspected paired resources contained 52 core strings plus four core plural entries and 77 export strings per locale. English count-neutral export phrasing avoids Long-to-Int plural conversion. Resource fixtures exercise exact formatter arguments, literal percent-containing external labels, and 0/1/2/large-Long counts.
- The inspected new tests include exact error-code assertions, runtime repository-call counts across retained-notice reformatting, unexpected-exception-text exclusion, whole-row cleanup invalidation, policy-derived share limits, current-composition wiring, resource key/placeholder parity, and direct-file input registration. These were source reads only; no reviewer tests were run.
- The inspected `app/build.gradle.kts` registers both new XML resource names in both locale folders and eight additional direct-read source paths. Runtime/status paths were already registered. The new source-contract tests' inspected direct reads have corresponding input entries.
- The implementation document explicitly leaves actual device layout, TalkBack, large-font and runtime locale-switch acceptance as `NOT_RUN` and reports no new APK/device acceptance. These limitations must remain in any eventual completion report.

## Still incomplete when files disappeared

- Independent digest and tree-membership verification for all source and baseline entries.
- A final byte-bound review of all 32 changed files. In particular, the final modifications to `LibraryMultiSelectionTest.kt`, `ExportLabelsTest.kt`, `ExportPresentationTest.kt`, and `ExportRecordCodecTest.kt` had not been read. The toolbar and paired `library_multi.xml` changes were only partially inspected through the changed consumers/key lines; their entire final files were not read.
- Verification of actual compile, focused/full tests, lint, dependency-byte admission and Release exclusion outcomes. No test count/result from this run is established by this note.
- Actual Android Compose locale-switch, narrow-screen, large-font, and accessibility execution. Source wrapping/scroll checks do not establish those outcomes.

## Focused-run and collector script observations

The reviewer read `run-focused.sh` and `collect-verification.py` before the interruption, but did not run them.

- The focused command placed `:library:test` before `:app:testDebugUnitTest`; the seven `--tests` filters followed the app task: `*Library*`, `*Export*`, `*Directory*`, `*Share*`, `*OrdinaryDestination*`, `*FinalResourceContractTest`, and `*EsvSemanticConsumerTest`. The intent is unfiltered library tests plus filtered app tests.
- The collector limits focused results to `library/test` or matching `app/testDebugUnitTest` suites, requires a five-component `module/build/test-results/task/TEST-*.xml` relative path, rejects empty/duplicate suite names, and requires both library and app results.
- A recovery/retry should use a fresh phase evidence-results directory. The viewed copy step did not clear old XML from an existing `evidence/focused/tests` directory; a later retry with renamed/removed suites could otherwise retain stale files. No actual stale-results contamination was established.
- Reconfirm these scripts after restoration and independently validate their actual collected results before reporting success. A fresh source/review manifest is required if any source bytes change.

## Recovery next step

Restore the actual source and evidence from an authorized reliable source. Re-establish the frozen baseline and candidate bytes, inspect every changed file, run the serialized authorized checks, and create a new independent review bound to the verified manifest. Do not treat these observations or reconstructed text as a substitute for original files or test evidence.
