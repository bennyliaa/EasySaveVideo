# Search-report owner recovery

Status: **context-reconstructed/unverified**.

本目录仅从本作者任务仍可见的、此前已执行的工具输入重建两个文件及对应补丁。它不是完整项目、不是 3034/3049 检查点、不是已验证恢复包。没有可用于对照的原文件 SHA-256，因此不声称与丢失文件字节等同。manifest 中的 SHA-256 仅标识本次重建出的字节。

## 保全文件

- `app/src/main/kotlin/com/easysavevideo/app/discovery/DiscoverySessionReportOwner.kt`：208 行
- `app/src/test/kotlin/com/easysavevideo/app/discovery/DiscoverySessionReportOwnerTest.kt`：507 行，27 个 `@Test` 方法
- `final-files.context-reconstructed.patch`：将两个最终重建稿作为新文件加入原有项目相对路径
- `visible-author-followups.context-reconstructed.patch`：从最初完整作者工具输入到最后可见作者稿的已知后续修改，供审计；不要在 final-files 补丁之后重复应用
- `RECOVERY_MANIFEST.json`：来源、限制、未包含内容及重建文件校验值

## 最后可见作者稿包含

1. `open(expectedContext)` 必须提供按钮渲染时的完整上下文；没有无参 Open。上下文在准入和加载状态发布后再次匹配。
2. Refresh/Dismiss 使用请求对象身份，复制出来但结构相同的对象不能替换当前请求。
3. Dismiss/上下文失效立即清除展示数据，但未完成 future 仍占单飞槽；无自动重试、轮询或请求队列。
4. 回调只保留 metrics，先核对 inventory 的 session stamp，不在展示状态或 UI 投递闭包中保留 inventory/page hashes。
5. 完成发布经过注入的 UI 投递；被拒绝的投递清除 payload，并在下一次 UI 调用中收束。
6. 重复回调、捕获/注册/投递异常、内联完成后抛错、重复点击、关闭、后台/路由/模态/来源/搜索变更以及可重入发布均有对应测试代码。

## 不能从本任务证明的内容

- 作者最后完成消息为 2026-10-17 21:20:34 UTC。此后 main/parent 可能对这两个文件做过修改；本上下文没有这些补丁，未擅自推测。
- AndroidDiscoveryController 的实际 capture 绑定修改、MainActivity/Compose 接线、报告 UI、资源文本和其他文件由其他作者负责，本目录不包含它们。
- 3034/3049 的最终源代码、APK、hash、编译/单元测试/设备测试状态不由本目录证明。
- 原工作阶段本作者没有运行 Gradle，仅见到行数、测试方法数和尾随空白检查。恢复阶段没有构建、测试、联网、访问用户本机或读取任何 denied session 路径。

## 集成时仍需核实

- Controller 必须在入 IO 队列前绑定目标 owner，并检查 target/source intent/lifecycle/session stamp；纯展示 owner 不能替代该保证。
- Main 必须把按钮渲染时的 context 传给 Open，并把渲染时的 request 传给 Refresh/Dismiss。
- route/foreground 的离开再返回需要递增 lifecycle generation；其他 modal 转换需要及时 reconcile 或等效 generation。报告自身的 modal 不应让 modalAvailable 失效。
- 应先恢复完整依赖与项目并核实其他作者的最终补丁，再串行执行项目已有构建和测试。此目录只负责保全，不执行这些步骤。
