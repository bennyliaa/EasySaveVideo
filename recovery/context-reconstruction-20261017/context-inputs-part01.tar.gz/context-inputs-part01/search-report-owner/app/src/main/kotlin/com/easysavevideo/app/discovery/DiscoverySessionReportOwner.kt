package com.easysavevideo.app.discovery

import com.easysavevideo.discovery.DiscoverySessionEvaluation
import com.easysavevideo.discovery.DiscoverySessionMetrics
import java.util.concurrent.CompletableFuture

/** All inputs are read on the UI lane. The report's own modal is excluded from modalAvailable.
 * lifecycleGeneration must advance on route departure/background, including leave-and-return.
 * available includes search/configuration/control readiness, so an accepted new search retires
 * the previous report before its replacement target has been published.
 */
data class DiscoverySessionReportContext(
    val target: DiscoveryControlTarget?,
    val sourceRevision: Long,
    val configurationIntent: Long,
    val lifecycleGeneration: Long,
    val available: Boolean,
    val foreground: Boolean,
    val routeVisible: Boolean,
    val modalAvailable: Boolean,
) {
    val eligible: Boolean get() = target != null && available && foreground && routeVisible && modalAvailable
    override fun toString() = "DiscoverySessionReportContext([redacted])"
}

enum class DiscoverySessionReportStatus { IDLE, LOADING, READY, UNAVAILABLE }

/** Identity, not structural equality, owns a refresh/dismiss callback. */
data class DiscoverySessionReportRequest internal constructor(
    val token: Long,
    val context: DiscoverySessionReportContext,
) { override fun toString() = "DiscoverySessionReportRequest([redacted])" }

/** This presentation retains metrics only, never the per-page inventory or an evaluation plan. */
data class DiscoverySessionReportState(
    val status: DiscoverySessionReportStatus = DiscoverySessionReportStatus.IDLE,
    val request: DiscoverySessionReportRequest? = null,
    val metrics: DiscoverySessionMetrics? = null,
    val busy: Boolean = false,
) {
    val visible: Boolean get() = status != DiscoverySessionReportStatus.IDLE
    override fun toString() = "DiscoverySessionReportState([redacted])"
}

/**
 * Pure, bounded, single-flight presentation ownership. Public methods, currentContext and publish
 * belong to the UI lane. deliver must run its callback there; a rejected delivery is drained by
 * the next UI call, never published from a future-completion thread.
 *
 * Only explicit open/refresh calls capture. Dismissal/context changes drop displayed data at once,
 * while the one underlying future keeps its claim until its UI completion. There is no request
 * queue, polling, persistence, network, history mutation or implicit retry. capture must bind the
 * requested coordinator/target before enqueueing its read and recheck it when the read executes.
 */
class DiscoverySessionReportOwner(
    private val currentContext: () -> DiscoverySessionReportContext,
    private val capture: (DiscoveryControlTarget) -> CompletableFuture<DiscoverySessionEvaluation?>,
    private val deliver: (() -> Unit) -> Boolean,
    private val publish: (DiscoverySessionReportState) -> Unit = {},
) : AutoCloseable {
    private class Flight(val request: DiscoverySessionReportRequest) {
        var observed = false
        var consumed = false
        var deliveryRejected = false
        var metrics: DiscoverySessionMetrics? = null
    }

    private val lock = Any()
    private var closed = false
    private var nextToken = 0L
    private var active: Flight? = null
    private var snapshot = DiscoverySessionReportState()
    val state: DiscoverySessionReportState get() = synchronized(lock) { snapshot }

    /** Bind the entry button to its rendered context. False creates no queued capture. */
    fun open(expectedContext: DiscoverySessionReportContext): Boolean {
        reconcile()
        return begin(expected = null, expectedContext = expectedContext)
    }

    /** Bind UI callbacks to the exact rendered request to prevent stale refreshes. */
    fun refresh(expected: DiscoverySessionReportRequest? = state.request): Boolean {
        reconcile()
        return if (expected == null) false else begin(expected, expected.context)
    }

    private fun begin(expected: DiscoverySessionReportRequest?, expectedContext: DiscoverySessionReportContext): Boolean {
        val context = contextOrNull() ?: return false
        val flight = synchronized(lock) {
            if (closed || active != null || !context.eligible || context != expectedContext) return false
            if (expected == null) {
                if (snapshot.visible) return false
            } else if (snapshot.request !== expected || !snapshot.visible) return false
            Flight(DiscoverySessionReportRequest(++nextToken, context)).also {
                active = it
                snapshot = DiscoverySessionReportState(DiscoverySessionReportStatus.LOADING, it.request, busy = true)
            }
        }
        publish(state)
        // Publication may reenter to dismiss, navigate, or dispose before capture has started.
        val latest = contextOrNull()
        val abandoned = synchronized(lock) {
            if (active !== flight) return true
            if (snapshot.request === flight.request && latest == context && latest?.eligible == true) false
            else {
                active = null
                snapshot = DiscoverySessionReportState()
                true
            }
        }
        if (abandoned) {
            if (!synchronized(lock) { closed }) publish(state)
            return true
        }
        try {
            capture(requireNotNull(context.target)).whenComplete { evaluation, failure ->
                complete(flight, if (failure == null) evaluation else null)
            }
        } catch (_: Exception) {
            complete(flight, null)
        }
        return true
    }

    /** Future callbacks may run on any lane and may be duplicated by an adapter. */
    private fun complete(flight: Flight, evaluation: DiscoverySessionEvaluation?) {
        synchronized(lock) {
            if (closed || active !== flight || flight.observed) return
            flight.observed = true
            // Project immediately: no delivery closure or retained state owns page hashes/inventory.
            flight.metrics = evaluation?.takeIf {
                snapshot.request === flight.request && it.inventory.sessionStamp == flight.request.context.target?.stamp
            }?.metrics
        }
        val accepted = try { deliver { consume(flight) } } catch (_: Exception) { false }
        if (!accepted) synchronized(lock) {
            // An adapter that executes inline and then rejects must not overwrite that completion.
            if (active === flight && !flight.consumed) {
                flight.deliveryRejected = true
                flight.metrics = null
            }
        }
    }

    private fun consume(flight: Flight) {
        val context = contextOrNull()
        val updated = synchronized(lock) {
            if (closed || active !== flight || flight.consumed || flight.deliveryRejected) return
            finishLocked(flight, context)
        }
        publish(updated)
    }

    private fun finishLocked(flight: Flight, context: DiscoverySessionReportContext?): DiscoverySessionReportState {
        flight.consumed = true
        active = null
        val metrics = flight.metrics
        flight.metrics = null
        snapshot = if (snapshot.request !== flight.request || context != flight.request.context || context?.eligible != true) {
            DiscoverySessionReportState()
        } else if (metrics == null) {
            DiscoverySessionReportState(DiscoverySessionReportStatus.UNAVAILABLE, flight.request)
        } else {
            DiscoverySessionReportState(DiscoverySessionReportStatus.READY, flight.request, metrics)
        }
        return snapshot
    }

    /** Call when presentation inputs change. This method never captures or refreshes. */
    fun reconcile() {
        val context = contextOrNull()
        val updated = synchronized(lock) {
            if (closed) return
            val pending = active
            if (pending?.deliveryRejected == true && !pending.consumed) {
                finishLocked(pending, context)
            } else if (snapshot.visible && (context != snapshot.request?.context || context?.eligible != true)) {
                pending?.metrics = null
                DiscoverySessionReportState(busy = pending != null).also { snapshot = it }
            } else return
        }
        publish(updated)
    }

    /** A stale close button cannot erase a newer report, even with an equal copied request. */
    fun dismiss(expected: DiscoverySessionReportRequest? = state.request): Boolean {
        val updated = synchronized(lock) {
            if (closed || expected == null || snapshot.request !== expected) return false
            active?.metrics = null
            DiscoverySessionReportState(busy = active != null).also { snapshot = it }
        }
        publish(updated)
        return true
    }

    override fun close() {
        val updated = synchronized(lock) {
            if (closed) return
            closed = true
            active?.metrics = null
            active = null
            DiscoverySessionReportState().also { snapshot = it }
        }
        publish(updated)
    }

    private fun contextOrNull(): DiscoverySessionReportContext? = try { currentContext() } catch (_: Exception) { null }
}
