package com.easysavevideo.app.discovery

import com.easysavevideo.core.model.EpochClock
import com.easysavevideo.discovery.*
import java.util.concurrent.CompletableFuture
import java.util.concurrent.RejectedExecutionException
import java.util.function.BiConsumer
import org.junit.Assert.*
import org.junit.Test

/** Executes the production presentation owner, using real content-free coordinator snapshots. */
class DiscoverySessionReportOwnerTest {
    private fun evaluation(session: String = "session", epoch: Int = 1, elapsed: Long = 123): DiscoverySessionEvaluation {
        val coordinator = VideoDiscoveryCoordinator(ProviderRegistry(), object : ProviderRuntime {
            override fun execute(provider: VideoSearchProvider, request: SearchRequest, operation: DiscoveryOperation,
                callback: (ProviderOutcome) -> Unit): CancellationHandle = error("No provider work allowed")
        }, InMemoryDiscoveryStore(), object : DiscoveryTimer {
            override fun schedule(delayMillis: Long, action: () -> Unit) = CancellationHandle {}
        }, EpochClock { 1_000 })
        return coordinator.use {
            repeat(epoch) { coordinator.start(session, SearchProfile("profile", "fixture query")) }
            requireNotNull(coordinator.sessionEvaluation()).let { it.copy(metrics = it.metrics.copy(elapsedMillis = elapsed)) }
        }
    }

    private class Queue {
        val tasks = mutableListOf<() -> Unit>()
        fun enqueue(task: () -> Unit): Boolean { tasks += task; return true }
        fun take() = tasks.removeAt(0)
        fun runNext() = take()()
    }

    private inner class Harness {
        val value = evaluation()
        val target = DiscoveryControlTarget("profile", value.inventory.sessionStamp, 0, 1)
        var context = DiscoverySessionReportContext(target, 3, 4, 5, true, true, true, true)
        val ui = Queue()
        val captures = mutableListOf<DiscoveryControlTarget>()
        val futures = mutableListOf<CompletableFuture<DiscoverySessionEvaluation?>>()
        val publications = mutableListOf<DiscoverySessionReportState>()
        var captureAction: ((DiscoveryControlTarget) -> CompletableFuture<DiscoverySessionEvaluation?>)? = null
        var deliveryAction: ((() -> Unit) -> Boolean)? = null
        var onPublish: (DiscoverySessionReportState) -> Unit = {}
        var onContext: () -> Unit = {}
        val owner = DiscoverySessionReportOwner(
            currentContext = { onContext(); context },
            capture = { target ->
                captures += target
                captureAction?.invoke(target) ?: CompletableFuture<DiscoverySessionEvaluation?>().also { futures += it }
            },
            deliver = { deliveryAction?.invoke(it) ?: ui.enqueue(it) },
            publish = { publications += it; onPublish(it) },
        )
        fun finish(value: DiscoverySessionEvaluation? = this.value, index: Int = futures.lastIndex) {
            futures[index].complete(value)
            ui.runNext()
        }
        fun ready() { assertTrue(owner.open(context)); finish() }
        fun assertIdle(busy: Boolean = false) {
            assertEquals(DiscoverySessionReportStatus.IDLE, owner.state.status)
            assertFalse(owner.state.visible)
            assertEquals(busy, owner.state.busy)
            assertNull(owner.state.metrics)
            assertNull(owner.state.request)
        }
    }

    @Test fun onlyExplicitOpenAndRefreshCaptureAndNeverPoll() {
        val h = Harness()
        repeat(20) { h.owner.reconcile() }
        assertTrue(h.captures.isEmpty())
        h.assertIdle()
        h.ready()
        assertSame(h.value.metrics, h.owner.state.metrics)
        assertEquals(DiscoverySessionReportStatus.READY, h.owner.state.status)
        assertFalse(h.owner.state.busy)
        assertEquals(listOf(h.target), h.captures)
        repeat(20) { h.owner.reconcile() }
        assertFalse(h.owner.open(h.context))
        assertEquals(1, h.captures.size)
        assertTrue(h.owner.refresh())
        assertNull(h.owner.state.metrics)
        assertEquals(2, h.captures.size)
        h.finish(h.value.copy(metrics = h.value.metrics.copy(elapsedMillis = 456)))
        assertEquals(456L, h.owner.state.metrics?.elapsedMillis)
    }

    @Test fun loadingClaimIsInstalledBeforeCaptureAndRepeatedClicksAreSingleFlight() {
        val h = Harness()
        h.captureAction = {
            assertTrue(h.owner.state.busy)
            assertEquals(DiscoverySessionReportStatus.LOADING, h.owner.state.status)
            assertFalse(h.owner.open(h.context))
            assertFalse(h.owner.refresh())
            CompletableFuture<DiscoverySessionEvaluation?>().also { h.futures += it }
        }
        assertTrue(h.owner.open(h.context))
        repeat(100) { assertFalse(h.owner.open(h.context)); assertFalse(h.owner.refresh()) }
        assertEquals(1, h.captures.size)
        h.futures.single().complete(h.value)
        assertTrue(h.owner.state.busy)
        assertFalse(h.owner.refresh())
        h.ui.runNext()
        assertFalse(h.owner.state.busy)
    }

    @Test fun staleOpenCallbackCannotCaptureAReplacementSearchOrLeaveReturnVisit() {
        val changes: List<(DiscoverySessionReportContext) -> DiscoverySessionReportContext> = listOf(
            { it.copy(target = it.target?.copy(stamp = SessionStamp("session", 2))) },
            { it.copy(target = it.target?.copy(controllerGeneration = 2)) },
            { it.copy(configurationIntent = 5) },
            { it.copy(sourceRevision = 4) },
            { it.copy(lifecycleGeneration = 6) },
        )
        for (change in changes) {
            val h = Harness()
            val renderedA = h.context
            h.context = change(h.context)
            assertFalse(h.owner.open(renderedA))
            assertTrue(h.captures.isEmpty())
            h.assertIdle()
            assertTrue(h.owner.open(h.context))
            assertEquals(1, h.captures.size)
        }
    }

    @Test fun returningToSameTargetStillRejectsThePreviousVisitOpenCallback() {
        val h = Harness()
        val renderedA = h.context
        h.context = h.context.copy(routeVisible = false, lifecycleGeneration = 6)
        h.owner.reconcile()
        h.context = h.context.copy(routeVisible = true)
        assertFalse(h.owner.open(renderedA))
        h.assertIdle()
        assertTrue(h.captures.isEmpty())
    }

    @Test fun backgroundFutureCompletionOnlyPublishesOnInjectedUiLane() {
        val h = Harness()
        val uiThread = Thread.currentThread()
        h.onContext = { assertSame(uiThread, Thread.currentThread()) }
        h.onPublish = { assertSame(uiThread, Thread.currentThread()) }
        h.owner.open(h.context)
        val background = Thread { h.futures.single().complete(h.value) }
        background.start(); background.join(2_000)
        assertFalse(background.isAlive)
        assertEquals(1, h.publications.size)
        assertNull(h.owner.state.metrics)
        assertTrue(h.owner.state.busy)
        h.ui.runNext()
        assertSame(h.value.metrics, h.owner.state.metrics)
    }

    @Test fun duplicateDeliveryCannotPublishTwiceOrReplaceNewerRefresh() {
        val h = Harness()
        h.owner.open(h.context); h.futures.single().complete(h.value)
        val oldDelivery = h.ui.take()
        oldDelivery(); oldDelivery()
        assertEquals(2, h.publications.size)
        assertTrue(h.owner.refresh())
        val newer = h.owner.state.request
        oldDelivery()
        assertSame(newer, h.owner.state.request)
        assertTrue(h.owner.state.busy)
        h.finish()
        oldDelivery()
        assertSame(newer, h.owner.state.request)
        assertEquals(4, h.publications.size)
    }

    /** A defensive adapter fixture can invoke whenComplete twice, unlike a conforming future. */
    private class RepeatingFuture : CompletableFuture<DiscoverySessionEvaluation?>() {
        lateinit var callback: BiConsumer<in DiscoverySessionEvaluation?, in Throwable?>
        override fun whenComplete(action: BiConsumer<in DiscoverySessionEvaluation?, in Throwable?>):
            CompletableFuture<DiscoverySessionEvaluation?> {
            callback = action
            return this
        }
    }

    @Test fun duplicateFutureCallbacksHaveOneDeliveryAndFirstOutcomeWins() {
        val h = Harness()
        val future = RepeatingFuture()
        h.captureAction = { future }
        h.owner.open(h.context)
        future.callback.accept(h.value, null)
        future.callback.accept(null, IllegalStateException("fixture"))
        assertEquals(1, h.ui.tasks.size)
        h.ui.runNext()
        assertSame(h.value.metrics, h.owner.state.metrics)
        future.callback.accept(h.value, null)
        assertTrue(h.ui.tasks.isEmpty())
    }

    @Test fun nullCaptureAndExceptionalFuturePublishUnavailableWithoutRetry() {
        for (exceptional in listOf(false, true)) {
            val h = Harness()
            h.owner.open(h.context)
            if (exceptional) h.futures.single().completeExceptionally(RejectedExecutionException("fixture"))
            else h.futures.single().complete(null)
            h.ui.runNext()
            assertEquals(DiscoverySessionReportStatus.UNAVAILABLE, h.owner.state.status)
            assertNull(h.owner.state.metrics)
            assertFalse(h.owner.state.busy)
            repeat(3) { h.owner.reconcile() }
            assertEquals(1, h.captures.size)
            assertTrue(h.owner.refresh())
        }
    }

    @Test fun captureExceptionUsesUiFailureDeliveryAndCanExplicitlyRetry() {
        val h = Harness()
        h.captureAction = { throw RejectedExecutionException("fixture") }
        assertTrue(h.owner.open(h.context))
        assertTrue(h.owner.state.busy)
        assertEquals(1, h.publications.size)
        h.ui.runNext()
        assertEquals(DiscoverySessionReportStatus.UNAVAILABLE, h.owner.state.status)
        h.captureAction = null
        assertTrue(h.owner.refresh())
        h.finish()
        assertEquals(DiscoverySessionReportStatus.READY, h.owner.state.status)
    }

    @Test fun failingCallbackRegistrationUsesOneFailureDeliveryUnlessAlreadyCompletedInline() {
        for (inlineSuccess in listOf(false, true)) {
            val h = Harness()
            h.captureAction = {
                object : CompletableFuture<DiscoverySessionEvaluation?>() {
                    override fun whenComplete(action: BiConsumer<in DiscoverySessionEvaluation?, in Throwable?>):
                        CompletableFuture<DiscoverySessionEvaluation?> {
                        if (inlineSuccess) action.accept(h.value, null)
                        throw RejectedExecutionException("fixture registration")
                    }
                }
            }
            h.owner.open(h.context)
            assertEquals(1, h.ui.tasks.size)
            h.ui.runNext()
            assertEquals(if (inlineSuccess) DiscoverySessionReportStatus.READY else DiscoverySessionReportStatus.UNAVAILABLE,
                h.owner.state.status)
            assertEquals(2, h.publications.size)
            assertFalse(h.owner.state.busy)
        }
    }

    @Test fun canceledFutureIsUnavailableAndDoesNotQueueRetry() {
        val h = Harness()
        h.owner.open(h.context); h.futures.single().cancel(false); h.ui.runNext()
        assertEquals(DiscoverySessionReportStatus.UNAVAILABLE, h.owner.state.status)
        assertFalse(h.owner.state.busy)
        assertEquals(1, h.captures.size)
    }

    @Test fun rejectedOrThrowingDeliveryDoesNotPublishOffLaneAndDrainsOnUi() {
        for (throws in listOf(false, true)) {
            val h = Harness()
            var retained: (() -> Unit)? = null
            h.deliveryAction = { task -> retained = task; if (throws) throw RejectedExecutionException("fixture") else false }
            h.owner.open(h.context); h.futures.single().complete(h.value)
            assertEquals(1, h.publications.size)
            assertTrue(h.owner.state.busy)
            requireNotNull(retained)()
            assertEquals(1, h.publications.size)
            h.owner.reconcile()
            assertEquals(DiscoverySessionReportStatus.UNAVAILABLE, h.owner.state.status)
            assertFalse(h.owner.state.busy)
            assertNull(h.owner.state.metrics)
            h.deliveryAction = null
            assertTrue(h.owner.refresh())
            val newer = h.owner.state.request
            requireNotNull(retained)()
            assertSame(newer, h.owner.state.request)
            h.finish()
        }
    }

    @Test fun inlineDeliveryThenRejectionOrThrowCannotEraseSuccessfulCompletion() {
        for (throws in listOf(false, true)) {
            val h = Harness()
            h.deliveryAction = { task -> task(); if (throws) throw RejectedExecutionException("fixture") else false }
            h.owner.open(h.context); h.futures.single().complete(h.value)
            assertEquals(DiscoverySessionReportStatus.READY, h.owner.state.status)
            assertSame(h.value.metrics, h.owner.state.metrics)
            h.owner.reconcile()
            assertEquals(2, h.publications.size)
        }
    }

    @Test fun dismissRetainsSingleFlightUntilCompletionAndCannotAutomaticallyReopen() {
        val h = Harness()
        h.owner.open(h.context)
        val old = h.owner.state.request
        assertTrue(h.owner.dismiss(old))
        h.assertIdle(busy = true)
        repeat(100) { assertFalse(h.owner.open(h.context)) }
        assertEquals(1, h.captures.size)
        h.finish()
        h.assertIdle()
        assertEquals(1, h.captures.size)
        assertTrue(h.owner.open(h.context))
        val newer = h.owner.state.request
        assertFalse(h.owner.dismiss(old))
        assertFalse(h.owner.refresh(old))
        assertSame(newer, h.owner.state.request)
        h.finish()
    }

    @Test fun staleCopiedRequestCannotRefreshOrDismissCurrentReport() {
        val h = Harness()
        h.ready()
        val request = requireNotNull(h.owner.state.request)
        assertFalse(h.owner.dismiss(request.copy()))
        assertFalse(h.owner.refresh(request.copy()))
        assertSame(request, h.owner.state.request)
        assertTrue(h.owner.refresh(request))
        assertFalse(h.owner.dismiss(request))
        assertFalse(h.owner.refresh(request))
        h.finish()
    }

    @Test fun everyContextBoundaryDiscardsAlreadyDisplayedMetricsWithoutRecapture() {
        val changes: List<(DiscoverySessionReportContext) -> DiscoverySessionReportContext> = listOf(
            { it.copy(target = null) },
            { it.copy(target = it.target?.copy(profileId = "replacement")) },
            { it.copy(target = it.target?.copy(stamp = SessionStamp("session", 2))) },
            { it.copy(target = it.target?.copy(controllerGeneration = 2)) },
            { it.copy(target = it.target?.copy(viewRevision = 1)) },
            { it.copy(sourceRevision = 4) },
            { it.copy(configurationIntent = 5) },
            { it.copy(lifecycleGeneration = 6) },
            { it.copy(available = false) },
            { it.copy(foreground = false) },
            { it.copy(routeVisible = false) },
            { it.copy(modalAvailable = false) },
        )
        for (change in changes) {
            val h = Harness()
            h.ready(); h.context = change(h.context); h.owner.reconcile()
            h.assertIdle()
            assertEquals(1, h.captures.size)
        }
    }

    @Test fun everyContextBoundaryFencesQueuedCompletionEvenWithoutRecomposition() {
        val changes: List<(DiscoverySessionReportContext) -> DiscoverySessionReportContext> = listOf(
            { it.copy(target = it.target?.copy(stamp = SessionStamp("session", 2))) },
            { it.copy(target = it.target?.copy(controllerGeneration = 2)) },
            { it.copy(sourceRevision = 4) },
            { it.copy(configurationIntent = 5) },
            { it.copy(lifecycleGeneration = 6) },
            { it.copy(available = false) },
            { it.copy(foreground = false) },
            { it.copy(routeVisible = false) },
            { it.copy(modalAvailable = false) },
        )
        for (change in changes) {
            val h = Harness()
            h.owner.open(h.context); h.futures.single().complete(h.value)
            h.context = change(h.context)
            h.ui.runNext()
            h.assertIdle()
            assertEquals(1, h.captures.size)
        }
    }

    @Test fun pendingSearchRetiresOldReportBeforeNewTargetPublication() {
        val h = Harness()
        h.owner.open(h.context)
        h.context = h.context.copy(available = false)
        h.owner.reconcile(); h.assertIdle(busy = true)
        // The old UI target may still be visible while a replacement search is queued.
        h.context = h.context.copy(available = true)
        h.finish()
        h.assertIdle()
        assertEquals(1, h.captures.size)
    }

    @Test fun leaveAndReturnCannotResurrectAnOldCaptureOrReadyReport() {
        for (alreadyReady in listOf(false, true)) {
            val h = Harness()
            h.owner.open(h.context)
            if (alreadyReady) h.finish()
            h.context = h.context.copy(routeVisible = false, lifecycleGeneration = 6)
            h.owner.reconcile()
            h.context = h.context.copy(routeVisible = true)
            h.owner.reconcile()
            if (!alreadyReady) h.finish()
            h.assertIdle()
            assertEquals(1, h.captures.size)
        }
    }

    @Test fun captureFromWrongSessionCannotBeRelabeledAsCurrentTarget() {
        val h = Harness()
        h.owner.open(h.context)
        // Models a queued capture accidentally reading B while its original claim still names A.
        h.finish(evaluation(epoch = 2))
        assertEquals(DiscoverySessionReportStatus.UNAVAILABLE, h.owner.state.status)
        assertNull(h.owner.state.metrics)
        assertEquals(h.target, h.owner.state.request?.context?.target)
    }

    @Test fun closeBeforeOpenAndDuringFutureOrQueuedDeliveryRejectsEverything() {
        for (stage in 0..2) {
            val h = Harness()
            if (stage > 0) h.owner.open(h.context)
            if (stage == 2) h.futures.single().complete(h.value)
            h.owner.close(); h.assertIdle()
            assertFalse(h.owner.open(h.context)); assertFalse(h.owner.refresh())
            val publications = h.publications.size
            if (stage == 1) h.futures.single().complete(h.value)
            if (stage == 2) h.ui.runNext()
            h.owner.reconcile(); h.owner.close()
            h.assertIdle()
            assertEquals(publications, h.publications.size)
        }
    }

    @Test fun admissionPublicationMayReenterButCannotCaptureTwice() {
        val h = Harness()
        var reentry = false
        h.onPublish = { state -> if (state.busy) {
            reentry = true
            assertFalse(h.owner.open(h.context))
            assertFalse(h.owner.refresh())
        } }
        assertTrue(h.owner.open(h.context))
        assertTrue(reentry)
        assertEquals(1, h.captures.size)
        h.finish()
    }

    @Test fun admissionPublicationDismissOrCloseOrContextChangePreventsCapture() {
        for (action in 0..2) {
            val h = Harness()
            h.onPublish = { state -> if (state.status == DiscoverySessionReportStatus.LOADING) {
                when (action) {
                    0 -> h.owner.dismiss(state.request)
                    1 -> h.owner.close()
                    else -> h.context = h.context.copy(available = false)
                }
            } }
            assertTrue(h.owner.open(h.context))
            assertTrue(h.captures.isEmpty())
            h.assertIdle()
        }
    }

    @Test fun successPublicationMayRefreshReentrantlyAndOldDeliveryCannotEraseIt() {
        val h = Harness()
        var refreshed = false
        h.onPublish = { state -> if (state.status == DiscoverySessionReportStatus.READY && !refreshed) {
            refreshed = true
            assertTrue(h.owner.refresh(state.request))
        } }
        h.owner.open(h.context); h.futures.single().complete(h.value)
        val oldDelivery = h.ui.take()
        oldDelivery()
        assertTrue(refreshed)
        assertEquals(2, h.captures.size)
        val newer = h.owner.state.request
        oldDelivery()
        assertSame(newer, h.owner.state.request)
        assertTrue(h.owner.state.busy)
        h.finish()
        assertSame(newer, h.owner.state.request)
    }

    @Test fun ineligibleContextCannotCaptureAndRefreshAfterInvalidationCannotOpenNewReport() {
        val h = Harness()
        h.context = h.context.copy(foreground = false)
        assertFalse(h.owner.open(h.context)); assertFalse(h.owner.refresh())
        assertTrue(h.captures.isEmpty())
        h.context = h.context.copy(foreground = true)
        h.ready()
        val old = h.owner.state.request
        h.context = h.context.copy(configurationIntent = 9)
        assertFalse(h.owner.refresh(old))
        h.assertIdle()
        assertEquals(1, h.captures.size)
    }

    @Test fun failedContextSupplierFailsClosedAndDoesNotRetainMetrics() {
        val h = Harness()
        h.ready()
        h.onContext = { throw IllegalStateException("fixture") }
        h.owner.reconcile()
        h.assertIdle()
        assertFalse(h.owner.open(h.context))
        assertEquals(1, h.captures.size)
    }

    @Test fun reportContractsKeepOnlyMetricsAndRedactIdentityStrings() {
        val h = Harness()
        h.ready()
        assertEquals("DiscoverySessionReportState([redacted])", h.owner.state.toString())
        assertEquals("DiscoverySessionReportRequest([redacted])", h.owner.state.request.toString())
        assertEquals("DiscoverySessionReportContext([redacted])", h.context.toString())
        val retainedTypes = DiscoverySessionReportState::class.java.declaredFields.map { it.type }
        assertFalse(retainedTypes.contains(DiscoverySessionEvaluation::class.java))
        assertFalse(retainedTypes.contains(DiscoveryEvaluationInventory::class.java))
        assertSame(h.value.metrics, h.owner.state.metrics)
        h.owner.dismiss()
        h.assertIdle()
    }
}
