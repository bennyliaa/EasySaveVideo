from pathlib import Path
import json
root=Path(__file__).parent
out=root/'reconstructed/app/src/main/kotlin/com/easysavevideo/app/library/export'
notices=json.loads((root/'evidence/notice-resource-copy.json').read_text())['notices']
mapping='''internal fun exportNotice(record: ExportRecord): ExportNotice = when (record.phase) {
    ExportPhase.SUCCEEDED -> if (record.request.destination.kind == ExportKind.MEDIA_STORE) ExportNotice.VERIFIED_GALLERY else ExportNotice.VERIFIED_DOCUMENT
    ExportPhase.COPIED_UNVERIFIED -> ExportNotice.COPIED_UNVERIFIED
    ExportPhase.CANCELLED -> if (record.request.destination.kind == ExportKind.SAF && record.output == null)
        ExportNotice.PICKER_CANCELLED
        else ExportNotice.EXPORT_CANCELLED
    ExportPhase.FAILED -> ExportNotice.EXPORT_FAILED
    ExportPhase.CLEANUP_PENDING -> ExportNotice.EXPORT_CLEANUP_PENDING
    else -> ExportNotice.EXPORT_RECOVERY_REQUIRED
}

internal fun shareFailureNotice(error: ShareError): ExportNotice = when (error) {
    ShareError.INITIALIZATION_FAILED -> ExportNotice.SHARE_INITIALIZATION_FAILED
    ShareError.SOURCE_TOO_LARGE -> ExportNotice.SHARE_SOURCE_TOO_LARGE
    ShareError.COPY_CAPACITY -> ExportNotice.SHARE_COPY_CAPACITY
    ShareError.PROCESS_CAPACITY -> ExportNotice.SHARE_PROCESS_CAPACITY
    ShareError.CLEANUP_PENDING -> ExportNotice.SHARE_CLEANUP_PENDING
    ShareError.RELEASE_UNCONFIRMED -> ExportNotice.SHARE_RELEASE_UNCONFIRMED
    ShareError.CANCELLED -> ExportNotice.SHARE_CANCELLED
    ShareError.IO -> ExportNotice.SHARE_IO
}
'''
with (out/'ExportPresentation.kt').open('x') as f: f.write('''package com.easysavevideo.app.library.export

import com.easysavevideo.app.library.share.ShareError
import com.easysavevideo.library.export.*

/** Finite presentation facts only. Resolve product text in the current composition, never a worker. */
enum class ExportNotice {
'''+''.join('    '+n+',\n' for n,_,_ in notices)+'''}

/** Grant and cleanup facts are separate from the current language and never confer authority. */
enum class UnverifiedExportStatus { GRANT_UNAVAILABLE, COPIED_UNVERIFIED, RECOVERY_REQUIRED }

'''+mapping)
renderer='''package com.easysavevideo.app.library.export

import com.easysavevideo.app.R
import com.easysavevideo.app.library.libraryBytes
import com.easysavevideo.app.library.share.SharePolicy
import com.easysavevideo.library.export.ExportLimits
import java.text.NumberFormat
import java.util.Locale
import java.util.concurrent.TimeUnit

/** A render-time reader only. Never stored in ExportViewState or captured by runtime work. */
internal fun interface LibraryExportText {
    fun get(resource: Int, vararg arguments: Any): String
}

internal fun libraryExportCount(value: Long, locale: Locale): String = NumberFormat.getIntegerInstance(locale).format(value)

internal fun exportNoticeResource(notice: ExportNotice): Int = when (notice) {
'''+''.join(f'    ExportNotice.{n} -> R.string.library_export_notice_{n.lower()}\n' for n,_,_ in notices)+'''}

internal fun exportNoticeText(notice: ExportNotice, locale: Locale, text: LibraryExportText): String {
    val arguments: Array<out Any> = when (notice) {
        ExportNotice.SHARE_CHOOSER_OPENED -> arrayOf(
            libraryExportCount(TimeUnit.MILLISECONDS.toMinutes(SharePolicy.TTL_MILLIS), locale),
            libraryExportCount(SharePolicy.MAX_OPENS.toLong(), locale))
        ExportNotice.BATCH_SHARE_LIMIT -> arrayOf(libraryExportCount(SharePolicy.MAX_COPIES.toLong(), locale),
            libraryBytes(SharePolicy.MAX_COPY_BYTES, locale), libraryBytes(SharePolicy.MAX_TOTAL_BYTES, locale))
        ExportNotice.BATCH_SHARE_CHOOSER_OPENED -> arrayOf(libraryExportCount(TimeUnit.MILLISECONDS.toMinutes(SharePolicy.TTL_MILLIS), locale))
        ExportNotice.EXPORT_CAPACITY -> arrayOf(libraryExportCount(ExportLimits.MAX_ACTIVE.toLong(), locale))
        ExportNotice.SHARE_SOURCE_TOO_LARGE -> arrayOf(libraryBytes(SharePolicy.MAX_COPY_BYTES, locale))
        ExportNotice.SHARE_COPY_CAPACITY -> arrayOf(libraryExportCount(SharePolicy.MAX_COPIES.toLong(), locale),
            libraryBytes(SharePolicy.MAX_TOTAL_BYTES, locale))
        else -> emptyArray()
    }
    return text.get(exportNoticeResource(notice), *arguments)
}

internal fun unverifiedExportLabel(entry: UnverifiedExportView, locale: Locale, text: LibraryExportText): String =
    text.get(R.string.library_export_review_label,
        entry.sourceName ?: text.get(R.string.library_export_review_unknown_source, entry.source.itemId.take(8)),
        entry.sanitizedProviderLabel ?: text.get(R.string.library_export_review_unknown_provider),
        libraryExportCount(entry.recordOrder, locale))

internal fun unverifiedExportStatusResource(status: UnverifiedExportStatus): Int = when (status) {
    UnverifiedExportStatus.GRANT_UNAVAILABLE -> R.string.library_export_review_grant_unavailable
    UnverifiedExportStatus.COPIED_UNVERIFIED -> R.string.library_export_review_copied_unverified
    UnverifiedExportStatus.RECOVERY_REQUIRED -> R.string.library_export_review_recovery_required
}

internal fun exportShareWarning(locale: Locale, text: LibraryExportText): String = text.get(
    R.string.library_export_share_warning, libraryBytes(SharePolicy.MAX_COPY_BYTES, locale),
    libraryExportCount(SharePolicy.MAX_COPIES.toLong(), locale), libraryBytes(SharePolicy.MAX_TOTAL_BYTES, locale),
    libraryExportCount(TimeUnit.MILLISECONDS.toMinutes(SharePolicy.TTL_MILLIS), locale),
    libraryExportCount(SharePolicy.MAX_OPENS.toLong(), locale))
'''
with (out/'LibraryExportResources.kt').open('x') as f:f.write(renderer)
# Exact text patch payload for the two original runtime mapping functions, after the 39 substitutions.
post_replacement_mapping=mapping.replace('): ExportNotice =','): String =')
with (root/'patches/runtime-moved-function-suffix.txt').open('x') as f:f.write('\n'+post_replacement_mapping)
replacements=[
('val notice: String? = null','val notice: ExportNotice? = null'),
('    val label: String,\n    val canAttemptCleanup: Boolean,\n    val status: String,','    val sourceName: String?,\n    val sanitizedProviderLabel: String?,\n    val recordOrder: Long,\n    val canAttemptCleanup: Boolean,\n    val status: UnverifiedExportStatus,'),
('val label = if (item != null && item.lifecycle == com.easysavevideo.library.MediaLifecycle.READY)\n                item.displayName else "媒体库项目 ${source.itemId.take(8)}"','val sourceName = if (item != null && item.lifecycle == com.easysavevideo.library.MediaLifecycle.READY)\n                item.displayName else null'),
('UnverifiedExportView(record.operationId, source, "$label → $destination · 导出记录 #${entry.order}", supported,\n                if (!port.hasLiveSafGrant(record.operationId)) "授权已不可用，请在文件提供方中手动核对。"\n                else if (record.verification == ExportVerification.READBACK_UNSUPPORTED) "副本未完整校验，可明确选择清理。"\n                else "导出或清理结果待核对，请重试恢复检查。")','UnverifiedExportView(record.operationId, source, sourceName, destination, entry.order, supported,\n                if (!port.hasLiveSafGrant(record.operationId)) UnverifiedExportStatus.GRANT_UNAVAILABLE\n                else if (record.verification == ExportVerification.READBACK_UNSUPPORTED) UnverifiedExportStatus.COPIED_UNVERIFIED\n                else UnverifiedExportStatus.RECOVERY_REQUIRED)'),
]
port=[
('fun destinationLabel(operationId: String): String {','fun destinationLabel(operationId: String): String? {',1),
('?: return "所选文件提供方"','?: return null',2),
('safeExportLabel(authority, 80).ifBlank { "所选文件提供方" }','safeExportLabel(authority, 80).takeIf { it.isNotBlank() }',1),
]
with (root/'patches/runtime-structure-replacements.json').open('x') as f:json.dump([{'old':a,'new':b,'expected_occurrences':1} for a,b in replacements],f,ensure_ascii=False,indent=2)
with (root/'patches/port-destination-label-replacements.json').open('x') as f:json.dump([{'old':a,'new':b,'expected_occurrences':n} for a,b,n in port],f,ensure_ascii=False,indent=2)
print('Recovered two full production files and exact runtime/port patch payloads')
