# Export/library context recovery

Status: **context-reconstructed / unverified**. These are recovery candidates copied from this worker's visible executed tool inputs and full outputs. They are not a restored baseline, a successful build, or original-byte-verified files.

## Preserved full files

Under `reconstructed/`:

- Production: `LibraryExportStatus.kt`, `LibraryExportDialog.kt`, `export/ExportPresentation.kt`, `export/LibraryExportResources.kt`
- Resources: `values/library_export_localization.xml`, `values-zh-rCN/library_export_localization.xml`
- Tests/helper: `LibraryUnverifiedCleanupTest.kt`, `export/ExportLabelsTest.kt`, `export/ExportPresentationTest.kt`, `export/ExportRecordCodecTest.kt`, `export/LibraryExportLocalizationTest.kt`, `export/LibraryExportLocalizationSourceContractTest.kt`, `export/LibraryExportResourceFixture.kt`

There are 13 full source/resource/test candidates. Four are production Kotlin files, two are resource files, and seven are test/helper Kotlin files.

## Patch-only source preservation

The entire original `AndroidExportRuntime.kt` and `AndroidExportPort.kt` are not represented as recovered full files. Their changes are retained as exact old/new text recipes under `patches/`:

- `runtime-notice-replacements.json`: all 39 original literal-to-enum changes, expected once each
- `runtime-structure-replacements.json`: typed notice/row fields and review-row construction
- `runtime-moved-function-suffix.txt`: exact transformed trailing mapping functions to remove after literal substitution; implementations are preserved in `ExportPresentation.kt`
- `port-destination-label-replacements.json`: only the nullable presentation fallback; existing provider metadata lookup and sanitization stay untouched
- `reconstruct_from_baseline.py`: validates every exact anchor, reads an independently recovered baseline without changing it, and writes only absent output files to a different directory. It covers Runtime, Port, Status, and Dialog. It has not been run against an original baseline.

The patch script must not be treated as baseline verification. Do not bypass an anchor mismatch or apply it blindly to a different revision.

## Verification boundaries

Reconstructed-only static checks confirmed 77 resource entries in each locale, matching keys/placeholders, 39 resource notice mappings, and no owned Chinese literal in the reconstructed production Kotlin files. This does not prove equality to the lost files.

No original file hash was available for a byte-for-byte comparison. All generated hashes describe this recovery artifact only; `original_hash_comparison` is false. No Gradle/JVM test, dependency install, build, APK, deployment, or device operation was run during recovery. The interrupted focused run has no successful result to claim.

This package does not restore the 3034/3049-file project, Gradle configuration, core implementation, dependencies, or toolchain. It depends on the separately recovered `libraryBytes(bytes: Long, locale: Locale = Locale.ROOT)` implementation. The Gradle direct-file registration remains main's responsibility.
