#!/usr/bin/env python3
"""Context-reconstructed/unverified exact-match patch recipe.
Reads an independently recovered source tree and writes ONLY missing files to a new output tree.
Never edits the input. Refuses missing, duplicate or differing anchors and existing output files.
No original-byte verification is implied; original hashes must be checked separately.
"""
from pathlib import Path
import argparse, json
here=Path(__file__).parent

def exact(value, old, new, count=1):
    actual=value.count(old)
    if actual != count:
        raise ValueError(f'Expected {count} exact occurrences; found {actual}: {old[:100]!r}')
    return value.replace(old,new)

def apply_list(value,name):
    for change in json.loads((here/name).read_text()):
        value=exact(value,change['old'],change['new'],change['expected_occurrences'])
    return value

def runtime(value):
    value=apply_list(value,'runtime-notice-replacements.json')
    value=apply_list(value,'runtime-structure-replacements.json')
    suffix=(here/'runtime-moved-function-suffix.txt').read_text()
    if not value.endswith(suffix):
        raise ValueError('Original moved mapping suffix does not match exactly; stop for baseline review')
    return value[:-len(suffix)].rstrip()+'\n'

def port(value):
    return apply_list(value,'port-destination-label-replacements.json')

def status(value):
    value=exact(value,'import androidx.compose.ui.res.stringResource','import androidx.compose.ui.res.stringResource\nimport androidx.compose.ui.platform.LocalConfiguration\nimport androidx.compose.ui.platform.LocalContext')
    value=exact(value,'import com.easysavevideo.app.library.export.UnverifiedExportView','import com.easysavevideo.app.library.export.UnverifiedExportView\nimport com.easysavevideo.app.library.export.LibraryExportText\nimport com.easysavevideo.app.library.export.libraryExportCount\nimport com.easysavevideo.app.library.export.exportNoticeText\nimport com.easysavevideo.app.library.export.unverifiedExportLabel\nimport com.easysavevideo.app.library.export.unverifiedExportStatusResource')
    value=exact(value,'@Composable\ninternal fun LibraryExportStatus','@OptIn(ExperimentalLayoutApi::class)\n@Composable\ninternal fun LibraryExportStatus')
    value=exact(value,'    val v = LocalEsvVisuals.current\n','    val v = LocalEsvVisuals.current\n    val locale = LocalConfiguration.current.locales[0]\n    val resources = LocalContext.current.resources\n    val text = LibraryExportText { resource, arguments -> resources.getString(resource, *arguments) }\n')
    fixed={
        '正在处理导出 / 分享副本，尚未确认完成。':'busy',
        '查看待核对的文件副本':'review_open',
        '取消本次导出 / 准备分享':'cancel_operation',
        '撤销临时分享读取并清理副本':'revoke_shares',
        '撤销不会收回其他应用已经读到或保存的内容。部分系统或接收应用可能不支持临时只读分享；遇到兼容问题可改用导出文件。':'revoke_scope',
        '删除这个外部导出副本？':'cleanup_title',
        '这会尝试删除上面这条导出记录对应的文件副本，此清理不会操作应用内原件。所选服务可能永久删除该副本；不支持清理时会保留明确的待处理结果。':'cleanup_warning',
        '确认删除这个导出副本':'cleanup_confirm',
        '保留副本，取消':'cleanup_cancel',
        '待核对的文件副本':'review_title',
        '以下记录与最近一次导出结果分别保存。重启后不会自动重新取得文件授权；没有可用授权的副本需要到原来选择的文件位置手动核对。':'review_scope',
        '当前没有待核对的文件副本记录。':'review_empty',
        '清理这个副本…':'cleanup_action',
        '上一页记录':'review_previous',
        '下一页记录':'review_next',
        '关闭列表':'review_close',
    }
    for old,key in fixed.items(): value=exact(value,'"'+old+'"','stringResource(R.string.library_export_'+key+')')
    value=exact(value,'EsvText(it, style = v.captionTextStyle) }','EsvText(exportNoticeText(it, locale, text), style = v.captionTextStyle) }')
    changes=[
        ('"${state.recoverable} 个导出操作仍待核对或清理。导出不会删除原件；外部位置可能已有副本或部分文件。"','stringResource(R.string.library_export_recoverable, libraryExportCount(state.recoverable, locale))'),
        ('"有 ${state.unverifiedCount} 条文件导出记录需要核对，包含未校验或尚未确认清理的副本。"','stringResource(R.string.library_export_review_count, libraryExportCount(state.unverifiedCount, locale))'),
        ('EsvText(confirmation.label)','EsvText(unverifiedExportLabel(confirmation, locale, text))'),
        ('"导出操作：${confirmation.operationId}"','stringResource(R.string.library_export_operation, confirmation.operationId)'),
        ('"来源项目：${confirmation.source.itemId} · 版本 ${confirmation.source.revision}"','stringResource(R.string.library_export_source, confirmation.source.itemId, libraryExportCount(confirmation.source.revision, locale))'),
        ('EsvText(entry.label,','EsvText(unverifiedExportLabel(entry, locale, text),'),
        ('EsvText(entry.status,','EsvText(stringResource(unverifiedExportStatusResource(entry.status)),'),
        ('"第 ${state.unverifiedPage + 1} / ${state.unverifiedPages} 页 · ${state.unverifiedCount} 条记录"','stringResource(R.string.library_export_review_page, libraryExportCount(state.unverifiedPage + 1, locale),\n                    libraryExportCount(state.unverifiedPages, locale), libraryExportCount(state.unverifiedCount, locale))'),
        ('Row(horizontalArrangement = Arrangement.spacedBy(v.spacingSmall)) {','FlowRow(horizontalArrangement = Arrangement.spacedBy(v.spacingSmall), verticalArrangement = Arrangement.spacedBy(v.spacingSmall)) {'),
    ]
    for old,new in changes: value=exact(value,old,new)
    return value

def dialog(value):
    value=exact(value,'import androidx.compose.ui.Modifier','import androidx.compose.ui.Modifier\nimport androidx.compose.ui.res.stringResource\nimport androidx.compose.ui.platform.LocalConfiguration\nimport androidx.compose.ui.platform.LocalContext\nimport com.easysavevideo.app.R\nimport com.easysavevideo.app.library.export.LibraryExportText\nimport com.easysavevideo.app.library.export.exportShareWarning')
    value=exact(value,'    val v = LocalEsvVisuals.current\n','    val v = LocalEsvVisuals.current\n    val locale = LocalConfiguration.current.locales[0]\n    val resources = LocalContext.current.resources\n    val text = LibraryExportText { resource, arguments -> resources.getString(resource, *arguments) }\n')
    fixed={
        '导出 / 分享副本':'dialog_title',
        '每次操作会另建普通视频副本，保留媒体库原件。只有完整写入并核对后才确认导出完成。':'dialog_scope',
        '相册副本发布后可由其他有权限的应用读取。':'gallery_warning',
        '导出一份到相册':'gallery_action',
        '文件位置由你在系统中选择。所选服务可能同步到云端；取消、权限丢失或服务不支持核对时，可能留下部分文件，需要在该位置检查或清理。':'files_warning',
        '选择文件位置并导出':'files_action',
        '此视频超过临时分享大小上限，可使用上方的相册或文件导出。':'share_oversize',
        '准备副本并打开系统分享':'share_action',
        '取消':'dialog_cancel',
    }
    for old,key in fixed.items(): value=exact(value,'"'+old+'"','stringResource(R.string.library_export_'+key+')')
    value=exact(value,'"${libraryBytes(item.sizeBytes)} · MP4"','stringResource(R.string.library_export_dialog_size, libraryBytes(item.sizeBytes, locale))')
    return exact(value,'"分享支持单个不超过 ${libraryBytes(SharePolicy.MAX_COPY_BYTES)} 的视频。应用内最多保留 ${SharePolicy.MAX_COPIES} 份临时副本，总计不超过 ${libraryBytes(SharePolicy.MAX_TOTAL_BYTES)}。副本只读、有效期 10 分钟，最多打开 ${SharePolicy.MAX_OPENS} 次，支持按位置读取。打开系统面板不代表已送达；到期或撤销会阻止后续读取，但接收方已读到或复制的内容无法收回。"','exportShareWarning(locale, text)')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if args.baseline.resolve()==args.output.resolve():raise ValueError('Output must differ from baseline')
    base='app/src/main/kotlin/com/easysavevideo/app/library/'
    planned={base+'export/AndroidExportRuntime.kt':runtime,base+'export/AndroidExportPort.kt':port,
        base+'LibraryExportStatus.kt':status,base+'LibraryExportDialog.kt':dialog}
    results={path:transform((args.baseline/path).read_text()) for path,transform in planned.items()}
    if any((args.output/path).exists() for path in results):raise FileExistsError('Output file exists; nothing written')
    for path,value in results.items():
        target=args.output/path;target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('x') as f:f.write(value)
    print('Wrote four context-patched candidate files. Original-byte and build verification remain required.')
