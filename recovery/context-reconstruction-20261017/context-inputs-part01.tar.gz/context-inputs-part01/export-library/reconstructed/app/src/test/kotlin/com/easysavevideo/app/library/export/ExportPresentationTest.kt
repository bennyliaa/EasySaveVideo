package com.easysavevideo.app.library.export

import com.easysavevideo.app.library.share.ShareError
import com.easysavevideo.library.MediaReadRef
import com.easysavevideo.library.export.*
import java.util.Locale
import org.junit.Assert.*
import org.junit.Test

class ExportPresentationTest {
    private val request = ExportRequest("export-op", MediaReadRef("item", 1, 1), ExportDestination(ExportKind.SAF, "grant"))
    private fun rendered(notice: ExportNotice, folder: String) = exportNoticeText(notice,
        if (folder == "values") Locale.US else Locale.SIMPLIFIED_CHINESE,
        libraryExportResourceText(folder, if (folder == "values") Locale.US else Locale.SIMPLIFIED_CHINESE))

    @Test fun noticesDoNotPromiseIndependentlyDeletedOriginalStillExists() {
        val success = ExportRecord(request, ExportPhase.SUCCEEDED, ExportOutput("export-op", ExportKind.SAF), ExportEvidence(1, "a".repeat(64)),
            verification = ExportVerification.DESTINATION_VERIFIED)
        assertEquals(ExportNotice.VERIFIED_DOCUMENT, exportNotice(success))
        val chinese = rendered(exportNotice(success), "values-zh-rCN")
        assertTrue(chinese.contains("本次操作不会删除")); assertFalse(chinese.contains("仍保留"))
        val english = rendered(exportNotice(success), "values")
        assertTrue(english.contains("This operation does not delete library originals"))
        assertFalse(english.contains("still exists"))
    }
    @Test fun cancelledPickerDoesNotClaimUnknownDocumentCleaned() {
        val notice = exportNotice(ExportRecord(request, ExportPhase.CANCELLED, cancelRequested = true))
        assertEquals(ExportNotice.PICKER_CANCELLED, notice)
        assertTrue(rendered(notice, "values-zh-rCN").contains("可能留下空文档"))
        assertFalse(rendered(notice, "values-zh-rCN").contains("已移除"))
        assertTrue(rendered(notice, "values").contains("may have left an empty document"))
        assertFalse(rendered(notice, "values").contains("were removed"))
        assertEquals(ExportNotice.EXPORT_CANCELLED, exportNotice(ExportRecord(request, ExportPhase.CANCELLED,
            output = ExportOutput("export-op", ExportKind.SAF), cancelRequested = true, cleanup = ExportCleanup.REMOVED)))
    }
    @Test fun everyExportPhasePreservesItsEvidenceAndDestinationDistinction() {
        val evidence = ExportEvidence(1, "a".repeat(64))
        for (kind in ExportKind.entries) {
            val selected = request.copy(destination = request.destination.copy(kind = kind))
            for (phase in ExportPhase.entries) {
                if (phase == ExportPhase.COPIED_UNVERIFIED && kind != ExportKind.SAF) continue
                val verification = when (phase) {
                    ExportPhase.SUCCEEDED -> ExportVerification.DESTINATION_VERIFIED
                    ExportPhase.COPIED_UNVERIFIED -> ExportVerification.READBACK_UNSUPPORTED
                    else -> ExportVerification.NONE
                }
                val record = ExportRecord(selected, phase, ExportOutput("export-op", kind), evidence, verification = verification)
                val expected = when (phase) {
                    ExportPhase.SUCCEEDED -> if (kind == ExportKind.MEDIA_STORE) ExportNotice.VERIFIED_GALLERY else ExportNotice.VERIFIED_DOCUMENT
                    ExportPhase.COPIED_UNVERIFIED -> ExportNotice.COPIED_UNVERIFIED
                    ExportPhase.CANCELLED -> ExportNotice.EXPORT_CANCELLED
                    ExportPhase.FAILED -> ExportNotice.EXPORT_FAILED
                    ExportPhase.CLEANUP_PENDING -> ExportNotice.EXPORT_CLEANUP_PENDING
                    else -> ExportNotice.EXPORT_RECOVERY_REQUIRED
                }
                assertEquals("$kind/$phase", expected, exportNotice(record))
            }
            assertEquals(if (kind == ExportKind.SAF) ExportNotice.PICKER_CANCELLED else ExportNotice.EXPORT_CANCELLED,
                exportNotice(ExportRecord(selected, ExportPhase.CANCELLED)))
        }
    }
    @Test fun allShareFailureClassesStayExplicitAndDistinct() {
        val expected = mapOf(
            ShareError.INITIALIZATION_FAILED to ExportNotice.SHARE_INITIALIZATION_FAILED,
            ShareError.SOURCE_TOO_LARGE to ExportNotice.SHARE_SOURCE_TOO_LARGE,
            ShareError.COPY_CAPACITY to ExportNotice.SHARE_COPY_CAPACITY,
            ShareError.PROCESS_CAPACITY to ExportNotice.SHARE_PROCESS_CAPACITY,
            ShareError.CLEANUP_PENDING to ExportNotice.SHARE_CLEANUP_PENDING,
            ShareError.RELEASE_UNCONFIRMED to ExportNotice.SHARE_RELEASE_UNCONFIRMED,
            ShareError.CANCELLED to ExportNotice.SHARE_CANCELLED,
            ShareError.IO to ExportNotice.SHARE_IO,
        )
        assertEquals(ShareError.entries.toSet(), expected.keys)
        expected.forEach { (error, notice) -> assertEquals(notice, shareFailureNotice(error)) }
        assertEquals(8, expected.values.toSet().size)
    }
    @Test fun unverifiedRowsCarryIndependentIdentityAndRedactedDiagnostics() {
        val a = UnverifiedExportView("op-a", request.source, "First", "Provider A", 1, true, UnverifiedExportStatus.COPIED_UNVERIFIED)
        val b = UnverifiedExportView("op-b", request.source, "Second", "Provider B", 2, false, UnverifiedExportStatus.GRANT_UNAVAILABLE)
        val state = ExportViewState(unverified = listOf(a, b), unverifiedCount = 2, unverifiedPages = 1)
        assertEquals(a, state.unverified.single { it.operationId == "op-a" })
        assertFalse(state.unverified.single { it.operationId == "op-b" }.canAttemptCleanup)
        for (privateText in listOf("First", "Provider A", "op-a", "item")) assertFalse(a.toString().contains(privateText))
        assertEquals("UnverifiedExportView([redacted])", a.toString())
    }
    @Test fun copyCapacityHasCleanupActionInsteadOfPretendRecovery() {
        val notice = shareFailureNotice(ShareError.COPY_CAPACITY)
        assertEquals(ExportNotice.SHARE_COPY_CAPACITY, notice)
        val chinese = rendered(notice, "values-zh-rCN")
        assertTrue(chinese.contains("撤销")); assertTrue(chinese.contains("实际关闭")); assertFalse(chinese.contains("重新启动"))
        val english = rendered(notice, "values")
        assertTrue(english.contains("Revoke")); assertTrue(english.contains("actually close")); assertFalse(english.contains("restart"))
        assertTrue(rendered(shareFailureNotice(ShareError.PROCESS_CAPACITY), "values").contains("restart"))
        assertTrue(rendered(shareFailureNotice(ShareError.PROCESS_CAPACITY), "values-zh-rCN").contains("重新启动"))
    }
    @Test fun oversizePointsAtOrdinaryExport() {
        assertEquals(ExportNotice.SHARE_SOURCE_TOO_LARGE, shareFailureNotice(ShareError.SOURCE_TOO_LARGE))
        assertTrue(rendered(shareFailureNotice(ShareError.SOURCE_TOO_LARGE), "values-zh-rCN").contains("系统视频库"))
        assertTrue(rendered(shareFailureNotice(ShareError.SOURCE_TOO_LARGE), "values").contains("system video library or a file"))
    }
}
