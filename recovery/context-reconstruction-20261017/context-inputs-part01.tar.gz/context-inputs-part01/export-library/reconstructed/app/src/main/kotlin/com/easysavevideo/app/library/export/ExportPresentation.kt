package com.easysavevideo.app.library.export

import com.easysavevideo.app.library.share.ShareError
import com.easysavevideo.library.export.*

/** Finite presentation facts only. Resolve product text in the current composition, never a worker. */
enum class ExportNotice {
    EXTRA_COPY_CANCELLATION_PENDING,
    EXTRA_COPY_CANCELLATION_QUEUE_BUSY,
    PICK_DOCUMENT,
    PICKER_RESULT_UNRELATED,
    DOCUMENT_GRANT_UNAVAILABLE,
    SHARE_CANCELLED_AFTER_PREPARATION,
    SHARE_CHOOSER_OPENED,
    SHARE_CHOOSER_UNAVAILABLE,
    BATCH_COPY_RESULTS,
    BATCH_SHARE_LIMIT,
    BATCH_SHARE_CHOOSER_OPENED,
    BATCH_SHARE_CHOOSER_UNCONFIRMED,
    BATCH_SELECTION_STALE,
    CANCEL_PICKER_REQUESTED,
    CANCEL_IO_REQUESTED,
    UNVERIFIED_CLEANUP_UNAVAILABLE,
    SHARES_REVOKED_CLEANED,
    SHARES_REVOKED_CLEANUP_PENDING,
    EXPORT_CAPACITY,
    RESULT_UNCONFIRMED,
    EXPORT_QUEUE_BUSY,
    CONTROL_UNCONFIRMED,
    CONTROL_QUEUE_BUSY,
    VERIFIED_GALLERY,
    VERIFIED_DOCUMENT,
    COPIED_UNVERIFIED,
    PICKER_CANCELLED,
    EXPORT_CANCELLED,
    EXPORT_FAILED,
    EXPORT_CLEANUP_PENDING,
    EXPORT_RECOVERY_REQUIRED,
    SHARE_INITIALIZATION_FAILED,
    SHARE_SOURCE_TOO_LARGE,
    SHARE_COPY_CAPACITY,
    SHARE_PROCESS_CAPACITY,
    SHARE_CLEANUP_PENDING,
    SHARE_RELEASE_UNCONFIRMED,
    SHARE_CANCELLED,
    SHARE_IO,
}

/** Grant and cleanup facts are separate from the current language and never confer authority. */
enum class UnverifiedExportStatus { GRANT_UNAVAILABLE, COPIED_UNVERIFIED, RECOVERY_REQUIRED }

internal fun exportNotice(record: ExportRecord): ExportNotice = when (record.phase) {
    ExportPhase.SUCCEEDED -> if (record.request.destination.kind == ExportKind.MEDIA_STORE) ExportNotice.VERIFIED_GALLERY else ExportNotice.VERIFIED_DOCUMENT
    ExportPhase.COPIED_UNVERIFIED -> ExportNotice.COPIED_UNVERIFIED
    ExportPhase.CANCELLED -> if (record.request.destination.kind == ExportKind.SAF && record.output == null)
        ExportNotice.PICKER_CANCELLED
        else ExportNotice.EXPORT_CANCELLED
    ExportPhase.FAILED -> ExportNotice.EXPORT_FAILED
    ExportPhase.CLEANUP_PENDING -> ExportNotice.EXPORT_CLEANUP_PENDING
    else -> ExportNotice.EXPORT_RECOVERY_REQUIRED
}

internal fun shareFailureNotice(error: ShareError): ExportNotice = when (error) {
    ShareError.INITIALIZATION_FAILED -> ExportNotice.SHARE_INITIALIZATION_FAILED
    ShareError.SOURCE_TOO_LARGE -> ExportNotice.SHARE_SOURCE_TOO_LARGE
    ShareError.COPY_CAPACITY -> ExportNotice.SHARE_COPY_CAPACITY
    ShareError.PROCESS_CAPACITY -> ExportNotice.SHARE_PROCESS_CAPACITY
    ShareError.CLEANUP_PENDING -> ExportNotice.SHARE_CLEANUP_PENDING
    ShareError.RELEASE_UNCONFIRMED -> ExportNotice.SHARE_RELEASE_UNCONFIRMED
    ShareError.CANCELLED -> ExportNotice.SHARE_CANCELLED
    ShareError.IO -> ExportNotice.SHARE_IO
}
