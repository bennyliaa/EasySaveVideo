package com.easysavevideo.app.library.export

import java.io.File
import org.junit.Assert.*
import org.junit.Test

/** Wiring/ownership contracts only; runtime/device acceptance is separate. */
class LibraryExportLocalizationSourceContractTest {
    private fun source(path: String) = File("src/main/kotlin/com/easysavevideo/app/$path").readText()
    private val runtime get() = source("library/export/AndroidExportRuntime.kt")
    private val status get() = source("library/LibraryExportStatus.kt")
    private val dialog get() = source("library/LibraryExportDialog.kt")
    private val presentation get() = source("library/export/ExportPresentation.kt")
    private val renderer get() = source("library/export/LibraryExportResources.kt")
    private val port get() = source("library/export/AndroidExportPort.kt")
    private fun section(value: String, start: String, end: String): String {
        assertTrue("Missing $start", value.contains(start))
        val rest = value.substringAfter(start)
        assertTrue("Missing $end", rest.contains(end))
        return rest.substringBefore(end)
    }

    @Test fun publicSnapshotsCarryTypedFactsAndLiteralNamesWithoutCachedProductCopy() {
        assertTrue(runtime.contains("val notice: ExportNotice? = null"))
        val row = section(runtime, "data class UnverifiedExportView(", "/** UI snapshots")
        for (field in listOf("val operationId: String", "val source: MediaReadRef", "val sourceName: String?",
            "val sanitizedProviderLabel: String?", "val recordOrder: Long", "val canAttemptCleanup: Boolean",
            "val status: UnverifiedExportStatus")) assertTrue(row.contains(field))
        assertFalse(row.contains("val label:")); assertFalse(row.contains("val status: String"))
        assertTrue(row.contains("UnverifiedExportView([redacted])"))
        assertTrue(presentation.contains("enum class ExportNotice")); assertTrue(presentation.contains("enum class UnverifiedExportStatus"))
        val instanceFields = ExportNotice::class.java.declaredFields.filterNot { it.isSynthetic || java.lang.reflect.Modifier.isStatic(it.modifiers) }
        assertTrue(instanceFields.isEmpty())
        for (text in listOf(runtime, status, dialog, presentation, renderer, port)) {
            assertFalse("Owned text must be in resources", text.contains(Regex("[\\p{IsHan}]")))
        }
        for (forbidden in listOf("getString(", "stringResource(", "LocalConfiguration", "Locale", "String.format",
            "exportNoticeText(", "unverifiedExportLabel(", "LibraryExportText", "failure.message", "failure.toString()")) {
            assertFalse("Runtime owns no translated text: $forbidden", runtime.contains(forbidden))
        }
        assertTrue(runtime.contains("if (failure is ShareFailure) shareFailureNotice(failure.code)"))
        assertTrue(runtime.contains("failure is ExportFailure && failure.code == ExportError.CAPACITY"))
        assertTrue(runtime.contains("(failure as? ShareFailure)?.diagnostic"))
    }

    @Test fun unknownProviderFallbackRetainsSanitizationAndMetadataOrderWithoutReconstructingAuthority() {
        val label = section(port, "fun destinationLabel(operationId: String): String?", "fun releaseFinishedGrant")
        assertTrue(label.contains("val target = journal.target(operationId) ?: return null"))
        assertTrue(label.contains("val authority = target.uri?.let { Uri.parse(it).authority } ?: return null"))
        assertTrue(label.contains("val fallback = safeExportLabel(authority, 80).takeIf { it.isNotBlank() }"))
        assertTrue(label.contains("context.packageManager.resolveContentProvider(authority, 0)"))
        assertTrue(label.contains("provider?.loadLabel(context.packageManager)?.let { safeExportLabel(it, 80) }?.takeIf { it.isNotBlank() } ?: fallback"))
        assertTrue(label.contains("catch (_: Exception) { fallback }"))
        for (forbidden in listOf("acceptSaf", "requireSaf", "takePersistable", "getString", "read", "open", "grantUriPermission"))
            assertFalse("Label lookup cannot acquire authority: $forbidden", label.contains(forbidden))
        val review = section(runtime, "private fun readReviews(", "private fun ExportViewState.withReviews(")
        assertTrue(review.contains("item.displayName else null"))
        assertTrue(review.contains("val supported = record.verification == ExportVerification.READBACK_UNSUPPORTED && port.hasLiveSafGrant(record.operationId)"))
        assertTrue(review.contains("UnverifiedExportView(record.operationId, source, sourceName, destination, entry.order, supported,"))
        assertTrue(review.contains("if (!port.hasLiveSafGrant(record.operationId)) UnverifiedExportStatus.GRANT_UNAVAILABLE"))
        assertTrue(review.contains("else if (record.verification == ExportVerification.READBACK_UNSUPPORTED) UnverifiedExportStatus.COPIED_UNVERIFIED"))
        assertTrue(review.contains("else UnverifiedExportStatus.RECOVERY_REQUIRED"))
        assertFalse(review.contains("openSource")); assertFalse(review.contains("acceptSaf")); assertFalse(review.contains("getString"))
    }

    @Test fun currentCompositionOnlyRendersFactsAndLocaleChangesCannotResubmitOrGrantCleanup() {
        for (ui in listOf(status, dialog)) {
            assertTrue(ui.contains("val locale = LocalConfiguration.current.locales[0]"))
            assertTrue(ui.contains("val resources = LocalContext.current.resources"))
            assertTrue(ui.contains("resources.getString(resource, *arguments)"))
        }
        assertTrue(status.contains("exportNoticeText(it, locale, text)"))
        assertTrue(status.contains("unverifiedExportLabel(confirmation, locale, text)"))
        assertTrue(status.contains("unverifiedExportLabel(entry, locale, text)"))
        assertTrue(status.contains("stringResource(unverifiedExportStatusResource(entry.status))"))
        assertTrue(status.contains("selected.canAttemptCleanup && selected in current"))
        assertTrue(status.contains("LaunchedEffect(foreground, state.unverified)"))
        assertTrue(status.contains("cleanupConfirmation?.let { it !in state.unverified } == true"))
        assertTrue(status.contains("exports.cleanupUnverified(confirmation.operationId)"))
        for (ui in listOf(status, dialog)) {
            assertFalse(ui.contains("LaunchedEffect(locale")); assertFalse(ui.contains("DisposableEffect(locale"))
        }
        for (forbidden in listOf("Context", "Resources", "Handler", "Intent", "Uri", "coordinator", "storage.", "journal.",
            "revokeShares(", "revokeAll(", "cleanupUnverified(", "getDefault(", "setDefault(", "toInt()")) {
            assertFalse("Renderer must only format: $forbidden", renderer.contains(forbidden))
        }
        assertTrue(renderer.contains("entry.sourceName ?:")); assertTrue(renderer.contains("entry.sanitizedProviderLabel ?:"))
        assertTrue(renderer.contains("TimeUnit.MILLISECONDS.toMinutes(SharePolicy.TTL_MILLIS)"))
        assertTrue(renderer.contains("libraryBytes(SharePolicy.MAX_COPY_BYTES, locale)"))
        assertTrue(renderer.contains("libraryBytes(SharePolicy.MAX_TOTAL_BYTES, locale)"))
        assertTrue(dialog.contains("item.sizeBytes in 1..SharePolicy.MAX_COPY_BYTES"))
        assertEquals(1, Regex("verticalScroll\\(").findAll(dialog).count())
        assertTrue(status.contains("FlowRow(horizontalArrangement"))
    }

    @Test fun allDirectReadInputsAreRegisteredForGradleTestInvalidation() {
        val build = File("build.gradle.kts").readText()
        val sources = section(build, "val contractSourceInputs = files(", "tasks.withType<Test>()")
        for (file in listOf("AndroidExportRuntime.kt", "LibraryExportStatus.kt", "LibraryExportDialog.kt",
            "ExportPresentation.kt", "LibraryExportResources.kt", "AndroidExportPort.kt")) {
            assertTrue("Missing source input $file", sources.contains(file))
        }
        val resources = section(build, "val contractResourceInputs =", "val contractSourceInputs =")
        assertTrue(resources.contains("\"library_export_localization.xml\""))
        assertTrue(resources.contains("\"values\", \"values-zh-rCN\""))
    }
}
