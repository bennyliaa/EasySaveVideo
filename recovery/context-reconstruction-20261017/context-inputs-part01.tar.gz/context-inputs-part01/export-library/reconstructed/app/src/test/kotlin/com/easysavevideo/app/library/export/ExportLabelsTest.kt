package com.easysavevideo.app.library.export

import org.junit.Assert.*
import com.easysavevideo.library.MediaReadRef
import java.util.Locale
import org.junit.Test

class ExportLabelsTest {
    @Test fun labelIsBoundedWithoutCuttingSurrogates() {
        assertEquals("123", safeExportLabel("123😀", 4))
        assertEquals("123😀", safeExportLabel("123😀", 5))
        assertEquals(80, safeExportLabel("a".repeat(1000), 80).length)
    }
    @Test fun controlsAndBidiCannotSpoofCleanupTarget() {
        assertEquals("Drive document", safeExportLabel("Drive\n\u202e document\u0000", 80))
        assertEquals("safe", safeExportLabel("\ud800safe\udfff", 80))
    }
    @Test fun providerLabelsRemainSanitizedLiteralDataInBothLocales() {
        val label = safeExportLabel("Drive\n\u202e 我的 %1\$s documents\u0000", 80)
        val row = UnverifiedExportView("op", MediaReadRef("item", 1, 1), "Video", label, 1,
            false, UnverifiedExportStatus.GRANT_UNAVAILABLE)
        for ((folder, locale) in listOf("values" to Locale.US, "values-zh-rCN" to Locale.SIMPLIFIED_CHINESE)) {
            val rendered = unverifiedExportLabel(row, locale, libraryExportResourceText(folder, locale))
            assertTrue(rendered.contains(label)); assertFalse(rendered.contains('\u202e')); assertFalse(rendered.contains('\n'))
            assertTrue(rendered.contains("%1\$s"))
        }
    }
}
