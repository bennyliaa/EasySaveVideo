package com.easysavevideo.app.library.export

import com.easysavevideo.app.R
import com.easysavevideo.app.library.libraryBytes
import com.easysavevideo.app.library.unverifiedCleanupStillCurrent
import com.easysavevideo.app.library.share.SharePolicy
import com.easysavevideo.library.MediaReadRef
import com.easysavevideo.library.export.ExportLimits
import java.text.NumberFormat
import java.util.Locale
import java.util.concurrent.TimeUnit
import org.junit.Assert.*
import org.junit.Test

/** Production renderers against actual resources; no Android, provider or device acceptance. */
class LibraryExportLocalizationTest {
    private val locales = listOf("values" to Locale.US, "values-zh-rCN" to Locale.SIMPLIFIED_CHINESE)

    @Test fun allThirtyNineNoticeFactsResolveBothLanguagesAndTheirActualArguments() {
        assertEquals(39, ExportNotice.entries.size)
        for ((folder, locale) in locales) {
            val strings = libraryExportResourceStrings(folder)
            val text = libraryExportResourceText(folder, locale)
            val used = mutableSetOf<String>()
            for (notice in ExportNotice.entries) {
                val expectedName = "library_export_notice_${notice.name.lowercase(Locale.ROOT)}"
                assertEquals(expectedName, libraryExportResourceName(exportNoticeResource(notice)))
                assertTrue(used.add(expectedName))
                val count = { value: Long -> NumberFormat.getIntegerInstance(locale).format(value) }
                val arguments: Array<out Any> = when (notice) {
                    ExportNotice.SHARE_CHOOSER_OPENED -> arrayOf(count(TimeUnit.MILLISECONDS.toMinutes(SharePolicy.TTL_MILLIS)), count(SharePolicy.MAX_OPENS.toLong()))
                    ExportNotice.BATCH_SHARE_LIMIT -> arrayOf(count(SharePolicy.MAX_COPIES.toLong()), libraryBytes(SharePolicy.MAX_COPY_BYTES, locale), libraryBytes(SharePolicy.MAX_TOTAL_BYTES, locale))
                    ExportNotice.BATCH_SHARE_CHOOSER_OPENED -> arrayOf(count(TimeUnit.MILLISECONDS.toMinutes(SharePolicy.TTL_MILLIS)))
                    ExportNotice.EXPORT_CAPACITY -> arrayOf(count(ExportLimits.MAX_ACTIVE.toLong()))
                    ExportNotice.SHARE_SOURCE_TOO_LARGE -> arrayOf(libraryBytes(SharePolicy.MAX_COPY_BYTES, locale))
                    ExportNotice.SHARE_COPY_CAPACITY -> arrayOf(count(SharePolicy.MAX_COPIES.toLong()), libraryBytes(SharePolicy.MAX_TOTAL_BYTES, locale))
                    else -> emptyArray()
                }
                val rendered = exportNoticeText(notice, locale, text)
                assertEquals("$folder/$notice", String.format(locale, strings.getValue(expectedName), *arguments), rendered)
                assertTrue(rendered.isNotBlank()); assertFalse(rendered.contains(Regex("%[0-9]+\\$[sd]")))
            }
            assertEquals(strings.keys.filter { it.startsWith("library_export_notice_") }.toSet(), used)
        }
    }

    @Test fun allResourcesAndPlaceholdersMatchAcrossLanguagesWithoutHardcodedNumericLimits() {
        val english = libraryExportResourceStrings("values")
        val chinese = libraryExportResourceStrings("values-zh-rCN")
        assertEquals(77, english.size); assertEquals(english.keys, chinese.keys)
        val placeholders = Regex("%[0-9]+\\$[sd]")
        for (key in english.keys) {
            assertTrue(english.getValue(key).isNotBlank()); assertTrue(chinese.getValue(key).isNotBlank())
            assertEquals(key, placeholders.findAll(english.getValue(key)).map { it.value }.toList(),
                placeholders.findAll(chinese.getValue(key)).map { it.value }.toList())
        }
        for (key in listOf("library_export_share_warning", "library_export_notice_share_chooser_opened",
            "library_export_notice_batch_share_limit", "library_export_notice_batch_share_chooser_opened",
            "library_export_notice_export_capacity", "library_export_notice_share_source_too_large",
            "library_export_notice_share_copy_capacity")) {
            for (strings in listOf(english, chinese)) {
                val withoutPlaceholders = strings.getValue(key).replace(placeholders, "")
                assertFalse("$key contains a policy number", withoutPlaceholders.any { it.isDigit() })
            }
        }
    }

    @Test fun everyReviewStatusPreservesUnverifiedAndManualReviewMeaning() {
        val expectedNames = mapOf(
            UnverifiedExportStatus.GRANT_UNAVAILABLE to "library_export_review_grant_unavailable",
            UnverifiedExportStatus.COPIED_UNVERIFIED to "library_export_review_copied_unverified",
            UnverifiedExportStatus.RECOVERY_REQUIRED to "library_export_review_recovery_required",
        )
        assertEquals(UnverifiedExportStatus.entries.toSet(), expectedNames.keys)
        for ((folder, locale) in locales) {
            val text = libraryExportResourceText(folder, locale)
            val rendered = expectedNames.map { (status, resource) ->
                assertEquals(resource, libraryExportResourceName(unverifiedExportStatusResource(status)))
                text.get(unverifiedExportStatusResource(status)).also { assertTrue(it.isNotBlank()) }
            }
            assertEquals(3, rendered.toSet().size)
            assertTrue(rendered[0].contains(if (folder == "values") "manually" else "手动核对"))
            assertTrue(rendered[1].contains(if (folder == "values") "not fully verified" else "未完整校验"))
            assertTrue(rendered[2].contains(if (folder == "values") "recovery check" else "恢复检查"))
        }
    }

    @Test fun unknownSourceAndProviderAreLocalizedOnlyAtRenderTimeAndExternalNamesStayLiteral() {
        val unknown = UnverifiedExportView("operation-unique", MediaReadRef("item-0123456789", 3, 1), null, null,
            2, false, UnverifiedExportStatus.GRANT_UNAVAILABLE)
        val english = unverifiedExportLabel(unknown, Locale.US, libraryExportResourceText("values", Locale.US))
        val chinese = unverifiedExportLabel(unknown, Locale.SIMPLIFIED_CHINESE, libraryExportResourceText("values-zh-rCN", Locale.SIMPLIFIED_CHINESE))
        assertEquals("Library item item-012 → Selected file provider · Export record #2", english)
        assertEquals("媒体库项目 item-012 → 所选文件提供方 · 导出记录 #2", chinese)
        assertNull(unknown.sourceName); assertNull(unknown.sanitizedProviderLabel)
        val named = unknown.copy(sourceName = "旅程 100% %1\$s.mp4", sanitizedProviderLabel = "Drive 相册 %2\$s")
        for ((folder, locale) in locales) {
            val rendered = unverifiedExportLabel(named, locale, libraryExportResourceText(folder, locale))
            assertTrue(rendered.startsWith("旅程 100% %1\$s.mp4 → Drive 相册 %2\$s · "))
            assertFalse(rendered.contains("operation-unique")); assertFalse(rendered.contains("item-012"))
        }
    }

    @Test fun longCountsAreLocaleFormattedWithoutIntTruncationOrSingularPluralAssumptions() {
        for ((folder, locale) in locales) {
            val text = libraryExportResourceText(folder, locale)
            for (count in listOf(0L, 1L, 2L, Int.MAX_VALUE.toLong() + 1, Long.MAX_VALUE)) {
                val number = NumberFormat.getIntegerInstance(locale).format(count)
                assertEquals(number, libraryExportCount(count, locale))
                for (resource in listOf(R.string.library_export_recoverable, R.string.library_export_review_count)) {
                    assertTrue(text.get(resource, libraryExportCount(count, locale)).contains(number))
                }
                val page = text.get(R.string.library_export_review_page, number, number, number)
                assertEquals(3, Regex(Regex.escape(number)).findAll(page).count())
                val row = UnverifiedExportView("operation", MediaReadRef("source", 1, 1), "Video", "Provider", count,
                    true, UnverifiedExportStatus.COPIED_UNVERIFIED)
                assertTrue(unverifiedExportLabel(row, locale, text).endsWith("#$number"))
            }
        }
        assertEquals("9,223,372,036,854,775,807", libraryExportCount(Long.MAX_VALUE, Locale.US))
        val original = Locale.getDefault()
        assertEquals("١٬٢٣٤", libraryExportCount(1234, Locale.forLanguageTag("ar-EG")))
        assertEquals(original, Locale.getDefault())
    }

    @Test fun cachedSnapshotReformatsEnglishChineseEnglishWithoutChangingCleanupConsentOrOperations() {
        val row = UnverifiedExportView("operation", MediaReadRef("source-id", 7, 9), null, null, 42,
            true, UnverifiedExportStatus.COPIED_UNVERIFIED)
        val snapshot = ExportViewState(notice = ExportNotice.SHARES_REVOKED_CLEANUP_PENDING, recoverable = 2,
            unverified = listOf(row), unverifiedCount = 1, unverifiedPages = 1)
        val before = snapshot.copy()
        val outputs = listOf(locales[0], locales[1], locales[0]).map { (folder, locale) ->
            val text = libraryExportResourceText(folder, locale)
            listOf(exportNoticeText(requireNotNull(snapshot.notice), locale, text), unverifiedExportLabel(row, locale, text),
                text.get(unverifiedExportStatusResource(row.status)), text.get(R.string.library_export_review_count, libraryExportCount(snapshot.unverifiedCount, locale)))
                .also {
                    assertEquals(before, snapshot)
                    assertSame(row, snapshot.unverified.single())
                    assertTrue(unverifiedCleanupStillCurrent(row, snapshot.unverified, true, false))
                    assertEquals("operation", row.operationId); assertEquals(7L, row.source.revision)
                    assertFalse(snapshot.busy); assertFalse(snapshot.canCancel)
                }
        }
        assertEquals(outputs.first(), outputs.last())
        assertNotEquals(outputs[0], outputs[1])
        val unavailable = row.copy(canAttemptCleanup = false, status = UnverifiedExportStatus.GRANT_UNAVAILABLE)
        for ((folder, locale) in locales) {
            unverifiedExportLabel(unavailable, locale, libraryExportResourceText(folder, locale))
            assertFalse(unverifiedCleanupStillCurrent(row, listOf(unavailable), true, false))
            assertFalse(unverifiedCleanupStillCurrent(unavailable, listOf(unavailable), true, false))
        }
    }

    @Test fun chooserReceiptIsNeverDeliveryAndCleanupUncertaintyNeverBecomesSuccess() {
        for ((folder, locale) in locales) {
            val text = libraryExportResourceText(folder, locale)
            for (notice in listOf(ExportNotice.SHARE_CHOOSER_OPENED, ExportNotice.BATCH_SHARE_CHOOSER_OPENED)) {
                assertTrue(exportNoticeText(notice, locale, text).contains(if (folder == "values") "delivery" else "不代表送达"))
            }
            for (notice in listOf(ExportNotice.SHARES_REVOKED_CLEANED, ExportNotice.SHARES_REVOKED_CLEANUP_PENDING,
                ExportNotice.BATCH_SHARE_CHOOSER_UNCONFIRMED)) {
                assertTrue(exportNoticeText(notice, locale, text).contains(if (folder == "values") "recall" else "收回"))
            }
            assertTrue(exportNoticeText(ExportNotice.SHARES_REVOKED_CLEANUP_PENDING, locale, text)
                .contains(if (folder == "values") "unconfirmed" else "待确认"))
            assertTrue(exportNoticeText(ExportNotice.COPIED_UNVERIFIED, locale, text)
                .contains(if (folder == "values") "integrity is unconfirmed" else "不能确认副本完整性"))
            assertTrue(exportNoticeText(ExportNotice.EXPORT_CLEANUP_PENDING, locale, text)
                .contains(if (folder == "values") "unconfirmed" else "待确认"))
            assertTrue(text.get(R.string.library_export_cleanup_warning).contains(if (folder == "values") "permanently" else "永久"))
            val warning = exportShareWarning(locale, text)
            assertTrue(warning.contains(libraryBytes(SharePolicy.MAX_COPY_BYTES, locale)))
            assertTrue(warning.contains(libraryBytes(SharePolicy.MAX_TOTAL_BYTES, locale)))
            assertTrue(warning.contains(libraryExportCount(TimeUnit.MILLISECONDS.toMinutes(SharePolicy.TTL_MILLIS), locale)))
            assertTrue(warning.contains(libraryExportCount(SharePolicy.MAX_COPIES.toLong(), locale)))
            assertTrue(warning.contains(libraryExportCount(SharePolicy.MAX_OPENS.toLong(), locale)))
        }
    }
}
