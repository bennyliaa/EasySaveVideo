package com.easysavevideo.app.library

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import com.easysavevideo.app.R
import com.easysavevideo.app.library.export.LibraryExportText
import com.easysavevideo.app.library.export.exportShareWarning
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.easysavevideo.app.theme.*
import com.easysavevideo.app.library.share.SharePolicy
import com.easysavevideo.library.MediaItem
import com.easysavevideo.library.MediaReadRef

internal enum class LibraryExportDestination { GALLERY, FILES, SHARE }

/** Foreground, exact-version choice only. It carries no system permission or stored destination. */
internal fun exportSelectionIsCurrent(reference: MediaReadRef, items: List<MediaItem>, foreground: Boolean): Boolean =
    foreground && items.any { it.lifecycle == com.easysavevideo.library.MediaLifecycle.READY && it.readRef() == reference }

@Composable
internal fun LibraryExportDialog(
    item: MediaItem,
    enabled: Boolean,
    onChoose: (LibraryExportDestination) -> Unit,
    onDismiss: () -> Unit,
) {
    val v = LocalEsvVisuals.current
    val locale = LocalConfiguration.current.locales[0]
    val resources = LocalContext.current.resources
    val text = LibraryExportText { resource, arguments -> resources.getString(resource, *arguments) }
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.widthIn(max = 680.dp).fillMaxWidth().heightIn(max = 720.dp)
            .background(v.colors.surface, RoundedCornerShape(v.corner))
            .verticalScroll(rememberScrollState()).padding(v.spacingLarge),
            verticalArrangement = Arrangement.spacedBy(v.spacingMedium)) {
            EsvText(stringResource(R.string.library_export_dialog_title), style = v.titleTextStyle)
            EsvText(item.displayName)
            EsvText(stringResource(R.string.library_export_dialog_size, libraryBytes(item.sizeBytes, locale)), style = v.captionTextStyle)
            EsvText(stringResource(R.string.library_export_dialog_scope), style = v.captionTextStyle)
            EsvText(stringResource(R.string.library_export_gallery_warning), style = v.captionTextStyle, color = v.colors.muted)
            EsvButton(stringResource(R.string.library_export_gallery_action), { onChoose(LibraryExportDestination.GALLERY) }, enabled = enabled, modifier = Modifier.fillMaxWidth())
            EsvText(stringResource(R.string.library_export_files_warning), style = v.captionTextStyle, color = v.colors.muted)
            EsvButton(stringResource(R.string.library_export_files_action), { onChoose(LibraryExportDestination.FILES) }, enabled = enabled, modifier = Modifier.fillMaxWidth())
            EsvText(exportShareWarning(locale, text), style = v.captionTextStyle, color = v.colors.muted)
            if (item.sizeBytes > SharePolicy.MAX_COPY_BYTES) EsvText(stringResource(R.string.library_export_share_oversize), style = v.captionTextStyle, color = v.colors.muted)
            EsvButton(stringResource(R.string.library_export_share_action), { onChoose(LibraryExportDestination.SHARE) }, enabled = enabled && item.sizeBytes in 1..SharePolicy.MAX_COPY_BYTES, modifier = Modifier.fillMaxWidth())
            EsvButton(stringResource(R.string.library_export_dialog_cancel), onDismiss, modifier = Modifier.fillMaxWidth())
        }
    }
}
