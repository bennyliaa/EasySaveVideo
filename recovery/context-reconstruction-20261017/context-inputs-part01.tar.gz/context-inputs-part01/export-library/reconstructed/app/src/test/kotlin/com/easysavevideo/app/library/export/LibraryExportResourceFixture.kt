package com.easysavevideo.app.library.export

import com.easysavevideo.app.R
import java.io.File
import java.util.Locale
import javax.xml.parsers.DocumentBuilderFactory

internal fun libraryExportResourceStrings(folder: String): Map<String, String> {
    val document = DocumentBuilderFactory.newInstance().newDocumentBuilder()
        .parse(File("src/main/res/$folder/library_export_localization.xml"))
    val strings = document.getElementsByTagName("string")
    return (0 until strings.length).associate { index ->
        val entry = strings.item(index)
        entry.attributes.getNamedItem("name").nodeValue to entry.textContent.replace("\\'", "'")
    }
}

internal fun libraryExportResourceName(id: Int): String = R.string::class.java.fields.single { it.getInt(null) == id }.name

internal fun libraryExportResourceText(folder: String, locale: Locale): LibraryExportText {
    val strings = libraryExportResourceStrings(folder)
    return LibraryExportText { resource, arguments ->
        String.format(locale, strings.getValue(libraryExportResourceName(resource)), *arguments)
    }
}
