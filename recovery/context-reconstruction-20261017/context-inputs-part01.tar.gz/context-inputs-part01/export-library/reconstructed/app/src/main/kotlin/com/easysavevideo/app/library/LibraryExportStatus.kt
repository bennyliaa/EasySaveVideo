package com.easysavevideo.app.library

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import com.easysavevideo.app.BuildConfig
import com.easysavevideo.app.diagnostics.initializationDiagnosticText
import com.easysavevideo.app.R
import com.easysavevideo.library.export.BatchTransferStatus
import com.easysavevideo.app.library.export.AndroidExportRuntime
import com.easysavevideo.app.library.export.UnverifiedExportView
import com.easysavevideo.app.library.export.LibraryExportText
import com.easysavevideo.app.library.export.libraryExportCount
import com.easysavevideo.app.library.export.exportNoticeText
import com.easysavevideo.app.library.export.unverifiedExportLabel
import com.easysavevideo.app.library.export.unverifiedExportStatusResource
import com.easysavevideo.app.library.export.DirectoryExportNotice
import com.easysavevideo.app.library.export.ExportRecoveryStatus
import com.easysavevideo.app.library.export.ExportRecoveryFailure
import com.easysavevideo.app.library.export.ExportRecoveryRetryAction
import com.easysavevideo.app.library.export.offerExportRecoveryRetry
import com.easysavevideo.app.theme.*

internal fun unverifiedCleanupStillCurrent(
    selected: UnverifiedExportView,
    current: List<UnverifiedExportView>,
    foreground: Boolean,
    busy: Boolean,
): Boolean = foreground && !busy && selected.canAttemptCleanup && selected in current

/** Output responsibilities remain visible independently of source selection and the latest notice. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun LibraryExportStatus(exports: AndroidExportRuntime, foreground: Boolean, isCurrent: () -> Boolean) {
    val state = exports.state
    val v = LocalEsvVisuals.current
    val locale = LocalConfiguration.current.locales[0]
    val resources = LocalContext.current.resources
    val text = LibraryExportText { resource, arguments -> resources.getString(resource, *arguments) }
    val currentForeground by rememberUpdatedState(foreground)
    val currentRuntime by rememberUpdatedState(exports)
    val currentAdmission by rememberUpdatedState(isCurrent)
    val retryAction = remember(exports) {
        ExportRecoveryRetryAction({
            currentForeground && currentRuntime === exports && currentAdmission() && !exports.state.busy &&
                offerExportRecoveryRetry(exports.state.recoveryCheck, exports.state.recoverable)
        }, exports::retry)
    }
    DisposableEffect(retryAction) { onDispose { retryAction.close() } }
    var showingUnverified by remember { mutableStateOf(false) }
    var cleanupConfirmation by remember { mutableStateOf<UnverifiedExportView?>(null) }
    LaunchedEffect(foreground, state.unverified) {
        if (!foreground) { showingUnverified = false; cleanupConfirmation = null }
        else if (cleanupConfirmation?.let { it !in state.unverified } == true) cleanupConfirmation = null
    }
    Column(verticalArrangement = Arrangement.spacedBy(v.spacingSmall)) {
        if (state.busy) EsvText(stringResource(R.string.library_export_busy), style = v.captionTextStyle)
        state.notice?.let { EsvText(exportNoticeText(it, locale, text), style = v.captionTextStyle) }
        initializationDiagnosticText(BuildConfig.DEBUG, state.initializationDiagnostic)?.let {
            EsvText(it, style = v.captionTextStyle, color = v.colors.muted)
        }
        state.directoryNotice?.let { notice -> EsvText(stringResource(when(notice) {
            DirectoryExportNotice.PICKING -> R.string.directory_picking
            DirectoryExportNotice.CONFIRM -> R.string.directory_confirm_notice
            DirectoryExportNotice.COPYING -> R.string.directory_copying
            DirectoryExportNotice.COMPLETED -> R.string.directory_completed
            DirectoryExportNotice.STOPPED -> R.string.directory_stopped
            DirectoryExportNotice.STALE -> R.string.directory_stale
            DirectoryExportNotice.UNAVAILABLE -> R.string.directory_unavailable
            DirectoryExportNotice.UNCERTAIN -> R.string.directory_uncertain
            DirectoryExportNotice.INTERRUPTED -> R.string.directory_interrupted
        }),style=v.captionTextStyle) }
        val directoryConfirmation = state.directoryConfirmation
        if(directoryConfirmation!=null)EsvButton(stringResource(R.string.directory_confirm_copy),
            { exports.confirmBatchFolderCopy(directoryConfirmation) },
            enabled=foreground && exports.canConfirmBatchFolder(directoryConfirmation),modifier=Modifier.fillMaxWidth())
        state.batchResults.forEachIndexed { index,result ->
            state.batchNames.getOrNull(index)?.let { EsvText(it,maxLines=2,style=v.captionTextStyle) }
            EsvText(stringResource(R.string.library_batch_move_item,index+1,stringResource(when(result.status) {
                BatchTransferStatus.VERIFIED_COPY -> R.string.library_transfer_verified
                BatchTransferStatus.COPIED_UNVERIFIED -> R.string.library_transfer_unverified
                BatchTransferStatus.STALE -> R.string.library_transfer_stale
                BatchTransferStatus.UNAVAILABLE -> R.string.library_transfer_unavailable
                BatchTransferStatus.FAILED_UNCONFIRMED -> R.string.library_transfer_unknown
                BatchTransferStatus.CANCELLED_BEFORE_START -> R.string.library_transfer_cancelled_before
                BatchTransferStatus.CANCELLED -> R.string.library_transfer_cancelled
                BatchTransferStatus.CLEANUP_PENDING -> R.string.library_transfer_cleanup
                BatchTransferStatus.PREPARED -> R.string.library_transfer_prepared
                BatchTransferStatus.CHOOSER_OPENED -> R.string.library_transfer_chooser
                BatchTransferStatus.AUTHORITY_REVOKED -> R.string.library_transfer_revoked
                BatchTransferStatus.NOT_STARTED -> R.string.library_transfer_not_started
                BatchTransferStatus.TARGET_UNAVAILABLE -> R.string.library_transfer_target_unavailable
            })),style=v.captionTextStyle)
        }
        if(state.batchCleanupPending)EsvText(stringResource(R.string.library_batch_cleanup_pending),color=v.colors.error,style=v.captionTextStyle)
        if (state.recoverable > 0) {
            EsvText(stringResource(R.string.library_export_recoverable, libraryExportCount(state.recoverable, locale)), style = v.captionTextStyle, color = v.colors.error)
        }
        val recovery = state.recoveryCheck
        EsvText(stringResource(when (recovery.status) {
            ExportRecoveryStatus.UNKNOWN -> R.string.export_recovery_unknown
            ExportRecoveryStatus.CHECKING -> R.string.export_recovery_checking
            ExportRecoveryStatus.FAILED -> if (recovery.failure == ExportRecoveryFailure.QUEUE_BUSY)
                R.string.export_recovery_queue_busy else R.string.export_recovery_failed
            ExportRecoveryStatus.CHECKED -> R.string.export_recovery_checked
        }), style = v.captionTextStyle)
        if (recovery.status == ExportRecoveryStatus.CHECKING && recovery.failure != null)
            EsvText(stringResource(if (recovery.failure == ExportRecoveryFailure.QUEUE_BUSY)
                R.string.export_recovery_queue_busy else R.string.export_recovery_failed), style = v.captionTextStyle)
        if (offerExportRecoveryRetry(recovery, state.recoverable)) {
            EsvText(stringResource(R.string.export_recovery_scope), style = v.captionTextStyle)
            EsvButton(stringResource(R.string.export_recovery_retry), retryAction::invoke,
                enabled = foreground && !state.busy && recovery.status != ExportRecoveryStatus.CHECKING,
                modifier = Modifier.fillMaxWidth())
        }
        if (state.unverifiedCount > 0) {
            EsvText(stringResource(R.string.library_export_review_count, libraryExportCount(state.unverifiedCount, locale)), style = v.captionTextStyle, color = v.colors.muted)
            EsvButton(stringResource(R.string.library_export_review_open), { showingUnverified = true }, enabled = foreground && !state.busy, modifier = Modifier.fillMaxWidth())
        }
        if (state.canCancel) EsvButton(stringResource(R.string.library_export_cancel_operation), exports::cancel, enabled = foreground, modifier = Modifier.fillMaxWidth())
        EsvButton(stringResource(R.string.library_export_revoke_shares), exports::revokeShares, enabled = foreground && !state.busy, modifier = Modifier.fillMaxWidth())
        EsvText(stringResource(R.string.library_export_revoke_scope), style = v.captionTextStyle, color = v.colors.muted)
    }
    val confirmation = cleanupConfirmation
    if (confirmation != null && foreground && confirmation in state.unverified) {
        LibraryDialog(onDismiss = { cleanupConfirmation = null }) {
            EsvText(stringResource(R.string.library_export_cleanup_title), style = v.titleTextStyle)
            EsvText(unverifiedExportLabel(confirmation, locale, text))
            EsvText(stringResource(R.string.library_export_operation, confirmation.operationId), style = v.captionTextStyle, color = v.colors.muted)
            EsvText(stringResource(R.string.library_export_source, confirmation.source.itemId, libraryExportCount(confirmation.source.revision, locale)), style = v.captionTextStyle, color = v.colors.muted)
            EsvText(stringResource(R.string.library_export_cleanup_warning))
            EsvButton(stringResource(R.string.library_export_cleanup_confirm), {
                if (unverifiedCleanupStillCurrent(confirmation, state.unverified, foreground, state.busy)) {
                    cleanupConfirmation = null
                    exports.cleanupUnverified(confirmation.operationId)
                }
            }, enabled = unverifiedCleanupStillCurrent(confirmation, state.unverified, foreground, state.busy), modifier = Modifier.fillMaxWidth())
            EsvButton(stringResource(R.string.library_export_cleanup_cancel), { cleanupConfirmation = null }, modifier = Modifier.fillMaxWidth())
        }
    } else if (showingUnverified && foreground) {
        LibraryDialog(onDismiss = { showingUnverified = false }) {
            EsvText(stringResource(R.string.library_export_review_title), style = v.titleTextStyle)
            EsvText(stringResource(R.string.library_export_review_scope), style = v.captionTextStyle, color = v.colors.muted)
            if (state.unverified.isEmpty()) EsvText(stringResource(R.string.library_export_review_empty), style = v.captionTextStyle)
            state.unverified.forEach { entry ->
                Column(verticalArrangement = Arrangement.spacedBy(v.spacingSmall)) {
                    EsvText(unverifiedExportLabel(entry, locale, text), maxLines = 3)
                    EsvText(stringResource(unverifiedExportStatusResource(entry.status)), style = v.captionTextStyle, color = v.colors.muted)
                    EsvButton(stringResource(R.string.library_export_cleanup_action), { cleanupConfirmation = entry },
                        enabled = entry.canAttemptCleanup && !state.busy, modifier = Modifier.fillMaxWidth())
                }
            }
            if (state.unverifiedPages > 0) {
                EsvText(stringResource(R.string.library_export_review_page, libraryExportCount(state.unverifiedPage + 1, locale),
                    libraryExportCount(state.unverifiedPages, locale), libraryExportCount(state.unverifiedCount, locale)), style = v.captionTextStyle)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(v.spacingSmall), verticalArrangement = Arrangement.spacedBy(v.spacingSmall)) {
                    EsvButton(stringResource(R.string.library_export_review_previous), { exports.unverifiedPage(state.unverifiedPage - 1) }, enabled = !state.busy && state.unverifiedPage > 0)
                    EsvButton(stringResource(R.string.library_export_review_next), { exports.unverifiedPage(state.unverifiedPage + 1) }, enabled = !state.busy && state.unverifiedPage + 1 < state.unverifiedPages)
                }
            }
            EsvButton(stringResource(R.string.library_export_review_close), { showingUnverified = false }, modifier = Modifier.fillMaxWidth())
        }
    }
}
