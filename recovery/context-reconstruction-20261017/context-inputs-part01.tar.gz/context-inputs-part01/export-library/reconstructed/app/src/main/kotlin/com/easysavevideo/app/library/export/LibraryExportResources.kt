package com.easysavevideo.app.library.export

import com.easysavevideo.app.R
import com.easysavevideo.app.library.libraryBytes
import com.easysavevideo.app.library.share.SharePolicy
import com.easysavevideo.library.export.ExportLimits
import java.text.NumberFormat
import java.util.Locale
import java.util.concurrent.TimeUnit

/** A render-time reader only. Never stored in ExportViewState or captured by runtime work. */
internal fun interface LibraryExportText {
    fun get(resource: Int, vararg arguments: Any): String
}

internal fun libraryExportCount(value: Long, locale: Locale): String = NumberFormat.getIntegerInstance(locale).format(value)

internal fun exportNoticeResource(notice: ExportNotice): Int = when (notice) {
    ExportNotice.EXTRA_COPY_CANCELLATION_PENDING -> R.string.library_export_notice_extra_copy_cancellation_pending
    ExportNotice.EXTRA_COPY_CANCELLATION_QUEUE_BUSY -> R.string.library_export_notice_extra_copy_cancellation_queue_busy
    ExportNotice.PICK_DOCUMENT -> R.string.library_export_notice_pick_document
    ExportNotice.PICKER_RESULT_UNRELATED -> R.string.library_export_notice_picker_result_unrelated
    ExportNotice.DOCUMENT_GRANT_UNAVAILABLE -> R.string.library_export_notice_document_grant_unavailable
    ExportNotice.SHARE_CANCELLED_AFTER_PREPARATION -> R.string.library_export_notice_share_cancelled_after_preparation
    ExportNotice.SHARE_CHOOSER_OPENED -> R.string.library_export_notice_share_chooser_opened
    ExportNotice.SHARE_CHOOSER_UNAVAILABLE -> R.string.library_export_notice_share_chooser_unavailable
    ExportNotice.BATCH_COPY_RESULTS -> R.string.library_export_notice_batch_copy_results
    ExportNotice.BATCH_SHARE_LIMIT -> R.string.library_export_notice_batch_share_limit
    ExportNotice.BATCH_SHARE_CHOOSER_OPENED -> R.string.library_export_notice_batch_share_chooser_opened
    ExportNotice.BATCH_SHARE_CHOOSER_UNCONFIRMED -> R.string.library_export_notice_batch_share_chooser_unconfirmed
    ExportNotice.BATCH_SELECTION_STALE -> R.string.library_export_notice_batch_selection_stale
    ExportNotice.CANCEL_PICKER_REQUESTED -> R.string.library_export_notice_cancel_picker_requested
    ExportNotice.CANCEL_IO_REQUESTED -> R.string.library_export_notice_cancel_io_requested
    ExportNotice.UNVERIFIED_CLEANUP_UNAVAILABLE -> R.string.library_export_notice_unverified_cleanup_unavailable
    ExportNotice.SHARES_REVOKED_CLEANED -> R.string.library_export_notice_shares_revoked_cleaned
    ExportNotice.SHARES_REVOKED_CLEANUP_PENDING -> R.string.library_export_notice_shares_revoked_cleanup_pending
    ExportNotice.EXPORT_CAPACITY -> R.string.library_export_notice_export_capacity
    ExportNotice.RESULT_UNCONFIRMED -> R.string.library_export_notice_result_unconfirmed
    ExportNotice.EXPORT_QUEUE_BUSY -> R.string.library_export_notice_export_queue_busy
    ExportNotice.CONTROL_UNCONFIRMED -> R.string.library_export_notice_control_unconfirmed
    ExportNotice.CONTROL_QUEUE_BUSY -> R.string.library_export_notice_control_queue_busy
    ExportNotice.VERIFIED_GALLERY -> R.string.library_export_notice_verified_gallery
    ExportNotice.VERIFIED_DOCUMENT -> R.string.library_export_notice_verified_document
    ExportNotice.COPIED_UNVERIFIED -> R.string.library_export_notice_copied_unverified
    ExportNotice.PICKER_CANCELLED -> R.string.library_export_notice_picker_cancelled
    ExportNotice.EXPORT_CANCELLED -> R.string.library_export_notice_export_cancelled
    ExportNotice.EXPORT_FAILED -> R.string.library_export_notice_export_failed
    ExportNotice.EXPORT_CLEANUP_PENDING -> R.string.library_export_notice_export_cleanup_pending
    ExportNotice.EXPORT_RECOVERY_REQUIRED -> R.string.library_export_notice_export_recovery_required
    ExportNotice.SHARE_INITIALIZATION_FAILED -> R.string.library_export_notice_share_initialization_failed
    ExportNotice.SHARE_SOURCE_TOO_LARGE -> R.string.library_export_notice_share_source_too_large
    ExportNotice.SHARE_COPY_CAPACITY -> R.string.library_export_notice_share_copy_capacity
    ExportNotice.SHARE_PROCESS_CAPACITY -> R.string.library_export_notice_share_process_capacity
    ExportNotice.SHARE_CLEANUP_PENDING -> R.string.library_export_notice_share_cleanup_pending
    ExportNotice.SHARE_RELEASE_UNCONFIRMED -> R.string.library_export_notice_share_release_unconfirmed
    ExportNotice.SHARE_CANCELLED -> R.string.library_export_notice_share_cancelled
    ExportNotice.SHARE_IO -> R.string.library_export_notice_share_io
}

internal fun exportNoticeText(notice: ExportNotice, locale: Locale, text: LibraryExportText): String {
    val arguments: Array<out Any> = when (notice) {
        ExportNotice.SHARE_CHOOSER_OPENED -> arrayOf(
            libraryExportCount(TimeUnit.MILLISECONDS.toMinutes(SharePolicy.TTL_MILLIS), locale),
            libraryExportCount(SharePolicy.MAX_OPENS.toLong(), locale))
        ExportNotice.BATCH_SHARE_LIMIT -> arrayOf(libraryExportCount(SharePolicy.MAX_COPIES.toLong(), locale),
            libraryBytes(SharePolicy.MAX_COPY_BYTES, locale), libraryBytes(SharePolicy.MAX_TOTAL_BYTES, locale))
        ExportNotice.BATCH_SHARE_CHOOSER_OPENED -> arrayOf(libraryExportCount(TimeUnit.MILLISECONDS.toMinutes(SharePolicy.TTL_MILLIS), locale))
        ExportNotice.EXPORT_CAPACITY -> arrayOf(libraryExportCount(ExportLimits.MAX_ACTIVE.toLong(), locale))
        ExportNotice.SHARE_SOURCE_TOO_LARGE -> arrayOf(libraryBytes(SharePolicy.MAX_COPY_BYTES, locale))
        ExportNotice.SHARE_COPY_CAPACITY -> arrayOf(libraryExportCount(SharePolicy.MAX_COPIES.toLong(), locale),
            libraryBytes(SharePolicy.MAX_TOTAL_BYTES, locale))
        else -> emptyArray()
    }
    return text.get(exportNoticeResource(notice), *arguments)
}

internal fun unverifiedExportLabel(entry: UnverifiedExportView, locale: Locale, text: LibraryExportText): String =
    text.get(R.string.library_export_review_label,
        entry.sourceName ?: text.get(R.string.library_export_review_unknown_source, entry.source.itemId.take(8)),
        entry.sanitizedProviderLabel ?: text.get(R.string.library_export_review_unknown_provider),
        libraryExportCount(entry.recordOrder, locale))

internal fun unverifiedExportStatusResource(status: UnverifiedExportStatus): Int = when (status) {
    UnverifiedExportStatus.GRANT_UNAVAILABLE -> R.string.library_export_review_grant_unavailable
    UnverifiedExportStatus.COPIED_UNVERIFIED -> R.string.library_export_review_copied_unverified
    UnverifiedExportStatus.RECOVERY_REQUIRED -> R.string.library_export_review_recovery_required
}

internal fun exportShareWarning(locale: Locale, text: LibraryExportText): String = text.get(
    R.string.library_export_share_warning, libraryBytes(SharePolicy.MAX_COPY_BYTES, locale),
    libraryExportCount(SharePolicy.MAX_COPIES.toLong(), locale), libraryBytes(SharePolicy.MAX_TOTAL_BYTES, locale),
    libraryExportCount(TimeUnit.MILLISECONDS.toMinutes(SharePolicy.TTL_MILLIS), locale),
    libraryExportCount(SharePolicy.MAX_OPENS.toLong(), locale))
