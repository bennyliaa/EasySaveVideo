# Media-library English / Simplified-Chinese presentation

## Original requirement and scope

Original UI framework §7 (UI01 lines148–154) and coder requirements §7 (UI03 lines68–74) require resource-backed product text, typed UI messages, locale formatting and language switches without restarting work. This slice starts from the sealed 3034 current-search-report checkpoint. Only the already approved English and Simplified-Chinese product locales are added here.

The Library surface includes its core catalog/list/details/name/delete/move dialogs and embedded export/share status, review rows and destination-choice dialog. External media/folder/provider labels remain literal. Internal technical IDs and diagnostic enums keep their existing technical meaning.

## State and rendering

Core Library snapshots retain public typed notices: fixed kind, exact LibraryError, non-empty-folder counts, or the six batch-move status counts. Worker callbacks retain those facts instead of a rendered Chinese sentence. Name validation follows the same domain validation and returns a typed notice.

Export snapshots retain a closed ExportNotice outcome and immutable review facts. Each review row still carries operation ID, exact source MediaReadRef and cleanup capability. Source name, sanitized external provider label, record order and typed review status participate in whole-row equality. Current Composition renders localized fallback labels, never granting or restoring authority based on locale.

Unknown duration/resolution and missing-folder metadata remain unknown/reading. Unconfirmed mutation, copied-unverified output, reader release, cleanup and recovery states remain distinct from success. A share chooser is not proof of delivery, and revocation cannot recall copies already received.

All numeric display uses the current UI locale; plural/count-neutral copy covers singular and multiple items. File-size unit symbols and MP4 remain technical notation. Existing SkinKit controls are retained; affected action rows wrap for long English labels. Current Composition can re-render the same notice in either language without a repository operation, export, verification or other task restart.

## Preserved behavior and privacy

Repository calls, catalog/journal/schema, exact identity/revision checks, UI/read generations, picker intent/lifecycle gates, queue admission, cancellation, cleanup, grant checks and operation limits are unchanged. Existing delete confirmation and review-row cleanup confirmation still require their exact current targets. No extra network, persistence/history, provider, entitlement, permission, dependency or language owner is introduced.

AndroidExportPort destination-label lookup remains metadata-only: sanitized external provider label, then sanitized authority, then an explicit unknown fact rendered by the UI. No extra URI/path read, grant recovery or persisted field is added. Product errors never interpolate Throwable messages, paths, URLs or credentials. The existing review-row toString remains redacted.

## Verification

Focused and full JVM tests, compile, lint, dependency-byte admission and Release debug-loopback exclusion are performed by the serialized offline build owner. Resource contracts cover matching keys, numbered placeholders, plurals, unknowns, privacy, locale switching and direct-file Gradle inputs. Runtime tests preserve cancellation/cleanup/consent behavior. Final exact counts and source manifest are recorded outside source in VERIFIED_CHECKPOINT.json and evidence/VERIFICATION.json.

Actual device layout, TalkBack, large-font and runtime locale-switch acceptance remain NOT_RUN while device/Ubuntu work is paused. This slice creates no APK and does not change the installed code9 binary or original N12 acceptance count.
