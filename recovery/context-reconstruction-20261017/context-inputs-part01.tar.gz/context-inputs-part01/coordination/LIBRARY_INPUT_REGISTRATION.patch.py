#!/usr/bin/env python3
"""UNVERIFIED context-reconstructed transformation for the known3034 app/build.gradle.kts.
Do not run against the restored2801 baseline or any unknown checkout.
Requires review, trusted baseline comparison and full verification before application.
"""
from pathlib import Path
import sys
if len(sys.argv) != 2: raise SystemExit("Pass an independently recovered3034 app/build.gradle.kts only")
p=Path(sys.argv[1]);s=p.read_text()
needle='"library_batch_export.xml", "export_recovery.xml",'
assert s.count(needle)==1
s=s.replace(needle,'"library_batch_export.xml", "library_core.xml", "library_export_localization.xml", "export_recovery.xml",')
paths=[
 'src/main/kotlin/com/easysavevideo/app/library/LibraryNotice.kt',
 'src/main/kotlin/com/easysavevideo/app/library/LibraryNoticeResources.kt',
 'src/main/kotlin/com/easysavevideo/app/library/LibraryPresentation.kt',
 'src/main/kotlin/com/easysavevideo/app/library/LibraryMultiSelectionToolbar.kt',
 'src/main/kotlin/com/easysavevideo/app/library/LibraryExportDialog.kt',
 'src/main/kotlin/com/easysavevideo/app/library/export/AndroidExportPort.kt',
 'src/main/kotlin/com/easysavevideo/app/library/export/ExportPresentation.kt',
 'src/main/kotlin/com/easysavevideo/app/library/export/LibraryExportResources.kt']
needle='    "src/main/kotlin/com/easysavevideo/app/library/LibraryScreen.kt",'
assert s.count(needle)==1
new=[q for q in paths if '"'+q+'"' not in s]
s=s.replace(needle,needle+''.join('\n    "'+q+'",' for q in new))
p.write_text(s)
