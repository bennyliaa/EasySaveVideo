#!/usr/bin/env python3
"""Rebuild a source snapshot into a NEW directory, checking every byte before any compilation."""
import argparse, hashlib, json, shutil
from pathlib import Path, PurePosixPath

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def safe(root, name):
    p=PurePosixPath(name)
    if p.is_absolute() or any(x in ('', '.', '..') for x in p.parts) or '\\' in name:
        raise ValueError('Unsafe manifest path')
    result=root.joinpath(*p.parts)
    if any(root.joinpath(*p.parts[:i]).is_symlink() for i in range(1,len(p.parts)+1)):
        raise ValueError('Symlinks are not admitted')
    if not result.resolve().is_relative_to(root.resolve()): raise ValueError('Path escaped package')
    return result

def verify(root, records):
    for r in records:
        p=safe(root,r['path'])
        if not p.is_file() or p.stat().st_size!=r['bytes'] or digest(p)!=r['sha256']:
            raise ValueError('Source identity mismatch: '+r['path'])
        if 'executable' in r and bool(p.stat().st_mode&0o111)!=r['executable']:
            raise ValueError('Executable mode mismatch: '+r['path'])

def main():
    a=argparse.ArgumentParser();a.add_argument('--baseline',required=True,type=Path);a.add_argument('--package',required=True,type=Path);a.add_argument('--output',required=True,type=Path);n=a.parse_args()
    if n.output.exists(): raise ValueError('Output must be a new directory')
    base=json.loads((n.package/'BASELINE_SOURCE_MANIFEST.json').read_text())
    target=json.loads((n.package/'COMPLETE_SOURCE_MANIFEST.json').read_text())
    change=json.loads((n.package/'MANIFEST.json').read_text())
    if change['baseline_commit']!='6d2edfa5680d0163038fde1faa58f693513d0ab8': raise ValueError('Unexpected prerequisite')
    if len({r['path'] for r in base})!=len(base) or len({r['path'] for r in target})!=len(target): raise ValueError('Duplicate manifest paths')
    if digest(n.package/'BASELINE_SOURCE_MANIFEST.json')!=change['baseline_replay_manifest_sha256'] or digest(n.package/'COMPLETE_SOURCE_MANIFEST.json')!=change['target_manifest_sha256']: raise ValueError('Manifest identity mismatch')
    verify(n.baseline,base)
    for r in change['changes']:
        src=safe(n.package/'overlay',r['path'])
        if not src.is_file() or digest(src)!=r['sha256'] or src.stat().st_size!=r['bytes']:raise ValueError('Overlay mismatch')
        prior=safe(n.baseline,r['path'])
        if r['old_sha256'] is not None and (not prior.is_file() or digest(prior)!=r['old_sha256']):raise ValueError('Wrong patch prerequisite')
        if r['old_sha256'] is None and prior.exists():raise ValueError('Unexpected new-file collision')
    n.output.mkdir(parents=True)
    for r in base:
        dest=safe(n.output,r['path']);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(safe(n.baseline,r['path']),dest);dest.chmod(0o755 if r.get('executable',False) else 0o644)
    for r in change['changes']:
        dest=safe(n.output,r['path']);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(safe(n.package/'overlay',r['path']),dest);dest.chmod(0o755 if r['executable'] else 0o644)
    verify(n.output,target)
    names={p.relative_to(n.output).as_posix() for p in n.output.rglob('*') if p.is_file()}
    if names!={r['path'] for r in target}:raise ValueError('Unexpected target entries')
    print(json.dumps({'source_files':len(target),'target_manifest_sha256':digest(n.package/'COMPLETE_SOURCE_MANIFEST.json'),'byte_and_mode_verification':'PASS','build_executed':False}))
if __name__=='__main__': main()
