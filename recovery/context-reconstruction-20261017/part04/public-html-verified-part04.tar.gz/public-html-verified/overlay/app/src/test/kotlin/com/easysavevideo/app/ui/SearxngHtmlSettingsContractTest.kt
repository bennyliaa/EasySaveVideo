package com.easysavevideo.app.ui

import java.io.File
import javax.xml.parsers.DocumentBuilderFactory
import org.junit.Assert.*
import org.junit.Test

/** Source checks supplement JVM policy tests; they do not claim Compose/device acceptance. */
class SearxngHtmlSettingsContractTest {
    private fun ui() = File("src/main/kotlin/com/easysavevideo/app/ui/SearxngSourceSettings.kt").readText()
    private fun resources(locale: String): Map<String, String> {
        val factory = DocumentBuilderFactory.newInstance()
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
        val nodes = factory.newDocumentBuilder().parse(File("src/main/res/$locale/searxng_settings.xml"))
            .getElementsByTagName("string")
        return (0 until nodes.length).associate { index -> nodes.item(index).let {
            it.attributes.getNamedItem("name").nodeValue to it.textContent
        } }
    }
    @Test fun formatSelectionIsExplicitExclusiveAndFencedWithoutAnyNetworkOrEnableSideEffect() {
        val source = ui()
        assertTrue(source.contains("var format by remember(claim) { mutableStateOf(original.format) }"))
        assertTrue(source.contains("Column(Modifier.selectableGroup())"))
        assertTrue(source.contains("role = Role.RadioButton"))
        assertTrue(source.contains("if (isCurrent() && format != choice) { format = choice; acknowledged = false }"))
        assertTrue(source.contains("SearxngConfigurationPolicy.replace(config, original.id, url, enabled, acknowledged, format)"))
        assertTrue(source.contains("SearxngConfigurationPolicy.acknowledgementRequired(original, url, enabled, format)"))
        assertTrue(source.contains("controller.replace(claim, url, enabled, acknowledged, format)"))
        assertTrue(source.contains("if (slot.searchUrl != null) EsvText(stringResource(formatLabel(slot.format))"))
        for (forbidden in listOf("SearxngHtmlSearchProvider(", "SystemSearxngTransport(", "enabled = true",
            "safeSearch = false", "submitFilterDraft(", ".search(", "searchlinks")) assertFalse(forbidden, source.contains(forbidden))
    }
    @Test fun bothLanguagesDiscloseOperatorLoggingPendingWebCandidatesAndNoAutomaticFallback() {
        val en = resources("values"); val zh = resources("values-zh-rCN")
        assertEquals(en.keys, zh.keys); assertEquals(39, en.size)
        val formats = Regex("%(?:[0-9]+\\$)?[dsf]")
        en.keys.forEach { key ->
            assertTrue(key, en.getValue(key).isNotBlank()); assertTrue(key, zh.getValue(key).isNotBlank())
            assertEquals(key, formats.findAll(en.getValue(key)).map { it.value }.toList(),
                formats.findAll(zh.getValue(key)).map { it.value }.toList())
        }
        for (key in listOf("privacy", "editor_privacy", "acknowledge")) {
            assertTrue(en.getValue("searxng_settings_$key").contains("may log"))
            assertTrue(zh.getValue("searxng_settings_$key").contains("可能记录"))
        }
        assertTrue(en.getValue("searxng_settings_format_notice").contains("awaiting validation"))
        assertTrue(en.getValue("searxng_settings_format_notice").contains("never switch to HTML automatically"))
        assertTrue(zh.getValue("searxng_settings_format_notice").contains("不能证明存在视频"))
        assertTrue(zh.getValue("searxng_settings_format_notice").contains("不会自动切换到 HTML"))
        assertTrue(en.getValue("searxng_settings_safe_search").contains("rejected without sending a query"))
        assertTrue(zh.getValue("searxng_settings_safe_search").contains("不会改变已请求的安全搜索设置"))
        assertTrue(en.getValue("searxng_settings_malformed").contains("original file is preserved"))
        assertTrue(zh.getValue("searxng_settings_malformed").contains("原始文件已保留"))
    }
    @Test fun newResourcesAreUsedAndRegisteredAsGradleContractInputs() {
        val source = ui()
        resources("values").keys.forEach { key -> assertTrue(key, source.contains("R.string.$key")) }
        val build = File("build.gradle.kts").readText()
        assertTrue(build.contains("\"searxng_settings.xml\""))
        assertTrue(build.contains("\"src/main/kotlin/com/easysavevideo/app/ui/SearxngSourceSettings.kt\""))
    }
}
