package com.easysavevideo.app.storage

import java.io.ByteArrayOutputStream
import java.io.DataOutputStream

/** Independently written historical v1 bytes; intentionally does not call the current encoder. */
internal fun legacySearxngConfiguration(duplicateOrigin: Boolean = false): ByteArray {
    val bytes = ByteArrayOutputStream()
    DataOutputStream(bytes).use { output ->
        output.writeInt(0x45535358); output.writeInt(1); output.writeLong(7); output.writeInt(3)
        for (index in 0..2) {
            val id = "searxng-${index + 1}".toByteArray(Charsets.UTF_8)
            output.writeInt(id.size); output.write(id)
            output.writeBoolean(index == 0)
            output.writeBoolean(index != 2)
            if (index != 2) {
                val url = (if (duplicateOrigin && index == 1) "https://SEARCH0.EXAMPLE.ORG/search"
                    else "https://search$index.example.org/search").toByteArray(Charsets.UTF_8)
                output.writeInt(url.size); output.write(url)
            }
        }
    }
    return bytes.toByteArray()
}
