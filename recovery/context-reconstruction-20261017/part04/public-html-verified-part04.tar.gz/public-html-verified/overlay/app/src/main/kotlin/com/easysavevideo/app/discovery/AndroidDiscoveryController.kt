package com.easysavevideo.app.discovery

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.easysavevideo.app.storage.AndroidDiscoveryStore
import com.easysavevideo.core.model.*
import com.easysavevideo.discovery.*
import com.easysavevideo.app.discovery.thumbnail.AndroidDiscoveryThumbnails
import com.easysavevideo.app.discovery.thumbnail.DiscoveryThumbnailImageState
import com.easysavevideo.app.discovery.thumbnail.CommonsThumbnailPolicy
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.ScheduledThreadPoolExecutor
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.atomic.AtomicLong

/** UI never calls SQLite/coordinator locks. Only immutable snapshots cross onto the main thread. */
data class DiscoveryUiState(
    val ready: Boolean = false,
    val profile: SearchProfile = SearchProfile("local", ""),
    val status: DiscoveryStatus? = null,
    val page: PageSnapshot? = null,
    val restoredPageFromStamp: SessionStamp? = null,
    val results: List<VideoSearchResult> = emptyList(),
    val pageIndex: Int = 0,
    val materializedPages: Int = 0,
    val nextPagePending: Boolean = false,
    val demo: Boolean = false,
    val storageUnavailable: Boolean = false,
    val notice: DiscoveryNotice? = null,
    val commonsConfigured: Boolean = CommonsSourceRegistration.configured,
    val commonsEnabled: Boolean = false,
    val controlTarget: DiscoveryControlTarget? = null,
    val historyStatistics: DiscoveryHistoryStatistics? = null,
    val historyStatisticsUnavailable: Boolean = false,
    val saveActive: Boolean = false,
    val recordingActive: Boolean = false,
    val admittedProviderDescriptors: List<ProviderDescriptor> = emptyList(),
    val powerScenarioId: String? = null,
    val osPower: DiscoveryOsPowerSnapshot = DiscoveryOsPowerSnapshot(),
    val sourceRevision: Long = -1L,
    val configurationIntent: Long = 0L,
    val thumbnailGeneration: Long = -1L,
    val pendingCandidates: List<PendingVideoCandidate> = emptyList(),
    val needsExplicitSearch: Boolean = false,
    val verificationSummary: VerificationSummary? = null,
    val verificationGeneration: Long = -1L,
    val localSourceAdmission: SourceAdmissionStatus = SourceAdmissionStatus.UNCONFIGURED,
    val pendingAdmission: Map<String, SourceAdmissionStatus> = emptyMap(),
) { override fun toString() = "DiscoveryUiState([redacted])" }

class AndroidDiscoveryController(context: Context, private val errors: ErrorSink) : AutoCloseable {
    private val store = AndroidDiscoveryStore(context)
    private val appContext = context.applicationContext
    private val thumbnails = AndroidDiscoveryThumbnails()
    private val thumbnailMaintenanceSubscription = CommonsSourceRegistration.subscribeThumbnailWithdrawal(thumbnails::withdraw)
    private var commonsEnabled: Boolean? = null
    private val io = Executors.newSingleThreadScheduledExecutor { runnable -> Thread(runnable, "esv-discovery-ui").apply { isDaemon = true } }
    private val main = Handler(Looper.getMainLooper())
    // Independent handler: close() removes ordinary snapshot callbacks, never control receipts.
    private val localControlMain = Handler(Looper.getMainLooper())
    private val closed = AtomicBoolean(false)
    @Volatile private var coordinator: VideoDiscoveryCoordinator? = null
    private var timer: JvmDiscoveryTimer? = null
    private var runtime: IsolatedProviderRuntime? = null
    @Volatile private var foreground = false
    @Volatile private var visible = false
    @Volatile private var saveActive = false
    @Volatile private var recordingActive = false
    private var registry = ProviderRegistry()
    private val sourceIntent = java.util.concurrent.atomic.AtomicLong(0)
    @Volatile private var appliedSourceIntent = 0L
    @Volatile private var sourceConfiguration: SearxngSourceConfiguration? = null
    @Volatile private var sourceConfigurationLoaded = false
    private val sourceOwner = AndroidSearxngConfigurationOwner.get(appContext)
    val sourceSettings = sourceOwner.controller
    private var sourceSubscription: AutoCloseable? = null
    private val verificationOwner = VerificationConfigurationOwner.hub
    val verificationSettings = verificationOwner.controller
    @Volatile private var verificationConfiguration = verificationSettings.state
    private var verificationSubscription: AutoCloseable? = null
    private fun loadedVerificationConfiguration(value: VerificationConfiguration) {
        if (closed.get() || verificationConfiguration.generation == value.generation) return
        // Re-fence delivery too: an owner may have attached reentrantly during change notification.
        fenceSourceConfiguration()
        verificationConfiguration = value
        val intent = sourceIntent.get()
        submit { if (sourceIntent.get() == intent) initialize(demo, intent) }
    }
    private data class PowerInput(val selection: DiscoveryPowerSelection, val os: DiscoveryOsPowerSnapshot)
    private val powerLock = Any()
    private var simulatedPower: DiscoveryPowerSelection? = null
    private val desiredPower = AtomicReference(PowerInput(DiscoveryPowerSelection(null,
        DiscoveryPowerSignals(enabled = true)), DiscoveryOsPowerSnapshot()))
    private data class PendingPowerChange(val coordinator: VideoDiscoveryCoordinator?, val revision: Long?, val input: PowerInput)
    private val powerDelivery = DiscoveryLatestDelivery<PendingPowerChange>(
        enqueue = { action -> if (closed.get()) false else try { io.execute(action); true } catch (_: Exception) { false } },
        consume = { change -> if (!closed.get()) guarded { applyPowerChange(change) } })
    private val signalClock = ScheduledThreadPoolExecutor(1) { runnable ->
        Thread(runnable, "esv-discovery-expiry").apply { isDaemon = true }
    }.apply { removeOnCancelPolicy = true; setExecuteExistingDelayedTasksAfterShutdownPolicy(false) }
    private val osSignals = DiscoveryOsPowerBridge(AndroidDiscoveryOsSignalSource(appContext), SystemClock::elapsedRealtime,
        DiscoverySignalTimer { delay, action ->
            val task = signalClock.schedule(action, delay, TimeUnit.MILLISECONDS)
            DiscoverySignalCancellation { task.cancel(false) }
        }, ::receiveOsPower)
    private var appliedPowerScenario: String? = null
    private var appliedOsPower = DiscoveryOsPowerSnapshot()
    private var demo = false
    private var settings = DiscoverySettings()
    private val thumbnailSettingsInput = AtomicReference(DiscoverySettings())
    private val thumbnailRequestedIntent = AtomicLong(0)
    private val thumbnailAppliedIntent = AtomicLong(0)
    private var sortOrder = ResultSort.RELEVANCE
    private var pageIndex = 0
    private var notice: DiscoveryNotice? = null
    private var unavailable = false
    private var initialized = false
    @Volatile private var managementRevision = -1L
    private var savedViewport: Pair<SessionStamp, Int>? = null
    private var readingRestoreProof: DiscoveryReadingRestoreProof? = null
    private var polling: ScheduledFuture<*>? = null
    private var controllerGeneration = 0L
    // Polling can fulfill earlier explicit page demand, but local controls never create demand.
    private var pageDemandPending = false
    private val nextPageDemand = DiscoveryPageDemand()
    private val pageLifecycle = java.util.concurrent.atomic.AtomicLong(0)
    private var historyStatistics: DiscoveryHistoryStatistics? = null
    private var historyStatisticsUnavailable = false
    var state by mutableStateOf(DiscoveryUiState())
        private set
    var localControlState by mutableStateOf(DiscoveryLocalControlState())
        private set
    private val localControlOwner = DiscoveryLocalControlOwner { localControlState = it }
    // Main-thread UI draft only; persisted applied search remains the sole source-query authority.
    var filterDraft by mutableStateOf<DiscoveryFilterDraft?>(null)
        private set
    // Ephemeral navigation draft: never executes a search and is discarded on leaving/background.
    var pendingBrowserQuery by mutableStateOf<String?>(null)
        private set
    fun offerBrowserQuery(query: String): Boolean {
        if (closed.get() || !foreground || !visible || query.isBlank() ||
            !DiscoveryPresentationPolicy.validQuery(query) || query.any { it.code < 32 || it.code == 127 }) return false
        pendingBrowserQuery = query
        applyBrowserQuery(query)
        return true
    }
    fun applyBrowserQuery(expected: String): Boolean {
        if (closed.get() || !foreground || !visible || pendingBrowserQuery != expected ||
            !state.ready || state.storageUnavailable || filterControlsBusy) return false
        val current = filterDraft
        val draft = DiscoveryFilterPresentationPolicy.reconcile(current, state.profile, state.demo, true)
        if (!updateFilterDraft(current, draft.copy(query = expected))) return false
        pendingBrowserQuery = null
        return true
    }
    var filterSearchPending by mutableStateOf(false)
        private set
    private var filterSourceChangePending by mutableStateOf(false)
    @Volatile private var filterIntentGeneration = 0L
    val filterControlsBusy: Boolean get() = filterSearchPending || filterSourceChangePending || sourceSettings.state.busy ||
        state.sourceRevision != CommonsSourceRegistration.managementRevision ||
        state.configurationIntent != sourceIntent.get()
    /** Main-thread compare-and-set prevents callbacks captured before recomposition erasing newer edits. */
    fun updateFilterDraft(expected: DiscoveryFilterDraft?, value: DiscoveryFilterDraft): Boolean {
        if (closed.get() || filterControlsBusy || filterDraft != expected ||
            !DiscoveryFilterPresentationPolicy.matchesApplied(value, state.profile, state.demo)) return false
        filterDraft = value
        // An accepted edit/reset or this handoff supersedes any waiting browser draft.
        pendingBrowserQuery = null
        return true
    }
    fun editFilterText(claim: DiscoveryFilterClaim, field: DiscoveryFilterTextField, value: String): Boolean {
        if (closed.get()) return false
        val current = filterDraft
        val next = DiscoveryFilterPresentationPolicy.editText(claim, current, state.controlTarget,
            state.profile, state.demo, state.ready, state.storageUnavailable, filterControlsBusy, field, value) ?: return false
        return updateFilterDraft(current, next)
    }
    /** Explicit clear is stricter than continuous IME edits: a stale claim must never erase newer input. */
    internal val clearQueryLifecycle: Long get() = pageLifecycle.get()
    internal val cardNavigationLifecycle: Long get() = pageLifecycle.get()
    fun clearFilterQuery(claim: DiscoveryFilterClaim, expectedLifecycle: Long): Boolean {
        if (closed.get() || !foreground || !visible) return false
        val current = filterDraft
        val next = DiscoveryFilterPresentationPolicy.clearQuery(claim, current, state.controlTarget,
            state.profile, state.demo, state.ready, state.storageUnavailable, filterControlsBusy,
            expectedLifecycle, pageLifecycle.get(), foreground && visible) ?: return false
        return updateFilterDraft(current, next)
    }
    fun confirmFilterSafety(claim: DiscoveryFilterClaim): Boolean {
        if (closed.get() || !DiscoveryFilterPresentationPolicy.validClaim(claim, filterDraft, state.controlTarget,
                state.profile, state.demo, state.ready, state.storageUnavailable, filterControlsBusy)) return false
        return updateFilterDraft(claim.draft, claim.draft.copy(safeSearch = false))
    }
    /** Claim once on the main thread, then revalidate the complete target on the serialized executor. */
    fun submitFilterDraft(expected: DiscoveryFilterDraft, target: DiscoveryControlTarget?): Boolean {
        if (target == null || closed.get()) return false
        val claim = DiscoveryFilterClaim(target, expected.demo, expected)
        if (!DiscoveryFilterPresentationPolicy.validClaim(claim, filterDraft, state.controlTarget,
                state.profile, state.demo, state.ready, state.storageUnavailable, filterControlsBusy) ||
            !DiscoveryFilterPresentationPolicy.canSubmit(expected)) return false
        val filters = DiscoveryFilterPresentationPolicy.validate(expected).filters ?: return false
        val intentGeneration = filterIntentGeneration
        pendingBrowserQuery = null
        filterSearchPending = true
        thumbnails.withdraw()
        coordinator?.invalidateVerificationSummary()
        state = state.copy(verificationSummary = null)
        submit {
            var applied: SearchProfile? = null
            try {
                val c = coordinator ?: return@submit
                if (!initialized || unavailable || intentGeneration != filterIntentGeneration ||
                    managementRevision != CommonsSourceRegistration.managementRevision || target != currentControlTarget(c) || demo != expected.demo) return@submit
                pageIndex = 0; pageDemandPending = true; notice = null
                c.start(SESSION, profile(DiscoveryPresentationPolicy.boundedQuery(expected.query.trim()), filters),
                    allowSessionCandidateVerification = !demo)
                applyLifecycle(c)
                applied = c.currentCheckpoint()?.profile
                refresh()
            } finally {
                // Snapshot publication is queued first. Failed/stale commands never submit a replacement.
                val completed = applied
                main.post {
                    if (!closed.get()) {
                        if (completed != null && filterDraft == expected)
                            filterDraft = DiscoveryFilterPresentationPolicy.fromProfile(completed, expected.demo)
                        filterSearchPending = false
                    }
                }
            }
        }
        return true
    }

    private fun configurationCurrent(claim: DiscoverySourceInitializationClaim,
        verification: VerificationConfiguration = verificationConfiguration): Boolean {
        val shared = sourceSettings.state
        return !verificationSettings.busy && verification.generation == verificationSettings.current.generation &&
            DiscoverySourceUiFence.canInitialize(claim, sourceIntent.get(), shared.config?.generation, shared.busy)
    }
    private fun initialize(enableDemo: Boolean, expectedIntent: Long = sourceIntent.get(),
        expectedConfiguration: SearxngSourceConfiguration? = sourceConfiguration) {
        readingRestoreProof = null
        if (!sourceConfigurationLoaded) { main.post { sourceSettings.reload() }; return }
        val claim = DiscoverySourceInitializationClaim(expectedIntent, expectedConfiguration?.generation)
        val verification = verificationConfiguration
        if (!configurationCurrent(claim, verification)) { pageDemandPending = false; return }
        val recoveringUnavailable = unavailable || appliedSourceIntent != expectedIntent
        controllerGeneration++
        nextPageDemand.cancel()
        pageDemandPending = true; historyStatistics = null; historyStatisticsUnavailable = false
        coordinator?.close(); runtime?.close(); timer?.close()
        CommonsSourceRegistration.initialize(appContext)
        managementRevision = CommonsSourceRegistration.managementRevision
        demo = enableDemo && BuildDiscovery.supportsDemo
        if (commonsEnabled == null) commonsEnabled = appContext.getSharedPreferences("discovery_sources", Context.MODE_PRIVATE)
            .getBoolean("commons_enabled", true)
        savedViewport = null
        timer = JvmDiscoveryTimer()
        val limits = DiscoveryLimits(pageSize = settings.pageSize)
        registry = BuildDiscovery.registry(demo, commonsEnabled == true, expectedConfiguration)
        val sessionAdmission = if (demo) null else SessionCandidateAdmission(registry)
        val validator = if (demo) null else VerificationEngineRegistration.validator(verification, timer!!,
            localEngines=listOf(VerificationEngineRegistration.localEngine(appContext)), sessionAdmission = sessionAdmission) { generation ->
            !closed.get() && !verificationSettings.busy && sourceIntent.get() == expectedIntent &&
                verificationSettings.current.generation == generation && verificationConfiguration.generation == generation
        }
        runtime = IsolatedProviderRuntime(ValidationPipeline(validator, limits = limits,
            retainUnvalidatedCandidates = true, retainFailedValidationCandidates = true,
            maxValidationsPerPage = if (expectedConfiguration?.enabledEndpoints?.any {
                it.format == com.easysavevideo.searxng.SearxngResultFormat.HTML_WEB } == true) 8 else 1,
            sessionAdmission = sessionAdmission), timer!!)
        coordinator = VideoDiscoveryCoordinator(registry, runtime!!, if (demo) InMemoryDiscoveryStore() else store, timer!!, limits = limits, sessionAdmission = sessionAdmission,
            sourceConfigurationKey = if (demo) null else VerificationConfigurationPolicy.configurationKey(
                SearxngSourceRegistration.configurationKey(expectedConfiguration,
                    commonsEnabled == true, registry.all().map { it.descriptor }), verification))
        unavailable = false; pageIndex = 0; initialized = false
        val c = coordinator!!
        // Publish the reference first: a concurrent write now fences this coordinator directly.
        // A write that fenced the previous/null reference is caught by this recheck.
        if (!configurationCurrent(claim, verification)) { c.suspendSourcesImmediately(); return }
        appliedSourceIntent = expectedIntent
        val power = desiredPower.get()
        c.setPowerSignals(power.selection.signals, 0L)
        appliedPowerScenario = power.selection.scenarioId
        appliedOsPower = power.os
        if (!demo) {
            val previous = store.transaction { checkpoint(SESSION) }
            if (previous != null) {
                if (!c.restore(SESSION, requireExplicitSearch = recoveringUnavailable)) {
                    unavailable = true
                    if (configurationCurrent(claim, verification)) {
                        publish(DiscoverySourceUiFence.failure(expectedIntent, demo))
                        main.post { if (!closed.get() && sourceIntent.get() == expectedIntent) filterSourceChangePending = false }
                    }
                    return
                }
                readingRestoreProof = DiscoveryReadingAnchorPolicy.restoreProof(previous, c.currentCheckpoint())
                sortOrder = previous.profile.sortOrder
                pageIndex = store.loadViewport(previous.stamp).coerceAtMost(previous.pool.pages.lastIndex.coerceAtLeast(0))
            } else c.start(SESSION, profile("", SearchFilters()))
        } else c.start(SESSION, profile("演示数据", SearchFilters()))
        if (!configurationCurrent(claim, verification)) { c.suspendSourcesImmediately(); return }
        initialized = true
        c.setMode(settings.mode); applyLifecycle(c); refresh()
        main.post { if (!closed.get() && appliedSourceIntent == sourceIntent.get()) filterSourceChangePending = false }
    }
    /** The write intent fences old callbacks before storage or registry work is queued. */
    private fun fenceSourceConfiguration() {
        if (closed.get()) return
        sourceIntent.incrementAndGet(); filterIntentGeneration++; filterSourceChangePending = true
        thumbnails.withdraw()
        coordinator?.suspendSourcesImmediately()
        state = state.copy(page = null, results = emptyList(), pendingCandidates = emptyList(), pendingAdmission = emptyMap(), verificationSummary = null,
            controlTarget = null, historyStatistics = null,
            notice = DiscoveryNotice.SOURCE_CONFIGURATION_CHECKING)
    }
    private fun loadedSourceConfiguration(value: SearxngConfigurationState) {
        if (closed.get() || value.busy || !value.loaded) return
        val shared = sourceSettings.state
        if (shared.busy || value.config?.generation?.let { it != shared.config?.generation } == true) return
        if (sourceConfigurationLoaded && sourceConfiguration?.generation != value.config?.generation)
            fenceSourceConfiguration()
        applySourceConfiguration(value.config, force = !sourceConfigurationLoaded)
    }
    private fun applySourceConfiguration(value: SearxngSourceConfiguration?, force: Boolean = false) {
        // Bind this queued state to its callback's intent, never a later intent read on the worker.
        val claim = DiscoverySourceInitializationClaim(sourceIntent.get(), value?.generation)
        if (!force && initialized && !unavailable && sourceConfigurationLoaded && sourceConfiguration?.generation == value?.generation &&
            appliedSourceIntent == sourceIntent.get()) return
        submit {
            if (!configurationCurrent(claim)) return@submit
            if (!force && initialized && !unavailable && sourceConfigurationLoaded && sourceConfiguration?.generation == value?.generation &&
                appliedSourceIntent == sourceIntent.get()) return@submit
            sourceConfiguration = value; sourceConfigurationLoaded = true
            pageDemandPending = false
            initialize(demo, claim.intent, value)
        }
    }
    /** Pending cards may open the current original page, without video/Seen/Save identity authority. */
    fun candidateUrl(target: DiscoveryControlTarget?, candidate: PendingVideoCandidate): String? =
        if (!closed.get() && !filterControlsBusy && !state.storageUnavailable && target != null &&
            target == state.controlTarget && state.pendingCandidates.any { it == candidate }) candidate.canonicalPageUrl else null

    fun verifyCandidate(target: DiscoveryControlTarget?, candidate: PendingVideoCandidate) {
        if (candidateUrl(target, candidate) == null || candidate.verificationActive || candidate.verification != null ||
            !foreground || !visible) return
        submit {
            val c = coordinator ?: return@submit
            val checkpoint = c.currentCheckpoint() ?: return@submit
            if (target != state.controlTarget || candidateUrl(target, candidate) == null) return@submit
            if (!c.verifyPending(checkpoint.stamp, candidate.candidateId))
                notice = DiscoveryNotice.VERIFICATION_NOT_STARTED
            refresh()
        }
    }
    /** Capture the revision before flags: a newer owner/lifecycle event can only add a veto. */
    private fun applyLifecycle(c: VideoDiscoveryCoordinator) {
        val generation = c.currentSuspensionGeneration()
        val saving = saveActive; val recording = recordingActive
        val active = foreground; val shown = visible
        c.setPriority(saving, recording)
        c.setVisibility(active, shown, generation)
    }
    fun setVisibility(isForeground: Boolean, discoveryVisible: Boolean) {
        if (!isForeground || !discoveryVisible) {
            thumbnails.withdraw()
            pendingBrowserQuery = null
            pageLifecycle.incrementAndGet() // Retire intent now, before any queued refresh can resume.
            state = state.copy(verificationSummary = null, nextPagePending = false)
        }
        foreground = isForeground; visible = discoveryVisible
        if (!isForeground || !discoveryVisible) coordinator?.suspendImmediately()
        osSignals.setActive(isForeground && discoveryVisible)
        submit {
            coordinator?.let(::applyLifecycle)
            if (!isForeground || !discoveryVisible) nextPageDemand.cancel()
            if (foreground && visible && polling == null) polling = io.scheduleWithFixedDelay({
                if (!closed.get() && foreground && visible) guarded { refresh() }
            }, 300, 300, TimeUnit.MILLISECONDS)
            else if (!foreground || !visible) { polling?.cancel(false); polling = null }
            refresh()
        }
    }
    /** Save/Record adapters call this before starting work; no discovery action starts those tasks. */
    fun setTaskPriority(saveActive: Boolean, recordingActive: Boolean) {
        if (this.saveActive == saveActive && this.recordingActive == recordingActive) return
        this.saveActive = saveActive; this.recordingActive = recordingActive
        if (saveActive || recordingActive) { thumbnails.withdraw(); coordinator?.suspendImmediately() }
        submit { coordinator?.let(::applyLifecycle); refresh() }
    }
    /** Explicit debug scenarios only. Release has an empty allowlist and always refuses this call. */
    fun selectPowerScenario(id: String) {
        val selection = BuildDiscoveryPower.selection(id) ?: return
        synchronized(powerLock) {
            if (closed.get()) return
            // The historical disconnected factory disables simulation, never the release OS fence.
            simulatedPower = selection.takeIf { it.scenarioId != null }
            offerPowerLocked(desiredPower.get().os)
        }
    }
    fun refreshSystemSignals() { if (!closed.get()) osSignals.refresh() }
    private fun receiveOsPower(snapshot: DiscoveryOsPowerSnapshot) = synchronized(powerLock) {
        if (!closed.get()) offerPowerLocked(snapshot)
    }
    private fun offerPowerLocked(snapshot: DiscoveryOsPowerSnapshot) {
        val input = PowerInput(simulatedPower ?: DiscoveryPowerSelection(null, snapshot.signals), snapshot)
        if (desiredPower.getAndSet(input) == input) return
        thumbnails.withdraw()
        val c = coordinator
        val revision = c?.suspendPowerImmediately()
        // Every changed observation fences immediately, before the bounded executor delivery.
        powerDelivery.offer(PendingPowerChange(c, revision, input))
    }
    private fun applyPowerChange(change: PendingPowerChange) {
        val c = coordinator
        if (c != null && change.coordinator === c) {
            pageDemandPending = false
            c.setPowerSignals(change.input.selection.signals, requireNotNull(change.revision))
            // No page materialization, setVisibility, new round, or requestMore on relaxation.
            appliedPowerScenario = change.input.selection.scenarioId
            appliedOsPower = change.input.os
            refresh(readOnly = true)
        }
    }

    fun updateSettings(value: DiscoverySettings) {
        if (closed.get()) return
        val thumbnailIntent = if (CommonsThumbnailPolicy.settingsInputChanged(thumbnailSettingsInput, value))
            beginThumbnailIntent() else null
        submit {
            try {
                val old = settings; settings = value
                if (coordinator == null) { initialize(false); return@submit }
                coordinator?.setMode(value.mode)
                if (initialized && (old.repeatPolicy != value.repeatPolicy || old.pageSize != value.pageSize)) {
                    if (coordinator?.reviseView(value.repeatPolicy, value.pageSize, pageIndex) == true) {
                        pageIndex = 0; pageDemandPending = true; notice = DiscoveryNotice.VIEW_SETTINGS_CHANGED
                    } else notice = null
                }
                refresh()
            } finally { thumbnailIntent?.let(thumbnailAppliedIntent::set) }
        }
    }
    fun search(query: String, filters: SearchFilters) {
        val bounded = DiscoveryPresentationPolicy.boundedQuery(query.trim())
        if (!DiscoveryPresentationPolicy.validQuery(bounded)) {
            submit { notice = DiscoveryNotice.INVALID_QUERY; refresh(readOnly = true) }
            return // Invalid local text cannot cancel or suspend the current valid search.
        }
        val thumbnailIntent = beginThumbnailIntent()
        coordinator?.suspendImmediately()
        state = state.copy(verificationSummary = null)
        submit {
            try {
                if (!initialized || unavailable) return@submit
                pageIndex = 0; pageDemandPending = true; notice = null
                coordinator?.start(SESSION, profile(bounded, filters), allowSessionCandidateVerification = !demo)
                coordinator?.let(::applyLifecycle); refresh()
            } finally { thumbnailAppliedIntent.set(thumbnailIntent) }
        }
    }
    fun updateSort(value: ResultSort) {
        if (closed.get() || !state.ready || state.storageUnavailable) return
        val thumbnailIntent = beginThumbnailIntent()
        submit {
            try {
                if (!initialized || unavailable) return@submit
                if (coordinator?.reviseView(settings.repeatPolicy, settings.pageSize, pageIndex, value) == true) {
                    sortOrder = value; pageIndex = 0; pageDemandPending = true
                    notice = DiscoveryNotice.SORT_CHANGED
                } else notice = null
                refresh()
            } finally { thumbnailAppliedIntent.set(thumbnailIntent) }
        }
    }
    fun movePage(delta: Int, target: DiscoveryControlTarget? = state.controlTarget, from: Int = state.pageIndex,
        lifecycle: Long = pageLifecycle.get()) {
        if (closed.get() || target == null || target != state.controlTarget || from != state.pageIndex ||
            lifecycle != pageLifecycle.get() || !foreground || !visible || delta !in setOf(-1, 1)) return
        val thumbnailIntent = beginThumbnailIntent()
        submit {
            try {
                val c = coordinator ?: return@submit
                if (target != currentControlTarget(c) || from != pageIndex || lifecycle != pageLifecycle.get() ||
                    !foreground || !visible || managementRevision != CommonsSourceRegistration.managementRevision ||
                    delta !in setOf(-1, 1)) return@submit
                val checkpoint = c.currentCheckpoint() ?: return@submit
                if (delta == -1) {
                    nextPageDemand.cancel()
                    if (from > 0 && checkpoint.pool.pages.any { it.pageIndex == from - 1 }) pageIndex = from - 1
                } else {
                    if (!DiscoveryPagerPolicy.canAdvance(from, checkpoint.pool.pages.size, c.status()) ||
                        !nextPageDemand.begin(target, from, lifecycle)) return@submit
                    if (lifecycle != pageLifecycle.get() || !foreground || !visible) {
                        nextPageDemand.cancel(); return@submit
                    }
                    val page = c.page(from + 1)
                    if (page != null) {
                        if (lifecycle == pageLifecycle.get() && foreground && visible) pageIndex = from + 1
                        nextPageDemand.cancel()
                    }
                    else c.requestMore()
                }
                notice = null
                refresh()
            } finally { thumbnailAppliedIntent.set(thumbnailIntent) }
        }
    }
    fun cancelNextPage(target: DiscoveryControlTarget? = state.controlTarget) = submit {
        val c = coordinator ?: return@submit
        if (target == null || target != currentControlTarget(c)) return@submit
        nextPageDemand.cancel()
        refresh(readOnly = true)
    }
    fun retry() = submit {
        if (unavailable) { notice = DiscoveryNotice.STORAGE_RETRY_UNAVAILABLE; refresh() }
        else if (nextPageDemand.targetPage(coordinator?.let(::currentControlTarget), pageIndex, pageLifecycle.get()) == null) {
            pageDemandPending = true; coordinator?.requestMore(); notice = null; refresh()
        }
    }
    /** Reads only local counts; never initializes a source, materializes a page, or creates demand. */
    fun refreshHistoryStatistics(target: DiscoveryControlTarget?) = submit {
        val c = coordinator ?: return@submit
        if (target == null || target != currentControlTarget(c)) return@submit
        updateHistoryStatistics(c)
        refresh(readOnly = true)
    }

    /** One controller-wide claim; the exact dialog target is rechecked on the existing IO lane. */
    fun confirmLocalControl(request: DiscoveryControlRequest): Boolean {
        check(Looper.myLooper() == Looper.getMainLooper())
        return localControlOwner.submit(request,
            dispatch = { action -> io.execute(action); true },
            work = { captured ->
                if (closed.get()) DiscoveryControlOutcome.STALE else {
                    var outcome = DiscoveryControlOutcome.FAILED
                    guarded {
                        val c = coordinator
                        if (closed.get() || c == null) { outcome = DiscoveryControlOutcome.STALE; return@guarded }
                        osSignals.revalidate()
                        val target = if (!closed.get() && managementRevision == CommonsSourceRegistration.managementRevision) currentControlTarget(c) else null
                        outcome = DiscoveryPresentationPolicy.executeControl(captured, target,
                            c.status().providers.map { it.providerId }.toSet(), c::clearHistory) { profileId, providerId ->
                            c.resetProgress(profileId, providerId)
                        }
                    }
                    outcome
                }
            },
            deliver = { completion ->
                if (Looper.myLooper() == Looper.getMainLooper()) completion()
                else localControlMain.post(completion)
            },
            afterWork = { result ->
                if (!closed.get()) {
                    notice = DiscoveryPresentationPolicy.controlOutcomeNotice(result.operation.request.action, result.outcome)
                    guarded {
                        if (result.outcome != DiscoveryControlOutcome.STALE) {
                            // A later status tick must not turn a local control into new demand.
                            pageDemandPending = false
                            nextPageDemand.cancel()
                            coordinator?.let(::updateHistoryStatistics)
                        }
                        refresh(readOnly = true)
                    }
                }
            })
    }

    fun dismissLocalControlResult(expectedReceipt: DiscoveryLocalControlResult) {
        check(Looper.myLooper() == Looper.getMainLooper())
        localControlOwner.dismiss(expectedReceipt)
    }

    private fun currentControlTarget(c: VideoDiscoveryCoordinator): DiscoveryControlTarget? =
        if (!initialized || unavailable || appliedSourceIntent != sourceIntent.get()) null else DiscoveryPresentationPolicy.controlTarget(c.currentCheckpoint(), controllerGeneration)

    private fun updateHistoryStatistics(c: VideoDiscoveryCoordinator) {
        historyStatistics = null
        val target = currentControlTarget(c) ?: return
        val current: HistoryStatistics? = c.historyStatistics(target.profileId)
        val all: HistoryStatistics? = c.historyStatistics()
        historyStatisticsUnavailable = current == null || all == null
        if (current != null && all != null) historyStatistics = DiscoveryHistoryStatistics(target, current, all)
    }
    private fun changeSources(action: () -> Unit) {
        if (closed.get()) return
        fenceSourceConfiguration()
        val generation = filterIntentGeneration
        submit {
            try { action() } finally {
                main.post { if (!closed.get() && generation == filterIntentGeneration) filterSourceChangePending = false }
            }
        }
    }
    fun enableDemo(enable: Boolean) {
        if (!BuildDiscovery.supportsDemo) return
        changeSources { initialize(enable) }
    }
    fun enableCommons(enable: Boolean) = changeSources {
        check(appContext.getSharedPreferences("discovery_sources", Context.MODE_PRIVATE).edit()
            .putBoolean("commons_enabled", enable).commit())
        commonsEnabled = enable; initialize(demo)
    }
    fun recordSeen(page: PageSnapshot, result: VideoSearchResult, event: SeenEvent) = submit {
        if (appliedSourceIntent != sourceIntent.get()) return@submit
        val c = coordinator ?: return@submit
        val current = c.currentCheckpoint() ?: return@submit
        if (current.stamp == page.stamp && current.pool.viewRevision == page.revision &&
            current.pool.pages.any { it == page && result.resultId in it.orderedResultIds } &&
            (event != SeenEvent.SHOWN || (foreground && visible))) c.recordSeen(page, result.fingerprint, event)
    }
    /** Main-thread immutable UI snapshot capture; executor revalidates this target before writing. */
    fun captureOriginTarget(page: PageSnapshot, result: VideoSearchResult): DiscoveryControlTarget? =
        state.controlTarget?.takeIf { !closed.get() && state.ready && !state.storageUnavailable &&
            state.page == page && state.results.any { it == result } &&
            it.stamp == page.stamp && it.viewRevision == page.revision }

    /** History is deliberately outside the Save transaction and can never change its media outcome. */
    fun completeOriginSave(tracker: DiscoveryOriginTracker, proof: DiscoveryOriginSaveProof, taskId: String,
        media: DiscoveryOriginMediaOutcome, callback: (DiscoveryOriginSaveOutcome) -> Unit) {
        fun complete() {
            val outcome = try {
            val c = coordinator
            val target = if (!closed.get() && !unavailable && c != null &&
                managementRevision == CommonsSourceRegistration.managementRevision) currentControlTarget(c) else null
            // The current DOM candidate detector proves a selected page, not that candidate media
            // equals the provider's video identity. It must never mark that identity as SAVED.
            tracker.completeSave(proof, taskId, media, target,
                identityMatch = DiscoveryOriginMediaIdentityMatch.UNKNOWN) { event ->
                when {
                    closed.get() || c == null || !event.isCurrent() || target != event.target ->
                        DiscoveryOriginHistoryOutcome.STALE_OR_UNAVAILABLE
                    c.currentCheckpoint()?.pool?.pages?.none { it == event.page && event.result.resultId in it.orderedResultIds } != false ||
                        c.results(event.page).none { it == event.result } -> DiscoveryOriginHistoryOutcome.STALE_OR_UNAVAILABLE
                    c.recordSeen(event.page, event.result.fingerprint, SeenEvent.SAVED,
                        stillCurrent = { !closed.get() && event.isCurrent() }) -> DiscoveryOriginHistoryOutcome.RECORDED
                    c.status().lastError in setOf(DiscoveryError.STORAGE_UNAVAILABLE, DiscoveryError.CAPACITY_REACHED) ->
                        DiscoveryOriginHistoryOutcome.HISTORY_FAILED
                    else -> DiscoveryOriginHistoryOutcome.STALE_OR_UNAVAILABLE
                }
            }
            } catch (_: Exception) {
                tracker.abandon(proof)
                DiscoveryOriginSaveOutcome(media, DiscoveryOriginHistoryOutcome.HISTORY_FAILED)
            }
            callback(outcome)
        }
        // A closed/rejected controller still resolves the independent history result. It never
        // silently drops a callback or retries the underlying media operation.
        if (closed.get()) { complete(); return }
        try { io.execute { complete() } } catch (_: java.util.concurrent.RejectedExecutionException) { complete() }
    }
    private fun refresh(readOnly: Boolean = false) {
        // Capture before reading page/store state. Never label old work with a later withdrawal epoch.
        val thumbnailSnapshotGeneration = CommonsThumbnailPolicy.publicationGeneration(
            thumbnails.currentGeneration(), thumbnailRequestedIntent.get(), thumbnailAppliedIntent.get())
        if (!readOnly && coordinator != null && managementRevision != CommonsSourceRegistration.managementRevision) {
            initialize(demo); return
        }
        val c = coordinator ?: return
        val lifecycle = pageLifecycle.get()
        nextPageDemand.fulfill(currentControlTarget(c), pageIndex, c.status(),
            !readOnly && initialized && !unavailable && foreground && visible, lifecycle,
            stillCurrent = { lifecycle == pageLifecycle.get() && foreground && visible }) { c.page(it) != null }
            ?.let { if (lifecycle == pageLifecycle.get() && foreground && visible) pageIndex = it }
        val checkpoint = c.currentCheckpoint()
        var page = checkpoint?.pool?.pages?.firstOrNull { it.pageIndex == pageIndex }
        if (DiscoveryPresentationPolicy.mayFulfillPageDemand(readOnly, pageDemandPending, page == null, initialized,
                unavailable, foreground, visible) && c.status().availableCount > 0) page = c.page(pageIndex)
        if (!readOnly && page != null) pageDemandPending = false
        val updated = c.currentCheckpoint()
        val status = c.status()
        if (status.lastError == DiscoveryError.STORAGE_UNAVAILABLE) unavailable = true
        if (!readOnly && !demo && page != null && !unavailable && savedViewport != (page.stamp to pageIndex)) {
            store.saveViewport(page.stamp, pageIndex); savedViewport = page.stamp to pageIndex
        }
        val target = currentControlTarget(c)
        publish(DiscoveryUiState(ready = true, profile = updated?.profile ?: SearchProfile("local", ""), status = status, page = page,
            results = page?.let(c::results).orEmpty(), pageIndex = pageIndex, materializedPages = updated?.pool?.pages?.size ?: 0,
            restoredPageFromStamp = if (unavailable) null else DiscoveryReadingAnchorPolicy.restoredFromStamp(readingRestoreProof, updated, page),
            nextPagePending = nextPageDemand.targetPage(target, pageIndex, pageLifecycle.get()) != null,
            demo = demo, storageUnavailable = unavailable, notice = notice, commonsConfigured = CommonsSourceRegistration.configured,
            commonsEnabled = commonsEnabled == true, controlTarget = target,
            historyStatistics = historyStatistics?.takeIf { it.target == target },
            historyStatisticsUnavailable = historyStatisticsUnavailable, saveActive = saveActive, recordingActive = recordingActive,
            admittedProviderDescriptors = registry.all().map { it.descriptor }, powerScenarioId = appliedPowerScenario,
            osPower = appliedOsPower,
            sourceRevision = managementRevision, configurationIntent = appliedSourceIntent,
            thumbnailGeneration = thumbnailSnapshotGeneration,
            pendingCandidates = c.pendingCandidates(), pendingAdmission = c.pendingCandidates().associate { it.candidateId to verificationConfiguration.localSources.status(CandidateUrl(it.canonicalPageUrl)) },
            localSourceAdmission = verificationConfiguration.localSources.status, verificationGeneration = c.verificationGeneration(), verificationSummary = c.verificationSummary(), needsExplicitSearch = updated?.queryAuthorized == false))
    }
    /** Main-thread viewport only; no raw URL or generic image reader enters the UI contract. */
    internal fun updateThumbnailViewport(page: PageSnapshot, results: List<VideoSearchResult>, visibleIds: List<String>) {
        check(Looper.myLooper() == Looper.getMainLooper())
        val value = state
        val source = sourceIntent.get()
        val lifecycle = pageLifecycle.get()
        val allowed = thumbnailIntentApplied() && thumbnailNetworkAllowed() && value.ready && !value.storageUnavailable && !value.demo &&
            !value.needsExplicitSearch && !filterControlsBusy && value.page == page && value.results == results &&
            value.commonsConfigured && value.commonsEnabled && value.configurationIntent == source &&
            value.sourceRevision == CommonsSourceRegistration.managementRevision &&
            value.thumbnailGeneration == thumbnails.currentGeneration() && value.status?.state != DiscoveryState.SUSPENDED &&
            value.admittedProviderDescriptors.any { it.id == com.easysavevideo.commons.CommonsIdentity.PROVIDER_ID }
        thumbnails.update(page, results, visibleIds, allowed, value.thumbnailGeneration) { binding, result, epoch ->
            CommonsSourceRegistration.thumbnailCapability(appContext, binding, result, value.sourceRevision) {
                thumbnails.isCurrent(epoch) && thumbnailIntentApplied() && thumbnailNetworkAllowed() && sourceIntent.get() == source &&
                    pageLifecycle.get() == lifecycle && !closed.get()
            }
        }
    }
    private fun beginThumbnailIntent(): Long {
        val intent = thumbnailRequestedIntent.incrementAndGet()
        thumbnails.withdraw()
        return intent
    }
    private fun thumbnailIntentApplied(): Boolean = thumbnailRequestedIntent.get() == thumbnailAppliedIntent.get()
    private fun thumbnailNetworkAllowed(): Boolean = !closed.get() && foreground && visible && !saveActive && !recordingActive &&
        DiscoveryPowerPolicy.evaluate(desiredPower.get().selection.signals, DiscoveryMode.BALANCED).allowsRequests
    internal fun thumbnailImage(page: PageSnapshot?, result: VideoSearchResult): DiscoveryThumbnailImageState = thumbnails.state(page, result)
    internal val thumbnailRequestGeneration: Long get() = thumbnails.requestGeneration
    internal fun clearThumbnailViewport() { thumbnails.hideViewport() }

    private fun profile(query: String, filters: SearchFilters): SearchProfile = DiscoveryPresentationPolicy.profile(
        query, Locale.getDefault().toLanguageTag(), filters, settings.repeatPolicy, demo).copy(sortOrder = sortOrder)
    private val uiDelivery = DiscoveryLatestDelivery<DiscoveryUiState>(
        enqueue = { action -> main.post(action) }, consume = { value ->
            if (!closed.get() && DiscoverySourceUiFence.accepts(value.configurationIntent, sourceIntent.get()))
                state = if (coordinator?.verificationGeneration() == value.verificationGeneration) value
                    else value.copy(verificationSummary = null) })
    init {
        // Subscribe after every field is initialized. Pending writes fence replacement owners before any restore.
        verificationSubscription = verificationOwner.subscribe(::fenceSourceConfiguration, ::loadedVerificationConfiguration)
        sourceSubscription = sourceOwner.subscribe(::fenceSourceConfiguration, ::loadedSourceConfiguration)
    }
    private fun publish(value: DiscoveryUiState) { if (!closed.get()) uiDelivery.offer(value) }
    private fun submit(action: () -> Unit) { if (!closed.get()) runCatching { io.execute { if (!closed.get()) { osSignals.revalidate(); guarded(action) } } } }
    private fun guarded(action: () -> Unit) {
        try { action() } catch (_: Exception) {
            readingRestoreProof = null
            unavailable = true; coordinator?.suspendSourcesImmediately()
            errors.report(ErrorEnvelope(ErrorCode.RECOVERY_FAILED, ErrorModule.RECOVERY, true, UserAction.RETRY))
            val failedIntent = sourceIntent.get()
            publish(DiscoverySourceUiFence.failure(failedIntent, demo))
            main.post { if (!closed.get() && sourceIntent.get() == failedIntent) filterSourceChangePending = false }
        }
    }
    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        localControlOwner.close()
        thumbnailMaintenanceSubscription.close(); thumbnails.close()
        pendingBrowserQuery = null
        verificationSubscription?.close(); verificationSubscription = null
        sourceSubscription?.close(); sourceSubscription = null
        osSignals.close(); signalClock.shutdownNow()
        powerDelivery.close(); uiDelivery.close()
        coordinator?.suspendImmediately(); main.removeCallbacksAndMessages(null)
        io.execute { polling?.cancel(false); coordinator?.close(); runtime?.close(); timer?.close(); store.close() }; io.shutdown()
    }
    private companion object { const val SESSION = "active-discovery" }
}
