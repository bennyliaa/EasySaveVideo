package com.easysavevideo.app.discovery

import com.easysavevideo.app.storage.SearxngConfigurationCodec
import com.easysavevideo.searxng.SearxngEndpoint
import com.easysavevideo.searxng.SearxngResultFormat
import java.net.URI
import java.security.MessageDigest
import java.util.Collections
import java.util.Locale

/** Functional endpoint configuration only. Never use this value as diagnostic/log output. */
class SearxngSourceSlot(val id: String, val searchUrl: String? = null, val enabled: Boolean = false,
    val format: SearxngResultFormat = SearxngResultFormat.JSON_VIDEOS) {
    init {
        require(id in SearxngConfigurationPolicy.SLOT_IDS)
        require(searchUrl != null || !enabled)
        searchUrl?.let {
            require(it.length <= SearxngConfigurationPolicy.MAX_URL_BYTES)
            require(it.toByteArray(Charsets.UTF_8).size <= SearxngConfigurationPolicy.MAX_URL_BYTES)
            SearxngEndpoint(id, it, format)
        }
    }
    val endpoint: SearxngEndpoint? get() = searchUrl?.let { SearxngEndpoint(id, it, format) }
    val hostname: String? get() = searchUrl?.let { URI(it).host }
    // The endpoint policy fixes HTTPS, /search and the default port. Host is therefore the origin key.
    internal val originKey: String? get() = hostname?.lowercase(Locale.ROOT)
    override fun equals(other: Any?) = other is SearxngSourceSlot && id == other.id && searchUrl == other.searchUrl &&
        enabled == other.enabled && format == other.format
    override fun hashCode() = 31 * (31 * (31 * id.hashCode() + (searchUrl?.hashCode() ?: 0)) + enabled.hashCode()) + format.hashCode()
    override fun toString() = "SearxngSourceSlot([redacted])"
}

/** Revision participates in the fingerprint, so edit-away/edit-back and explicit reset cannot reuse a pool. */
class SearxngSourceConfiguration(val revision: Long, slots: List<SearxngSourceSlot>) {
    val slots: List<SearxngSourceSlot> = Collections.unmodifiableList(slots.toList())
    init {
        require(revision >= 0)
        require(this.slots.map { it.id } == SearxngConfigurationPolicy.SLOT_IDS)
        val origins = this.slots.mapNotNull { it.originKey }
        require(origins.size == origins.toSet().size)
    }
    val generation: String by lazy {
        MessageDigest.getInstance("SHA-256").digest(SearxngConfigurationCodec.encode(this))
            .joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }
    val enabledEndpoints: List<SearxngEndpoint> get() = slots.filter { it.enabled }.mapNotNull { it.endpoint }
    override fun equals(other: Any?) = other is SearxngSourceConfiguration && revision == other.revision && slots == other.slots
    override fun hashCode() = 31 * revision.hashCode() + slots.hashCode()
    override fun toString() = "SearxngSourceConfiguration([redacted])"
}

enum class SearxngConfigurationIssue { INVALID_ENDPOINT, DUPLICATE_ORIGIN, ACKNOWLEDGEMENT_REQUIRED, REVISION_EXHAUSTED, UNKNOWN_SLOT }

sealed interface SearxngConfigurationEdit {
    data class Accepted(val config: SearxngSourceConfiguration) : SearxngConfigurationEdit {
        override fun toString() = "SearxngConfigurationEdit.Accepted([redacted])"
    }
    data object Unchanged : SearxngConfigurationEdit
    data class Rejected(val issue: SearxngConfigurationIssue) : SearxngConfigurationEdit
}

/** Pure policy. No DNS, HTTP, providers, query state, SafeSearch mutations, or implicit normalization. */
object SearxngConfigurationPolicy {
    const val MAX_URL_BYTES = 2048
    val SLOT_IDS: List<String> = Collections.unmodifiableList(listOf("searxng-1", "searxng-2", "searxng-3"))
    fun empty(revision: Long = 0) = SearxngSourceConfiguration(revision, SLOT_IDS.map { SearxngSourceSlot(it) })

    fun acknowledgementRequired(before: SearxngSourceSlot, searchUrl: String, enabled: Boolean,
        format: SearxngResultFormat = before.format): Boolean =
        searchUrl.isNotEmpty() && (before.searchUrl != searchUrl || before.format != format || (!before.enabled && enabled))

    fun replace(config: SearxngSourceConfiguration, slotId: String, searchUrl: String, enabled: Boolean,
        acknowledged: Boolean, format: SearxngResultFormat = config.slots.firstOrNull { it.id == slotId }?.format
            ?: SearxngResultFormat.JSON_VIDEOS): SearxngConfigurationEdit {
        val old = config.slots.firstOrNull { it.id == slotId }
            ?: return SearxngConfigurationEdit.Rejected(SearxngConfigurationIssue.UNKNOWN_SLOT)
        val replacement = try { SearxngSourceSlot(slotId, searchUrl.ifEmpty { null }, enabled,
            if (searchUrl.isEmpty()) SearxngResultFormat.JSON_VIDEOS else format) }
        catch (_: IllegalArgumentException) { return SearxngConfigurationEdit.Rejected(SearxngConfigurationIssue.INVALID_ENDPOINT) }
        if (replacement.originKey != null && config.slots.any { it.id != slotId && it.originKey == replacement.originKey })
            return SearxngConfigurationEdit.Rejected(SearxngConfigurationIssue.DUPLICATE_ORIGIN)
        if (old == replacement) return SearxngConfigurationEdit.Unchanged
        if (acknowledgementRequired(old, searchUrl, enabled, format) && !acknowledged)
            return SearxngConfigurationEdit.Rejected(SearxngConfigurationIssue.ACKNOWLEDGEMENT_REQUIRED)
        if (config.revision == Long.MAX_VALUE)
            return SearxngConfigurationEdit.Rejected(SearxngConfigurationIssue.REVISION_EXHAUSTED)
        return SearxngConfigurationEdit.Accepted(SearxngSourceConfiguration(config.revision + 1,
            config.slots.map { if (it.id == slotId) replacement else it }))
    }

    fun reset(config: SearxngSourceConfiguration): SearxngConfigurationEdit =
        if (config.revision == Long.MAX_VALUE) SearxngConfigurationEdit.Rejected(SearxngConfigurationIssue.REVISION_EXHAUSTED)
        else SearxngConfigurationEdit.Accepted(empty(config.revision + 1))
}
