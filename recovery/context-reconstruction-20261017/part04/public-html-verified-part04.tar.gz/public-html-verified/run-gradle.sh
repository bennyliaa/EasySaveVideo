#!/usr/bin/env bash
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=$(cd "$HERE/.." && pwd)
for arg in "$@"; do
  case "$arg" in *assemble*|*bundle*|*install*|*Signing*|*signing*|*publish*|*upload*) echo 'Recovery wrapper refuses packaging, signing, device and publication tasks' >&2; exit 2;; esac
done
export JAVA_HOME="$ROOT/toolchain/jdk21-module-launchers"
export GRADLE_USER_HOME=/workspace/scratch/df6c1284d5ab/android-build-home/gradle-home
export ANDROID_HOME="$ROOT/toolchain/sdk"
export ANDROID_USER_HOME="$ROOT/toolchain/android-user"
export ESV_BUILD_HOME="$ROOT/toolchain/home"
export HOME="$ESV_BUILD_HOME"
export PATH="$JAVA_HOME/bin:$PATH"
cd "$HERE/source"
exec flock "$ROOT/gradle-build.lock" scripts/gradle-workspace.sh --max-workers=1 --dependency-verification strict -Pkotlin.compiler.execution.strategy=in-process -Pkotlin.incremental=false -Pandroid.builder.sdkDownload=false "$@"
