from pathlib import Path
import json, hashlib, datetime, xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent; S=P/'source'; E=P/'evidence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
log=E/'final-offline-aggregate02.log'
assert (E/'final-offline-aggregate02.exit').read_text().strip()=='0'
text=log.read_text(); assert 'BUILD SUCCESSFUL' in text and 'BUILD FAILED' not in text
assert 'License admission: exact 95 reviewed runtime artifacts verified for both variants' in text
manifest=E/'FINAL_SOURCE_MANIFEST.json'; records=json.loads(manifest.read_text())
assert sha(manifest)=='888e8c0ab63ccffdc80603f7d2d1e69556cf6580a8d57a818d96fc998c3869d1'
for r in records:
 p=S/r['path']; assert p.is_file() and not p.is_symlink() and p.stat().st_size==r['bytes'] and sha(p)==r['sha256'] and bool(p.stat().st_mode&0o111)==r['executable'],r['path']
actual={p.relative_to(S).as_posix() for p in S.rglob('*') if p.is_file() and not any(v in {'.gradle','.kotlin','.git','build'} for v in p.relative_to(S).parts) and p.relative_to(S).as_posix()!='local.properties'}
assert actual=={r['path'] for r in records},sorted(actual^{r['path'] for r in records})
modules=['core-model','core-domain','ui-theme','discovery','commons-provider','searxng-provider','verification-client','verification-local','save','recording','library','hls','app']
start=datetime.datetime.fromisoformat(json.loads((E/'FINAL_RUN_METADATA.json').read_text())['start_utc']).timestamp()
totals={k:0 for k in ['tests','failures','errors','skipped']}; suites=[]; bymodule={}; skipped=[]
for module in modules:
 files=sorted((S/module/'build/test-results'/('testDebugUnitTest' if module=='app' else 'test')).glob('TEST-*.xml')); assert files,module
 counts={k:0 for k in totals}
 for f in files:
  assert f.stat().st_mtime>=start,('stale XML',f)
  t=ET.parse(f).getroot()
  row={'path':f.relative_to(S).as_posix(),'sha256':sha(f),'suite':t.get('name')}
  for k in totals:
   n=int(t.get(k,'0')); counts[k]+=n; totals[k]+=n; row[k]=n
  suites.append(row)
  for case in t.findall('testcase'):
   if case.find('skipped') is not None:skipped.append({'class':case.get('classname'),'test':case.get('name')})
 counts['passed']=counts['tests']-counts['failures']-counts['errors']-counts['skipped']; counts['suites']=len(files); bymodule[module]=counts
assert totals['failures']==totals['errors']==0 and totals['skipped']==2,totals
lint={}
for variant in ['debug','release']:
 p=S/'app/build/reports'/('lint-results-'+variant+'.xml'); assert p.stat().st_mtime>=start
 issues=ET.parse(p).getroot().findall('issue'); severity={x:sum(i.get('severity')==x for i in issues) for x in ['Fatal','Error','Warning','Information']}
 assert severity['Fatal']==severity['Error']==0
 lint[variant]={'severity':severity,'sha256':sha(p),'path':p.relative_to(S).as_posix()}
runtime={}
for variant in ['debug','release']:
 p=S/'app/build/reports'/(variant+'RuntimeClasspath-inventory.tsv'); assert p.stat().st_mtime>=start
 rows=[x.split('\t') for x in p.read_text().splitlines() if x.strip()]
 # The raw inventory includes source project artifacts; admission independently checks the exact external reviewed set.
 sanitized='\n'.join('\t'.join(row[:3]) for row in rows)+'\n'
 out=E/(variant+'RuntimeClasspath-inventory-sanitized.tsv');out.write_text(sanitized)
 runtime[variant]={'artifacts_including_project_modules':len(rows),'raw_report_sha256':sha(p),'sanitized_report_sha256':sha(out),'reviewed_external_runtime_count':95}
assert not list(S.rglob('*.apk'))
receipt={'status':'VERIFIED_NEW_BASELINE_DERIVED_HTML_SLICE_NOT_LOST_CHECKPOINT_RESTORATION','verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_commit':'6d2edfa5680d0163038fde1faa58f693513d0ab8','source_manifest_sha256':sha(manifest),'source_files':len(records),'source_bytes_and_modes_unchanged':True,'verification_mode':'offline strict dependency verification, max-workers=1, in-process Kotlin, all requested tasks rerun','test_suites':len(suites),'totals':totals,'passed':totals['tests']-totals['failures']-totals['errors']-totals['skipped'],'modules':bymodule,'skips':skipped,'lint':lint,'runtime':runtime,'compile':['debug Kotlin','release Kotlin','release Java'],'full_log_sha256':sha(log),'focused_receipt':json.loads((E/'FOCUSED_VERIFICATION.json').read_text()),'replay':json.loads((E/'REPLAY_FINAL_VERIFICATION.json').read_text()),'no_apk':True,'no_device_or_live_search_test':True,'live_qualification':'BLOCKED: ononoki robots429; tiekoetter query robots disallow; no searches attempted','historical_lost_increment_restoration':False}
(E/'FINAL_AGGREGATE_VERIFICATION.json').write_text(json.dumps(receipt,indent=2)+'\n')
(E/'TEST_SUITE_MANIFEST.json').write_text(json.dumps(suites,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
