# Exact four metadata checksums: proposed reproducibility fix

Prepared 2026-10-19 UTC. NOT APPLIED to any ESV source, NOT UPLOADED, NOT BUILT. This directory is an independent proposal. Frozen T0647, signed code10, existing hot Gradle cache and all dependency/security settings remain unchanged.

## Files and exact identities

- Target: gradle/verification-metadata.xml
- Required before-file SHA256: 29b76573f3b03e4dab2257092454eb203c32d9517688991e8ae858cbcfd3b5d2
- Proposed after-file SHA256: 5a94b42c6d27955fd4386dc30f1ee5a8966e0f0e14d5d7c3328f9ca51d6888af
- Unified patch: verification-metadata-four-reviewed-artifacts.patch
- Patch SHA256: 1d89a3334d5eca58067996e4cf8bf8399e05140a8ca950137e99bd5fb8bd49ea
- Standalone proposed XML is included for review, not installed as a trust file.

PATCH_VERIFICATION.json identifies each artifact and its official URL. The diff adds exactly four artifact nodes: two new component entries and one MODULE artifact in each existing JUnit BOM component. All prior artifact nodes and the configuration are byte-preserved. No wildcard trust, ignored artifact, new repository, changed version or verification-disable switch is introduced.

## Evidence and license scope

Evidence contains original metadata bytes freshly downloaded from Maven Central, timestamped HTTPS/HTTP/hash receipts, tagged upstream license snapshots, cloud cache comparisons and static introduction chains. The Windows-reported hashes match both official bytes and existing cloud bytes. Both JUnit MODULE variants have exactly the same 18 constraints as their existing trusted POM, and zero files/direct dependencies. Variant attributes still matter; equality of constraints alone does not replace a resolved-graph test.

Guava and coroutines declare Apache-2.0. JUnit declares EPL-2.0. This proposed change is solely exact existing build-metadata closure; it does not add JUnit runtime code, waive any copyleft policy, authorize new runtime dependencies, or provide a closed-source legal guarantee. Keep the independent 95-artifact runtime admission check.

## Apply only after parent approval in a separate Windows source copy

1. Verify the patch SHA and exact before-file SHA. Abort if either differs; do not normalize/rewrite another file automatically.
2. Review/apply the unified patch to that independent copy only, using a normal patch tool. Verify the after-file SHA equals the value above and the source diff contains only these four artifact additions.
3. Run the original failing resolution/compilation command with strict verification and verify-metadata=true. Do not regenerate all hashes or accept further missing metadata automatically. Any newly reported artifact needs an individual audit.
4. After resolution succeeds, rerun relevant debug/release compilation, unit tests, runtime admission and runtime inventory; require all 95 admitted runtime byte identities and lockfiles to remain equivalent. No APK or installation is authorized by this patch proposal.
5. Establish cold-metadata reproducibility using a NEW disposable Gradle cache as separately coordinated. Preserve the existing good cache. A warm-cache success alone is not acceptance, and copying parsed descriptors to suppress missing-hash failures is not the fix.

No amended Gradle run has occurred in cloud. Independent patch/evidence review passed; see INDEPENDENT_REVIEW.json. The reviewer applied only to a temporary scratch file with zero fuzz and verified byte equality, preserving 701 prior artifact records and adding exactly four. This is not a Gradle or cold-cache acceptance result.
