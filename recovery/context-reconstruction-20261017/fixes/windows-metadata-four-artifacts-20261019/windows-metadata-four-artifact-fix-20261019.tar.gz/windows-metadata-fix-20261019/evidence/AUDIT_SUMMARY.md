# Windows missing metadata checksums: read-only audit

Date: 2026-10-19 UTC. Scope: four missing checksums reported by the Windows build, not mismatched bytes. No source, trust list, lockfile, repository configuration, artifact cache, or signing key was changed. No new Gradle build, clean-cache experiment, APK or publication was performed in this audit.

## Result

All four reported Windows SHA-256 values equal both the existing ESV cloud cache files and new direct, TLS-verified HTTP 200 downloads from official Maven Central. No redirects were followed. Exact download records, raw files, license snapshots and source URLs are in `official/`; cloud cache hashes and descriptor observations are in `cloud/CACHE_AUDIT.json`.

| Coordinate / artifact | Bytes | SHA-256 |
|---|---:|---|
| com.google.guava:guava-parent:33.4.0-jre / POM | 21100 | 3a499ed34a0d9ee0f1bcc39230021a1cd4e2f7dd0426ab6844f585465d41dcd7 |
| org.junit:junit-bom:5.10.2 / MODULE | 6995 | de23b114b3e4119a8fe6eb17bed5a3852816698bace67071579d6d927ebb080a |
| org.junit:junit-bom:5.11.0-M2 / MODULE | 7104 | 86477abcf490d6ca059aa9973cb108d22a506f49d1a5569bb32cc6cbf43c2cce |
| org.jetbrains.kotlinx:kotlinx-coroutines-bom:1.8.0 / POM | 4291 | 1239e9dbe1397cd5971342956b2511bc3ace7b641842e4372a088dcfa8b9ad55 |

Official artifacts:
- https://repo.maven.apache.org/maven2/com/google/guava/guava-parent/33.4.0-jre/guava-parent-33.4.0-jre.pom
- https://repo.maven.apache.org/maven2/org/junit/junit-bom/5.10.2/junit-bom-5.10.2.module
- https://repo.maven.apache.org/maven2/org/junit/junit-bom/5.11.0-M2/junit-bom-5.11.0-M2.module
- https://repo.maven.apache.org/maven2/org/jetbrains/kotlinx/kotlinx-coroutines-bom/1.8.0/kotlinx-coroutines-bom-1.8.0.pom

The existing verification file is unchanged, SHA-256 `29b76573f3b03e4dab2257092454eb203c32d9517688991e8ae858cbcfd3b5d2`. It lists both JUnit POMs but not their MODULEs, and has no component entry for these exact Guava parent and coroutines BOM versions. `verify-metadata` remains true and strict verification was used in the cloud code10 build.

## Why the successful cloud build did not establish cold-build completeness

The cloud has `metadata-2.107/descriptors` entries for all four coordinates, plus the parent/child descriptors. Gradle caches parsed component models separately from raw artifact files. A Gradle maintainer documents that a cached component model can avoid walking its parent POM hierarchy again, so a metadata checksum list produced on a warm cache may omit parent entries that another machine needs. Both JUnit POMs explicitly contain the `published-with-gradle-metadata` redirection marker.

Together, the existing parsed-cache entries, missing trust entries, successful strict cloud build, and exact static parent/import chains support a warm-cache traversal difference. This is an evidence-based explanation, not a captured trace of the earlier resolution: no destructive cache reset or isolated cold-cache reproduction was run. The audit did not find evidence of a Windows-specific artifact substitution.

Sources:
- Gradle dependency cache design: https://docs.gradle.org/current/userguide/dependency_caching.html
- Gradle maintainer explanation of parent metadata omissions: https://github.com/gradle/gradle/issues/20194
- Gradle metadata format behavior: https://docs.gradle.org/current/userguide/supported_metadata_formats.html
- Strict metadata verification guidance: https://docs.gradle.org/current/userguide/dependency_verification.html

Read-only `javap` snapshots of the actual installed Gradle 9.6.0 caching and verification repository access classes are retained in `cloud/`; no dependency code was executed by those inspections.

## Existing introduction chains

These are static published/cache descriptor chains, not a new Windows resolved graph. Each edge's source file and SHA-256 is recorded in `cloud/STATIC_INTRODUCTION_CHAINS.json`.

1. AGP 9.4.0 -> sdk-common 32.4.0 -> Guava 33.4.0-jre -> Guava parent 33.4.0-jre.
2. AGP 9.4.0 -> commons-io 2.16.1 -> commons-parent 69 -> imported JUnit BOM 5.10.2.
3. AGP 9.4.0 -> sdk-common 32.4.0 -> commons-compress 1.27.1 -> commons-parent 72 -> imported JUnit BOM 5.11.0-M2.
4. Kotlin Gradle Plugin 2.2.10 -> kotlin-compiler-runner 2.2.10 -> coroutines-core-jvm 1.8.0 -> imported coroutines BOM 1.8.0.

The two JUnit MODULE files have two platform variants each, each containing exactly the same 18 version constraints as its already-listed POM, and zero file artifacts or direct dependencies. See `cloud/JUNIT_POM_MODULE_CONSTRAINT_EQUALITY.json`. Resolving an imported producer BOM does not itself add the producer's test library JARs to the consumer.

## License and runtime boundary

- Guava v33.4.0: Apache-2.0, official tagged license https://github.com/google/guava/blob/v33.4.0/LICENSE
- JUnit r5.10.2 / r5.11.0-M2: EPL-2.0, official tagged licenses https://github.com/junit-team/junit5/blob/r5.10.2/LICENSE.md and https://github.com/junit-team/junit5/blob/r5.11.0-M2/LICENSE.md
- coroutines 1.8.0: Apache-2.0, official tagged license https://github.com/Kotlin/kotlinx.coroutines/blob/1.8.0/LICENSE.txt

This is an exact build-descriptor audit, not blanket admission of JUnit or other code into a closed-source runtime and not a legal guarantee. Metadata can affect selection and remains security-relevant. The unchanged code10 production runtime inventory contains 95 admitted external artifacts; Guava is 33.3.1-android, coroutines is 1.10.2, and no JUnit artifact appears. No new runtime library or version is proposed.

## Minimal safe next change, not applied

1. In a separate Windows development copy, add only the four named artifact SHA-256 records above to the existing `gradle/verification-metadata.xml`, preserving existing JUnit POM records. Record the official URLs and this audit as provenance.
2. Do not run blind `--write-verification-metadata`, disable verification, trust wildcard metadata, force POM-only resolution, alter versions/repositories, or copy warm parsed descriptors merely to hide the omissions.
3. Rerun the same previously failing command under strict verification. Any additional missing checksum is a separate audit item, not authority to accept it automatically.
4. Once resolution passes, rerun relevant compilation/tests and runtime admission/inventory, comparing all 95 admitted runtime bytes and the lockfiles. A separate cold-metadata-cache check is useful for reproducibility but must use a new disposable cache and preserve the existing good cache; it has not yet been performed.
5. The existing signed code10 APK and its frozen source/receipts remain unchanged. This audit does not justify a new APK or an installation.

No trust changes have been made. The parent task must decide the bounded amendment in the independent Windows copy.
