# ESV Windows missing-metadata audit: official upstream bytes

Audit completed: 2026-10-19T02:11:30.331892+00:00

## Result and scope

All four supplied Windows SHA-256 fingerprints match fresh downloads of the exact POM / Gradle Module Metadata files from the official Maven Central HTTPS endpoint. No mismatch was found. This is an independent upstream-byte comparison; the Windows files themselves and the existing Gradle cache were not read by this audit worker.

Only new audit files in this directory were written. No dependency was executed or installed; no project dependency declaration, lockfile, verification manifest, signing key, security setting, or runtime admission list was changed. No private credentials were read or supplied.

HTTP 200, TLS verification result 0, and zero redirects were recorded for all six Maven metadata downloads and all four tagged project license files. Only selected non-sensitive HTTP headers were retained. The raw metadata files are unmodified and can be rehashed.

## Four missing metadata fingerprints

### com.google.guava:guava-parent:33.4.0-jre (POM)

- Official URL: https://repo.maven.apache.org/maven2/com/google/guava/guava-parent/33.4.0-jre/guava-parent-33.4.0-jre.pom
- Download began (UTC): 2026-10-19T02:09:11.825299+00:00
- Download finished (UTC): 2026-10-19T02:09:18.410368+00:00
- Size: 21100 bytes
- SHA-256, downloaded bytes: 3a499ed34a0d9ee0f1bcc39230021a1cd4e2f7dd0426ab6844f585465d41dcd7
- SHA-256, supplied Windows report: 3a499ed34a0d9ee0f1bcc39230021a1cd4e2f7dd0426ab6844f585465d41dcd7
- Comparison: EXACT MATCH
- Saved file: guava-parent-33.4.0-jre.pom

### org.junit:junit-bom:5.10.2 (MODULE)

- Official URL: https://repo.maven.apache.org/maven2/org/junit/junit-bom/5.10.2/junit-bom-5.10.2.module
- Download began (UTC): 2026-10-19T02:09:18.411928+00:00
- Download finished (UTC): 2026-10-19T02:09:22.523823+00:00
- Size: 6995 bytes
- SHA-256, downloaded bytes: de23b114b3e4119a8fe6eb17bed5a3852816698bace67071579d6d927ebb080a
- SHA-256, supplied Windows report: de23b114b3e4119a8fe6eb17bed5a3852816698bace67071579d6d927ebb080a
- Comparison: EXACT MATCH
- Saved file: junit-bom-5.10.2.module

### org.junit:junit-bom:5.11.0-M2 (MODULE)

- Official URL: https://repo.maven.apache.org/maven2/org/junit/junit-bom/5.11.0-M2/junit-bom-5.11.0-M2.module
- Download began (UTC): 2026-10-19T02:09:22.524203+00:00
- Download finished (UTC): 2026-10-19T02:09:26.953231+00:00
- Size: 7104 bytes
- SHA-256, downloaded bytes: 86477abcf490d6ca059aa9973cb108d22a506f49d1a5569bb32cc6cbf43c2cce
- SHA-256, supplied Windows report: 86477abcf490d6ca059aa9973cb108d22a506f49d1a5569bb32cc6cbf43c2cce
- Comparison: EXACT MATCH
- Saved file: junit-bom-5.11.0-M2.module

### org.jetbrains.kotlinx:kotlinx-coroutines-bom:1.8.0 (POM)

- Official URL: https://repo.maven.apache.org/maven2/org/jetbrains/kotlinx/kotlinx-coroutines-bom/1.8.0/kotlinx-coroutines-bom-1.8.0.pom
- Download began (UTC): 2026-10-19T02:09:26.953647+00:00
- Download finished (UTC): 2026-10-19T02:09:31.965756+00:00
- Size: 4291 bytes
- SHA-256, downloaded bytes: 1239e9dbe1397cd5971342956b2511bc3ace7b641842e4372a088dcfa8b9ad55
- SHA-256, supplied Windows report: 1239e9dbe1397cd5971342956b2511bc3ace7b641842e4372a088dcfa8b9ad55
- Comparison: EXACT MATCH
- Saved file: kotlinx-coroutines-bom-1.8.0.pom

## Metadata role and runtime boundary

- Guava parent 33.4.0-jre: XML POM with packaging `pom`, zero direct dependencies, and four dependency-management entries (jsr305, checker-qual, error_prone_annotations, j2objc-annotations). It is parent/build metadata, not the Guava JAR. Its managed versions and inherited settings can affect resolution; its contents alone do not establish which runtime artifact enters ESV.
- JUnit BOM 5.10.2 and 5.11.0-M2: JSON Gradle Module Metadata format 1.1. Each has `apiElements` and `runtimeElements`, both categorized as `platform`; each variant has 18 dependency constraints, zero direct dependencies, and zero artifact files. The two variants have identical constraints. Versions are 5.10.2 / 1.10.2 and 5.11.0-M2 / 1.11.0-M2 respectively. The name `runtimeElements` is a variant usage label, not evidence of a runtime JAR. Both companion POMs are packaging `pom`, with zero direct dependencies and 18 managed entries.
- kotlinx-coroutines BOM 1.8.0: XML POM with packaging `pom`, zero direct dependencies, and 17 managed coroutines-module versions. The BOM is not coroutines-core-jvm or an Android runtime binary.
- Therefore a narrowly scoped hash entry for one of these exact filenames would verify that metadata file only. It would not approve every managed/selected module or bypass its binary verification. Metadata remains security-relevant because it can affect transitive dependency selection. Keep strict verification and runtime/binary checks in force.
- This audit does not establish the actual selected Windows dependency graph, why another OS/cache did not request these descriptors, APK contents, runtime compatibility, safety from vulnerabilities, or license compliance for ESV. Those require the separate resolution/cache/build/runtime reviews.
- JUnit 5.11.0-M2 is a milestone-named published BOM. Its module field says `org.gradle.status=release`; that generic status does not make the version a final stable JUnit release and does not mean its constraints are selected runtime code.

## Authoritative project license / source boundary

These are observed upstream declarations, not a blanket license or redistribution clearance. The `.module` files contain no license declaration; JUnit license identification is corroborated by the matching-version official Maven POM and tagged upstream project LICENSE.md. Project-level licenses do not replace checking any separately distributed binaries, embedded third-party components, notices, or transitives.

### Guava 33.4.0

- Official POM declares Apache License, Version 2.0 and SCM https://github.com/google/guava.
- Tagged project license: https://github.com/google/guava/blob/v33.4.0/LICENSE
- Tagged source boundary: https://github.com/google/guava/tree/v33.4.0
- The downloaded tagged LICENSE text identifies Apache License 2.0. No complete source archive was downloaded, no source-to-binary reproduction was performed, and no claim is made about all unrelated transitive artifacts.

### JUnit BOM 5.10.2 and 5.11.0-M2

- Both matching-version official Maven POMs declare Eclipse Public License v2.0 and SCM https://github.com/junit-team/junit5.
- Tagged licenses: https://github.com/junit-team/junit5/blob/r5.10.2/LICENSE.md and https://github.com/junit-team/junit5/blob/r5.11.0-M2/LICENSE.md
- Tagged source boundaries: https://github.com/junit-team/junit5/tree/r5.10.2 and https://github.com/junit-team/junit5/tree/r5.11.0-M2
- Both downloaded LICENSE.md files identify Eclipse Public License 2.0 and are byte-identical. GitHub browser navigation for the historical junit5 repository now redirects to junit-team/junit-framework; the Maven POM records the historical upstream URL.
- The license declaration concerns the upstream JUnit project/BOM; it is not a license determination for ESV, its compiled application, or all components that a BOM constrains.

### kotlinx.coroutines 1.8.0

- Official BOM POM declares The Apache Software License, Version 2.0 and SCM https://github.com/Kotlin/kotlinx.coroutines.
- Tagged license: https://github.com/Kotlin/kotlinx.coroutines/blob/1.8.0/LICENSE.txt
- Tagged source boundary: https://github.com/Kotlin/kotlinx.coroutines/tree/1.8.0
- The downloaded tagged LICENSE.txt identifies Apache License 2.0. This does not establish the notices or provenance of every coroutines binary or unrelated transitive component.

## Supporting metadata and license acquisition

- File: junit-bom-5.10.2.pom
  - URL: https://repo.maven.apache.org/maven2/org/junit/junit-bom/5.10.2/junit-bom-5.10.2.pom
  - Retrieved UTC: 2026-10-19T02:09:31.966280+00:00 to 2026-10-19T02:09:37.765150+00:00
  - Size: 5649 bytes
  - SHA-256: 169dd904a4b0f6520cffe658cc62292bfe9f3c14a989fa92120724cde43a9968

- File: junit-bom-5.11.0-M2.pom
  - URL: https://repo.maven.apache.org/maven2/org/junit/junit-bom/5.11.0-M2/junit-bom-5.11.0-M2.pom
  - Retrieved UTC: 2026-10-19T02:09:37.765713+00:00 to 2026-10-19T02:09:41.792982+00:00
  - Size: 5706 bytes
  - SHA-256: 4a3ffc4a4edcfec2cb5d619922706a9407161798571939f854dfda73e4e17cc8

- File: guava-v33.4.0-LICENSE.txt
  - URL: https://raw.githubusercontent.com/google/guava/v33.4.0/LICENSE
  - Retrieved UTC: 2026-10-19T02:09:44.798753+00:00 to 2026-10-19T02:10:00.557953+00:00
  - Size: 11358 bytes
  - SHA-256: cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30

- File: junit-r5.10.2-LICENSE.md
  - URL: https://raw.githubusercontent.com/junit-team/junit5/r5.10.2/LICENSE.md
  - Retrieved UTC: 2026-10-19T02:10:00.558264+00:00 to 2026-10-19T02:10:04.392966+00:00
  - Size: 14235 bytes
  - SHA-256: 5aa4cd44c111add178d1c2e2fe36d58a484012c80167df925f826cd64d411bf0

- File: junit-r5.11.0-M2-LICENSE.md
  - URL: https://raw.githubusercontent.com/junit-team/junit5/r5.11.0-M2/LICENSE.md
  - Retrieved UTC: 2026-10-19T02:10:04.393228+00:00 to 2026-10-19T02:10:08.157864+00:00
  - Size: 14235 bytes
  - SHA-256: 5aa4cd44c111add178d1c2e2fe36d58a484012c80167df925f826cd64d411bf0

- File: kotlinx-coroutines-1.8.0-LICENSE.txt
  - URL: https://raw.githubusercontent.com/Kotlin/kotlinx.coroutines/1.8.0/LICENSE.txt
  - Retrieved UTC: 2026-10-19T02:10:08.158138+00:00 to 2026-10-19T02:10:12.377220+00:00
  - Size: 11398 bytes
  - SHA-256: b1febe6399dffb10d19d35e7663ab16300c93cb0476a94115df1cc0097a8ffd8

## Trust limitations and documentation

- Matching SHA-256 proves byte equality to the supplied Windows fingerprint at this observed official endpoint. HTTPS endpoint provenance and tagged project sources were checked; detached PGP signatures, publisher signing identity, tag signatures/immutability, reproducible builds, and a full software bill of materials were not verified.
- Official Central endpoint documentation: https://central.sonatype.org/faq/ssl/ (recognizes repo.maven.apache.org and repo1.maven.org as TLS endpoints).
- Gradle verification documentation: https://docs.gradle.org/current/userguide/dependency_verification.html (distinguishes metadata and artifact verification; warns metadata can influence transitive dependencies).
- Gradle platform/BOM documentation: https://docs.gradle.org/current/userguide/platforms.html (describes platform constraints and Maven dependency-management import).
- Web text extraction could not open the Maven POM/MODULE URLs, so exact-byte retrieval used curl over verified HTTPS instead; all downloads succeeded. There is no remaining download blocker.

## Evidence files

- downloads.json: exact coordinates, URLs, retrieval timestamps, safe response headers, byte counts, SHA-256 and SHA-1, Windows comparison flags, parsed packaging / variant / dependency counts.
- license-downloads.json: tagged public license acquisition URLs, timestamps, byte counts, SHA-256, and HTTP/TLS status.
- Original metadata and tagged license files: retained unchanged in this directory.
- SHA256SUMS: hashes of all report and evidence files except this inventory itself.
