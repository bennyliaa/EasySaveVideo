# Slice09: opt-in Debug Commons request-stage diagnosis

This local delta applies ONLY to the exact frozen code11 source recorded by BASELINE_MANIFEST.json (2,876 files). It is not included in the previously tested code11 APK. It preserves code11 version/signing/build configuration; no APK is assembled here.

## Restore safely

1. Copy the code11 source into a new directory, excluding build/cache/output directories. Verify every BASELINE_MANIFEST.json path with SHA-256 before applying anything.
2. Overlay the archive's source/ files onto that independent copy. There are no deletions.
3. Verify every FINAL_SOURCE_MANIFEST.json entry against the resulting source. Do not overlay onto a different baseline or modify the frozen baseline.
4. Use the already admitted offline JDK21, SDK36, Kotlin/Compose2.2.10, Gradle and strict dependency verification setup. run-gradle.sh documents this cloud workspace's toolchain paths; adjust paths only for the receiving environment, without fetching replacement artifacts or changing release configuration.
5. Serialize builds with the shared build lock. The recorded command runs discovery/test, commons-provider/test, app/testDebugUnitTest, and Release Kotlin/Java compile. Debug compile is part of the app unit-test pipeline.

## What changed

Only Commons receives exact operation/session trace capabilities. The original resolver, connect, handshake, write, strict HTTP reader and JSON parser supply observations. Numeric aliases, bounded enums, safe HTTP status and monotonic duration are the only stored diagnostic fields. No URL/query/title/body/exception text/host/IP/contact is stored. Cache/cooldown/deadline/cancellation are explicit. Missing observations are not fabricated failures. No new request, retry behavior, source, export protocol, entitlement or safety bypass is introduced.

Debug controls in the existing evaluation section explicitly arm one search, stop and preview at most 32 rows. Arming alone makes no request. Normal operation is disabled; Release has no controls. Navigating away, backgrounding, closing or replacing the session revokes ownership. Late responses and immediate cancellation are fenced. OPERATION SUCCESS describes a runtime callback, not accepted/displayed candidates.

## Subsequent device acceptance: UNEXECUTED

Install only under separate authorized device/signature/version handling. On the exact candidate APK, enable the Debug controls, issue one existing Commons search and inspect the safe preview. Preserve HTTP status, phase outcomes, NOT_OBSERVED/INCOMPLETE, truncation and timeout distinctions. Confirm stop, navigation/background, replacement and retry isolation. Do not interpret offline fixture elapsed times as network or first-screen performance. Actual TLS/HTTP failure for the previous code11 symptom remains unknown until this device evidence exists.

No network trial, device install, APK assembly, upload or export was performed for this slice. The source is a reconstructed project continuation, not proof of complete recovery of older functionality.

## Verified offline results

Discovery 462, Commons provider 422, App 4,943 tests: 5,827 total, zero failures/errors/skips. Debug and Release Kotlin/Java compile passed. This slice adds 49 tests; the totals include existing regression coverage. Core module XML comes from run02; App and both compile variants from final run03. Earlier failed runs are preserved and explained in FINAL_VERIFICATION.json. Final delta: 28 files; reconstructed source: 2,892 files.
