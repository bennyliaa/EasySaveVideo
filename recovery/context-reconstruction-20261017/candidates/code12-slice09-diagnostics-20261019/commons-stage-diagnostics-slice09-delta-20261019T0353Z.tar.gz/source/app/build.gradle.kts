import java.security.MessageDigest
import org.gradle.api.tasks.PathSensitivity
import org.gradle.api.tasks.testing.Test

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.easysavevideo.app"
    compileSdk = 36
    buildToolsVersion = "36.0.0"
    defaultConfig {
        applicationId = "com.easysavevideo.app"
        minSdk = 31
        targetSdk = 36
        versionCode = 9
        versionName = "0.9.0-ui-dev"
        testInstrumentationRunner = "com.easysavevideo.app.validation.OwnedVerificationInstrumentation"
        // Explicit build identity only. A channel does not select billing or authorize release.
        val distributionChannel = providers.gradleProperty("esv.distribution.channel").orElse("unconfigured").get()
        require(distributionChannel in setOf("unconfigured", "google_play", "huawei", "xiaomi", "oppo", "vivo", "tencent_myapp")) {
            "Unsupported ESV distribution channel; use an exact documented build value"
        }
        buildConfigField("String", "DISTRIBUTION_CHANNEL", "\"$distributionChannel\"")
        val commonsContact = providers.gradleProperty("esv.commons.contact")
            .orElse(providers.environmentVariable("ESV_COMMONS_CONTACT")).orElse("").get()
        require(commonsContact.isEmpty() || (commonsContact.length <= 256 &&
            commonsContact.all { it.code in 33..126 && it !in "()\\\"" })) { "Invalid Commons service contact" }
        buildConfigField("String", "COMMONS_CONTACT", "\"$commonsContact\"")
        buildConfigField("boolean", "COMMONS_ENABLED", (commonsContact.isNotEmpty() &&
            providers.gradleProperty("esv.commons.enabled").orElse("true").get() == "true").toString())
    }
    buildFeatures { compose = true; buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    lint { abortOnError = true; checkReleaseBuilds = true }
}
dependencies {
    // Exact reviewed Coil core-only graph; network fetching remains the original ESV adapter.
    implementation("io.coil-kt.coil3:coil-core:3.3.0")
    // Exact official WebKit 1.17.1 admission; runtime privacy still feature-gated.
    implementation("androidx.webkit:webkit:1.17.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0") {
        // Already reviewed runtime bytes; the main anonymous-image adapter also requires compile visibility.
        exclude(group = "org.jetbrains.kotlin")
    }
    implementation(project(":core-model"))
    implementation(project(":core-domain"))
    implementation(project(":discovery"))
    implementation(project(":commons-provider"))
    implementation(project(":searxng-provider"))
    implementation(project(":verification-client"))
    implementation(project(":verification-local"))
    implementation(project(":save"))
    implementation(project(":recording"))
    implementation(project(":library"))
    implementation(project(":hls"))
    // Exact reviewed dependency graph. New Vault runtime source has an independent scope gate; entry remains disabled.
    implementation("com.google.crypto.tink:tink-android:1.23.0")
    implementation("androidx.media3:media3-transformer:1.11.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.11.1")
    // Align all app compilation/runtime configurations with the four audited runtime migrations.
    // These constraints do not add modules or force an older dependency over Media3's requirements.
    constraints {
        implementation("androidx.concurrent:concurrent-futures:1.2.0")
        implementation("com.google.guava:listenablefuture:9999.0-empty-to-avoid-conflict-with-guava")
        implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core-jvm:1.9.0")
        implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    }
    implementation(project(":ui-theme"))
    implementation(platform("androidx.compose:compose-bom:2025.06.01"))
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.runtime:runtime")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3:1.3.2")
    implementation("androidx.compose.material3:material3-window-size-class:1.3.2")
    implementation("androidx.navigation:navigation-compose:2.8.9")
    testImplementation("junit:junit:4.13.2")
}


// JVM contract tests also read these project files directly, outside their classpath.
// Keep this list aligned with the resource/source contract tests in src/test/kotlin.
// final_*.xml is intentionally a tree: FinalResourceContractTest enumerates that set.
val contractResourceInputs = fileTree("src/main/res") {
    for (locale in listOf("values", "values-zh-rCN")) {
        for (resource in listOf(
            "private_recording.xml", "editor_back.xml", "settings_discovery.xml", "settings_privacy.xml", "settings_entitlements.xml", "settings_destination.xml", "settings_browser.xml", "save_concurrency.xml", "save_normalization.xml",
            "recording_notification.xml", "save_authentication_origin.xml", "save_runtime_notice.xml", "save_authentication_navigation.xml", "save_display.xml", "discovery_body.xml", "discovery_recovery.xml", "discovery_address.xml", "discovery_pending.xml", "input_clear.xml",
            "ordinary_destination.xml", "ordinary_destination_display.xml", "browser_copy.xml", "bookmark_panel.xml", "history_panel.xml", "browser_permission_notice.xml", "browser_cookie_clear.xml", "save_wifi.xml", "editor_defaults.xml", "video_presence.xml", "browser_js_dialog.xml", "new_tab_search.xml", "directory_batch.xml", "discovery_copy.xml", "discovery_layout.xml",
            "discovery_presentation.xml", "discovery_power.xml", "searxng_settings.xml", "verification_candidate_scope.xml", "filter_copy.xml", "finite_i18n.xml", "save_failure_guidance.xml",
            "library_batch_export.xml", "export_recovery.xml", "save_recovery.xml", "save_evaluation.xml", "save_method_settings.xml", "library_multi.xml", "library_display.xml", "provider_copy.xml",
            "provider_dialog.xml", "region_validation.xml", "responsive_panes.xml", "runtime_messages.xml", "vault_runtime.xml", "vault_playback.xml", "vault_auto_lock_settings.xml", "vault_thumbnails.xml", "final_*.xml"
        )) include("$locale/$resource")
    }
}
val contractSourceInputs = files(
    "src/main/kotlin/com/easysavevideo/app/ui/shell/SaveMethodSettingsDetail.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/SaveMethodSettingsActions.kt",
    "src/main/kotlin/com/easysavevideo/app/storage/SaveMethodPreferenceBoundary.kt",
    "src/main/kotlin/com/easysavevideo/app/save/RecordingSaveEvaluationTaskBinding.kt",
    fileTree("src/androidTest") { include("**/*.kt", "**/*.java", "AndroidManifest.xml") },
    "../docs/discovery/EVALUATION_EXPORT_DEVICE_ACCEPTANCE_20261018.md",
    "src/main/kotlin/com/easysavevideo/app/save/SealedEvaluationExport.kt",
    "src/main/kotlin/com/easysavevideo/app/save/AndroidEvaluationReportExport.kt",
    "src/debug/kotlin/com/easysavevideo/app/ui/CommonsStageDiagnosticsPanel.kt",
    "src/release/kotlin/com/easysavevideo/app/ui/CommonsStageDiagnosticsPanel.kt",
    "src/main/kotlin/com/easysavevideo/app/discovery/DebugCommonsStageDiagnosticsOwner.kt",
    "src/main/kotlin/com/easysavevideo/app/discovery/CommonsStageDiagnosticsPresentation.kt",
    "src/debug/res/values/commons_stage_diagnostics.xml",
    "src/debug/res/values-zh-rCN/commons_stage_diagnostics.xml",
    "../docs/discovery/COMMONS_STAGE_DEBUG_UI_20261019.md",
    "src/debug/kotlin/com/easysavevideo/app/ui/SaveEvaluationPanel.kt",
    "src/release/kotlin/com/easysavevideo/app/ui/SaveEvaluationPanel.kt",
    "src/main/kotlin/com/easysavevideo/app/save/DebugSaveEvaluationOwner.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveEvaluationTaskBinding.kt",
    fileTree("src/main/kotlin/com/easysavevideo/app/vault") { include("**/*.kt") },
    "src/main/AndroidManifest.xml",
    "build.gradle.kts",
    "src/main/kotlin/com/easysavevideo/app/library/storage/AndroidLibraryRepository.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/RuntimeMessageCopy.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/RuntimeMessageResources.kt",
    "src/main/kotlin/com/easysavevideo/app/discovery/CommonsSourceRegistration.kt",
    "src/main/kotlin/com/easysavevideo/app/discovery/thumbnail/CommonsThumbnailReader.kt",
    "src/main/kotlin/com/easysavevideo/app/discovery/thumbnail/AndroidDiscoveryThumbnails.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/DiscoveryVerificationResources.kt",
    "src/main/res/values/flow_states.xml",
    "src/main/res/values-zh-rCN/flow_states.xml",
    "src/main/kotlin/com/easysavevideo/app/ui/DiscoveryAddressInput.kt",
    "src/main/kotlin/com/easysavevideo/app/discovery/DiscoveryPresentationCopy.kt",
    "src/main/kotlin/com/easysavevideo/app/discovery/DiscoverySourceUiFence.kt",
    "src/main/kotlin/com/easysavevideo/app/storage/DiscoveryCheckpointCodec.kt",
    "src/main/kotlin/com/easysavevideo/app/discovery/DiscoveryPresentationPolicy.kt",
    "src/main/kotlin/com/easysavevideo/app/discovery/RightsPresentationPolicy.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/DiscoveryPresentationResources.kt",
    "src/main/kotlin/com/easysavevideo/app/save/storage/OwnedDirectTechnicalDiagnostics.kt",
    "src/androidTest/kotlin/com/easysavevideo/app/validation/OwnedVerificationInstrumentation.kt",
    "src/androidTest/kotlin/com/easysavevideo/app/validation/OpusTechnicalValidation.kt",
    "../save/src/main/kotlin/com/easysavevideo/save/ControlledDirectPipeline.kt",
    "src/main/kotlin/com/easysavevideo/app/save/DirectConvertedAndroidVerifier.kt",
    "src/main/kotlin/com/easysavevideo/app/save/storage/AdoptedCanonicalOutputOwner.kt",
    "src/main/kotlin/com/easysavevideo/app/save/storage/AdoptedVerificationBindings.kt",
    "src/main/kotlin/com/easysavevideo/app/save/storage/AndroidNormalizedCommitJournal.kt",
    "src/main/kotlin/com/easysavevideo/app/save/storage/DirectRawSelectionPolicy.kt",
    "src/main/kotlin/com/easysavevideo/app/save/storage/NormalizationDurableMutationPolicy.kt",
    "src/main/kotlin/com/easysavevideo/app/save/storage/NormalizedCommitProtocol.kt",
    "src/main/kotlin/com/easysavevideo/app/editor/verification/AndroidEditOutputVerifier.kt",
    "src/main/kotlin/com/easysavevideo/app/editor/verification/EditVerificationPolicy.kt",
    "src/main/kotlin/com/easysavevideo/app/editor/verification/EditMp4Probe.kt",
    "src/main/kotlin/com/easysavevideo/app/editor/verification/EditAacConfigPolicy.kt",
    "src/main/kotlin/com/easysavevideo/app/media/verification/AndroidAvcAacOutputInspection.kt",
    "src/main/kotlin/com/easysavevideo/app/media/verification/AvcAacMp4Probe.kt",
    "src/main/kotlin/com/easysavevideo/app/media/verification/AvcAacOutputExpectation.kt",
    "src/main/kotlin/com/easysavevideo/app/media/verification/AvcAacVerificationPolicy.kt",
    "src/main/kotlin/com/easysavevideo/app/media/verification/BorrowedAvcAacInspection.kt",
    "src/main/kotlin/com/easysavevideo/app/editor/engine/Media3EditorEngine.kt",
    "src/main/kotlin/com/easysavevideo/app/media/transform/SharedTransformerRuntime.kt",
    "src/main/kotlin/com/easysavevideo/app/media/transform/TransformerSessionRunner.kt",
    "src/main/kotlin/com/easysavevideo/app/media/transform/TransformerSessionExecution.kt",
    "src/main/kotlin/com/easysavevideo/app/media/transform/TransformerRunSpec.kt",
    "src/main/kotlin/com/easysavevideo/app/media/transform/TransformerEngine.kt",
    "src/main/kotlin/com/easysavevideo/app/media/transform/TransformerDataSource.kt",
    "src/main/kotlin/com/easysavevideo/app/media/transform/TransformerNativeFactories.kt",
    "src/debug/kotlin/com/easysavevideo/app/entitlements/BuildEntitlements.kt",
    "src/release/kotlin/com/easysavevideo/app/entitlements/BuildEntitlements.kt",

    "src/main/java/com/easysavevideo/app/browser/privacy/PrivatePlatformTextInputMethodRequest.java",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/PrivateEditorInfo.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/CapturedPrivateActions.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/PrivateChildCompositionScheduler.kt",
    "src/main/kotlin/com/easysavevideo/app/recording/OwnedPrivateRecordingPresentationPort.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/PrivateCaptureWindowState.kt",
    "src/main/kotlin/com/easysavevideo/app/recording/PendingPrivateRecordingPresentationPort.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/PrivateMainPresentationOwner.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/PrivateEditorInfoApi34.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/PrivateEditorInfoApi35.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/PrivateEditorInfoApi36.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/PrivateInputDelegateLease.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/PrivateInputLifetime.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/RevocableInputConnection.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/RevocableInputConnectionApi33.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/RevocableInputConnectionApi34.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/RevocableInputConnectionState.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/PrivateAppDialog.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/PrivateDialogTeardown.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/PrivateBrowsingPresentation.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/PrivateBrowsingRuntime.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/AndroidPrivateProfileBackend.kt",

    "src/main/kotlin/com/easysavevideo/app/save/storage/NormalizationAttemptOwner.kt",
    "src/main/kotlin/com/easysavevideo/app/save/AndroidLocalMp4Verifier.kt",
    "src/main/kotlin/com/easysavevideo/app/save/DirectNormalizedAndroidVerifier.kt",
    "src/main/kotlin/com/easysavevideo/app/save/DirectAndroidOutputInspection.kt",
    "src/main/kotlin/com/easysavevideo/app/save/DirectAndroidAudioInspection.kt",
    "src/main/kotlin/com/easysavevideo/app/save/storage/NormalizationWorkspaceSchema.kt",
    "src/main/kotlin/com/easysavevideo/app/save/storage/NormalizationWorkspaceProtocol.kt",
    "src/main/kotlin/com/easysavevideo/app/save/storage/NormalizationWorkspaceCodec.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveTaskTextResources.kt",
    "src/main/res/values/save_normalization.xml",
    "src/main/res/values-zh-rCN/save_normalization.xml",
    "src/main/kotlin/com/easysavevideo/app/save/SaveSettingsOwner.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveWorkerHandoff.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveExecutionRetirement.kt",
    "src/main/kotlin/com/easysavevideo/app/save/PrivateNetworkRuntimeSources.kt",
    "src/main/kotlin/com/easysavevideo/app/recording/AndroidRecordSavePort.kt",
    "src/main/kotlin/com/easysavevideo/app/recording/AndroidRecordingSession.kt",
    "src/main/kotlin/com/easysavevideo/app/recording/PrivateRecordingNativeBinding.kt",
    "src/main/kotlin/com/easysavevideo/app/recording/PrivateRecordingBridge.kt",
    "src/main/kotlin/com/easysavevideo/app/recording/PrivateRecordingContinuation.kt",
    "src/main/kotlin/com/easysavevideo/app/recording/RecordingConsentController.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/PrivateRecordingPresentationUi.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/RecordingSessionControls.kt",
    "src/main/kotlin/com/easysavevideo/app/recording/ContinuousRecordingOwner.kt",
    "src/main/kotlin/com/easysavevideo/app/recording/BasicCaptureGeometry.kt",

    "src/main/kotlin/com/easysavevideo/app/browser/privacy/PrivateContentRoot.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/PrivateRootProtectionState.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/privacy/PrivateWindowGuard.kt",
    "src/main/kotlin/com/easysavevideo/app/save/PrivateNetworkSourceOwner.kt",
    "src/main/kotlin/com/easysavevideo/app/save/storage/AndroidSaveStorage.kt",
    "src/main/kotlin/com/easysavevideo/app/save/storage/AndroidControlledDirectStorage.kt",
    "src/main/kotlin/com/easysavevideo/app/save/storage/OwnedDirectTranscodeAttempt.kt",
    "../save/src/main/kotlin/com/easysavevideo/save/SaveCoordinator.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/SettingsNavigation.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/BrowserSettingsDetail.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/BrowserSettingsActions.kt",
    "src/main/kotlin/com/easysavevideo/app/library/export/ExportRecoveryCheck.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveTaskCommandGate.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveResumeHandoff.kt",
    "src/main/kotlin/com/easysavevideo/app/library/AndroidLibraryRuntime.kt",
    "src/main/kotlin/com/easysavevideo/app/library/LibraryBatchSelection.kt",
    "src/main/kotlin/com/easysavevideo/app/library/LibraryPickerPageReturn.kt",
    "src/main/kotlin/com/easysavevideo/app/library/LibraryExportStatus.kt",
    "src/main/kotlin/com/easysavevideo/app/library/export/AndroidExportRuntime.kt",
    "src/main/kotlin/com/easysavevideo/app/library/export/DirectoryBatchConfirmation.kt",
    "src/main/kotlin/com/easysavevideo/app/library/export/LibraryBatchRouteExit.kt",
    "src/main/kotlin/com/easysavevideo/app/library/destination/DirectoryPickerLifecycle.kt",
    "src/main/kotlin/com/easysavevideo/app/editor/EditorBackPolicy.kt",
    "src/main/kotlin/com/easysavevideo/app/editor/EditorDeadlineGuard.kt",
    "src/main/kotlin/com/easysavevideo/app/editor/ui/EditorBackResources.kt",
    "src/main/kotlin/com/easysavevideo/app/editor/ui/EditorDraftCheckpoint.kt",
    "src/main/kotlin/com/easysavevideo/app/editor/storage/AndroidEditStorage.kt",
    "src/main/kotlin/com/easysavevideo/app/editor/workflow/EditWorkflow.kt",
    "src/main/kotlin/com/easysavevideo/app/editor/ui/EditorPresentation.kt",
    "src/main/kotlin/com/easysavevideo/app/library/destination/OrdinaryDestinationReceipt.kt",
    "src/main/kotlin/com/easysavevideo/app/recording/RecordingNotificationStatus.kt",
    "src/main/kotlin/com/easysavevideo/app/recording/RecordingNotificationDisplay.kt",
    "src/main/kotlin/com/easysavevideo/app/recording/RecordingForegroundService.kt",
    "src/main/kotlin/com/easysavevideo/app/recording/AndroidSegmentRecordingRuntime.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/EsvLocaleContext.kt",
    "src/main/kotlin/com/easysavevideo/app/save/AuthenticationOriginPolicy.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveAuthenticationOriginGuidance.kt",
    "src/main/kotlin/com/easysavevideo/app/discovery/DiscoveryReadingAnchorPolicy.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/DiscoveryReadingAnchor.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveRuntimeNotice.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveRuntimeNoticeResources.kt",
    "src/main/kotlin/com/easysavevideo/app/recording/RecordingScreen.kt",
    "src/main/kotlin/com/easysavevideo/app/theme/EsvDiagnosticNotice.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveAuthenticationNavigation.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveAuthenticationGuidance.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveDisplayFormatting.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveDisplayResources.kt",
    "src/main/kotlin/com/easysavevideo/app/discovery/DiscoveryBodyPresentation.kt",
    "src/main/kotlin/com/easysavevideo/app/discovery/DiscoveryCardNavigation.kt",
    "src/main/kotlin/com/easysavevideo/app/discovery/DiscoveryBodyRecovery.kt",
    "src/main/kotlin/com/easysavevideo/app/discovery/DiscoveryFilterPresentationPolicy.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/InputClearButton.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/InputClearPolicy.kt",
    "src/main/kotlin/com/easysavevideo/app/theme/EsvComposeTheme.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/EsvAppShell.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/ShellNavigationLayout.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/PendingCandidateCards.kt",
    "src/main/kotlin/com/easysavevideo/app/editor/ui/EditorScreen.kt",
    "src/main/kotlin/com/easysavevideo/app/recording/ui/RecordingSegmentsCard.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/ProviderManagementScreen.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/SearxngSourceSettings.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/VerificationServiceSettings.kt",
    "src/main/kotlin/com/easysavevideo/app/library/destination/OrdinaryDestinationUi.kt",
    "src/main/kotlin/com/easysavevideo/app/library/destination/OrdinaryDestinationResources.kt",
    "src/main/kotlin/com/easysavevideo/app/library/destination/OrdinaryDestinationPresentation.kt",
    "src/main/kotlin/com/easysavevideo/app/library/destination/AndroidOrdinaryDestinationRuntime.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveTaskScreen.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/VaultAutoLockSettingsDetail.kt",
    "src/main/kotlin/com/easysavevideo/app/storage/SettingsWriteBoundary.kt",
    "../core-model/src/main/kotlin/com/easysavevideo/core/model/Settings.kt",
    "../core-model/src/main/kotlin/com/easysavevideo/core/model/VaultSessionContract.kt",
    "src/main/kotlin/com/easysavevideo/app/storage/AndroidStores.kt",
    "src/main/kotlin/com/easysavevideo/app/storage/BrowserPersistence.kt",
    "src/main/kotlin/com/easysavevideo/app/save/AndroidSaveNetworkBackend.kt",
    "src/main/kotlin/com/easysavevideo/app/save/stream/AndroidHlsStreamPort.kt",
    "src/main/kotlin/com/easysavevideo/app/editor/AndroidEditRuntime.kt",
    "src/main/kotlin/com/easysavevideo/app/discovery/AndroidDiscoveryController.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/DiscoveryScreen.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/SystemBrowserHost.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/history/AndroidHistoryRuntime.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/history/HistoryRecordingAdapter.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/history/HistoryPanel.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/history/HistoryPanelPresentation.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/history/HistoryPanelActions.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/bookmarks/BookmarkPanel.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/bookmarks/BookmarkPanelPresentation.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/BrowserInspectionDocument.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/BrowserSameDocumentUpdate.kt",
    "../core-domain/src/main/kotlin/com/easysavevideo/core/domain/BrowserSessionController.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/BrowserVideoPresenceScript.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/BrowserScreen.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/BrowserNoticeResources.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/EsvLocaleHost.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/BrowserJsDialog.kt",
    "src/main/kotlin/com/easysavevideo/app/save/AndroidSaveRuntime.kt",
    "src/main/kotlin/com/easysavevideo/app/save/PageSaveDetector.kt",
    "src/main/kotlin/com/easysavevideo/app/save/PageSaveCandidateIndices.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveFailureGuidanceUi.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveAlternativeSelection.kt",
    "src/main/kotlin/com/easysavevideo/app/save/SaveMethodAlternativeUi.kt",
    "src/main/res/values/save_method_alternative.xml",
    "src/main/res/values-zh-rCN/save_method_alternative.xml",
    "src/main/kotlin/com/easysavevideo/app/MainActivity.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/EsvSettingsScreen.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/EsvDestination.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/navigation/RootNavigation.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/DiscoverySettingsDetail.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/PrivacySettingsDetail.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/DiscoveryPrivacySettingsDetail.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/DiscoveryPrivacyActions.kt",
    "src/main/kotlin/com/easysavevideo/app/discovery/DiscoveryLocalControlOwner.kt",
    "src/main/res/values/discovery_privacy.xml",
    "src/main/res/values-zh-rCN/discovery_privacy.xml",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/EntitlementSettingsDetail.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/CentralSaveDestinationSettings.kt",
    "src/main/kotlin/com/easysavevideo/app/library/destination/DestinationSettingsActions.kt",
    "src/main/kotlin/com/easysavevideo/app/library/destination/OrdinaryDestinationUi.kt",
    "src/main/kotlin/com/easysavevideo/app/entitlements/EntitlementExplanation.kt",
    "src/main/kotlin/com/easysavevideo/app/ui/shell/PrivacySettingsActions.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/BrowserCacheClear.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/BrowserCookieClear.kt",
    "src/main/kotlin/com/easysavevideo/app/browser/BrowserNotice.kt",
    "src/main/kotlin/com/easysavevideo/app/library/LibraryScreen.kt",
    "src/main/kotlin/com/easysavevideo/app/library/LibraryBatchExportDialog.kt",
    "src/main/kotlin/com/easysavevideo/app/licenses/ThirdPartyNotices.kt",
    "src/main/assets/third-party-notices.txt"
)
tasks.withType<Test>().configureEach {
    inputs.files(contractResourceInputs).withPropertyName("contractResourceInputs")
        .withPathSensitivity(PathSensitivity.RELATIVE)
    inputs.files(contractSourceInputs).withPropertyName("contractSourceInputs")
        .withPathSensitivity(PathSensitivity.RELATIVE)
}

tasks.register("runtimeInventory") {
    dependsOn(":core-model:jar", ":core-domain:jar", ":ui-theme:jar", ":discovery:jar", ":save:jar", ":recording:jar", ":library:jar", ":hls:jar", ":commons-provider:jar", ":searxng-provider:jar", ":verification-client:jar")
    doLast {
        listOf("debugRuntimeClasspath", "releaseRuntimeClasspath").forEach { name ->
            val output = layout.buildDirectory.file("reports/$name-inventory.tsv").get().asFile
            output.parentFile.mkdirs()
            output.writeText(configurations.getByName(name).resolvedConfiguration.resolvedArtifacts
                .sortedBy { it.moduleVersion.id.toString() }.joinToString("\n", postfix = "\n") { artifact ->
                    val digest = MessageDigest.getInstance("SHA-256").digest(artifact.file.readBytes())
                        .joinToString("") { byte -> "%02x".format(byte) }
                    "${artifact.moduleVersion.id}\t${artifact.file.name}\t$digest\t${artifact.file.absolutePath}"
                })
            println("Runtime inventory: ${output.absolutePath}")
        }
    }
}


// Exact runtime bytes must remain in the reviewed set. A new candidate cannot silently
// enter an implementation merely because dependency resolution succeeded.
val verifyRuntimeAdmission by tasks.registering {
    doLast {
        val admitted = rootProject.file("third_party/admitted-runtime.tsv").readLines()
            .filter { it.isNotBlank() && !it.startsWith("#") }.toSet()
        listOf("debugRuntimeClasspath", "releaseRuntimeClasspath").forEach { variant ->
            val actual = configurations.getByName(variant).resolvedConfiguration.resolvedArtifacts
                .filterNot { it.id.componentIdentifier is org.gradle.api.artifacts.component.ProjectComponentIdentifier }
                .map { artifact ->
                    val digest = MessageDigest.getInstance("SHA-256").digest(artifact.file.readBytes())
                        .joinToString("") { byte -> "%02x".format(byte) }
                    "${artifact.moduleVersion.id}\t${artifact.file.name}\t$digest"
                }.toSet()
            check(actual == admitted) { "Unreviewed runtime graph/bytes for $variant. Review the exact candidate license and update admission evidence before integration." }
        }
        println("License admission: exact ${admitted.size} reviewed runtime artifacts verified for both variants")
    }
}
tasks.configureEach {
    if (name == "preBuild") dependsOn(verifyRuntimeAdmission)
}


// Isolated user-authorized code11 test candidate. Release/default values are unchanged.
android {
    buildTypes {
        getByName("debug") {
            buildConfigField("String", "COMMONS_CONTACT", "\"bennyliaa@gmail.com\"")
            buildConfigField("boolean", "COMMONS_ENABLED", "true")
        }
    }
}
androidComponents {
    onVariants(selector().withBuildType("debug")) { variant ->
        variant.outputs.forEach { output -> output.versionCode.set(11) }
    }
}
