#!/usr/bin/env python3
"""Read-only verification of an independently restored source tree."""
import argparse, hashlib, json
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('source',type=Path); p.add_argument('--baseline',action='store_true'); a=p.parse_args()
r=Path(__file__).resolve().parent
m=r/('BASELINE_MANIFEST.json' if a.baseline else 'evidence/FINAL_SOURCE_MANIFEST.json')
manifest=json.loads(m.read_text()); bad=[]
for rel, expected in manifest.items():
 path=a.source/rel
 if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected: bad.append(rel)
if bad: raise SystemExit('Mismatch: '+', '.join(bad))
print(f'Verified {len(manifest)} SHA-256 source files against {m.name}')
