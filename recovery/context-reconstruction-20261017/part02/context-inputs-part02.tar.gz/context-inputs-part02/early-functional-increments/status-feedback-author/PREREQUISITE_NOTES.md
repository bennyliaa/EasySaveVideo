# Compatible prerequisite required

The source recipe is the display-feedback increment only. It assumes the earlier automatic-pending verification changes and source-authority handling already exist.

Required existing facts and paths include:
- DiscoveryStatus.roundActive, powerPolicy, powerPolicyUpdatePending, requestsThisRound and inFlightCount.
- ProviderDiscoveryProgress, including per-source progress/health fields.
- VideoDiscoveryCoordinator.clearAuthorityState, refreshAuthorityState, accepted publish closure, candidateId early-return in finishFailure, and existing epoch/descriptor/deadline guards.
- Automatic candidate eligibility and bounded per-round candidate verification used by the deterministic test fixtures.
- DiscoveryBodyPresentation, resource-copy adapter, original source-status rows, existing card/pending branches, and Gradle contract input lists.

This recovery contains no earlier scheduler/automatic-verification implementation. It adds only the descriptor-bound current-session display error fact and the associated presentation/resource/test changes. Source lifecycle and source success clearing must remain at the exact existing accepted publication points; a loose merge that changes scheduler/health/authority behavior is outside the recovered increment.

Before using these reconstructed files, a build owner must compare the prerequisite source, review the literal edits, generate an independent current manifest, and rerun applicable tests and compilation. The recorded historical successful run does not validate this transcription or a new merged candidate.
