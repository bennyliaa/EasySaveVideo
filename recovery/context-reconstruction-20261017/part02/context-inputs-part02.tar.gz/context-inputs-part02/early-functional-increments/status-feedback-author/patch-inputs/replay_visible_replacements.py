#!/usr/bin/env python3
"""RECONSTRUCTED / UNVERIFIED literal edit replay from the author's visible tool inputs.

This script has not been run against any source tree in this recovery. It does not
reproduce missing prerequisite files or certify historical source bytes. It reads a
separately supplied compatible prerequisite and writes a NEW sparse overlay only.
"""
from pathlib import Path
import argparse
import json
import shutil

CORE = 'discovery/src/main/kotlin/com/easysavevideo/discovery/'
APP = 'app/src/main/kotlin/com/easysavevideo/app/'
TEST = 'app/src/test/kotlin/com/easysavevideo/app/discovery/'
OPERATIONS = []
def add(path, old, new):
    OPERATIONS.append({'path': path, 'old': old, 'new': new})

add(CORE+'ProviderDiscoveryProgress.kt',
    '    val lastError: DiscoveryError?,\n',
    '    val lastError: DiscoveryError?,\n    /** Final source failure from this session only; never persisted or used for scheduling. */\n    val currentSessionError: DiscoveryError? = null,\n')
add(CORE+'VideoDiscoveryCoordinator.kt',
    '    private val health = mutableMapOf<String, ProviderHealth>()',
    '    private val health = mutableMapOf<String, ProviderHealth>()\n    // Display-only facts, bounded by the registry and scoped to the current session and descriptor.\n    private val sessionSourceErrors = mutableMapOf<String, Pair<ProviderDescriptor, DiscoveryError>>()')
add(CORE+'VideoDiscoveryCoordinator.kt',
    '                checkpoint?.profile?.query?.isNotBlank() == true)\n',
    '                checkpoint?.profile?.query?.isNotBlank() == true).copy(\n                    currentSessionError = sessionSourceErrors[id]?.takeIf { it.first == provider.descriptor }?.second)\n')
add(CORE+'VideoDiscoveryCoordinator.kt',
    '    private fun clearAuthorityState() {\n',
    '    private fun clearAuthorityState() {\n        sessionSourceErrors.clear()\n')
add(CORE+'VideoDiscoveryCoordinator.kt',
    '                health.remove(id); noNewPages.remove(id); retiredAuthoritySources += id',
    '                health.remove(id); sessionSourceErrors.remove(id); noNewPages.remove(id); retiredAuthoritySources += id')
add(CORE+'VideoDiscoveryCoordinator.kt',
    '        observedAuthorityDescriptors.keys.retainAll(descriptors.keys)',
    '        sessionSourceErrors.entries.removeAll { (id, value) -> descriptors[id] != value.first }\n        observedAuthorityDescriptors.keys.retainAll(descriptors.keys)')
add(CORE+'VideoDiscoveryCoordinator.kt',
    '                    health[id] = stagedHealth',
    '                    health[id] = stagedHealth\n                    sessionSourceErrors.remove(id)')
add(CORE+'VideoDiscoveryCoordinator.kt',
    '        val previous = health[request.descriptor.id] ?: ProviderHealth()',
    '        // Candidate failures returned above; these facts never affect source health or demand.\n        sessionSourceErrors[request.descriptor.id] = request.descriptor to error\n        val previous = health[request.descriptor.id] ?: ProviderHealth()')

add(APP+'discovery/DiscoveryBodyPresentation.kt',
    '    SOURCE_CONFIGURATION, UNSUPPORTED_FILTER, FAILED, CAPACITY_REACHED, IDLE,',
    '    SOURCE_CONFIGURATION, UNSUPPORTED_FILTER, FAILED, CAPACITY_REACHED, IDLE,\n    SOURCE_FAILURE, SOURCE_TIMEOUT, SOURCE_INCOMPLETE, SOURCE_COOLDOWN, SOURCE_UNCHECKED,')
add(APP+'discovery/DiscoveryBodyPresentation.kt',
    '    return when (status?.state) {',
    '''    if (status?.state == DiscoveryState.EXHAUSTED || status?.state == DiscoveryState.BACKOFF) {
        when (discoverySourceIssue(status)) {
            DiscoverySourceIssue.FAILURE -> return DiscoveryBodyState.SOURCE_FAILURE
            DiscoverySourceIssue.TIMEOUT -> return DiscoveryBodyState.SOURCE_TIMEOUT
            DiscoverySourceIssue.INCOMPLETE -> return DiscoveryBodyState.SOURCE_INCOMPLETE
            null -> Unit
        }
        if (status?.state == DiscoveryState.BACKOFF && discoveryWaitingOnSource(status)) return DiscoveryBodyState.SOURCE_COOLDOWN
        if (status?.state == DiscoveryState.EXHAUSTED && discoveryHasUncheckedSource(status)) return DiscoveryBodyState.SOURCE_UNCHECKED
    }
    return when (status?.state) {''')
add(APP+'discovery/DiscoveryBodyPresentation.kt',
    '    DiscoveryBodyState.BACKOFF -> DiscoveryBodyText(R.string.discovery_copy_85, R.string.discovery_body_backoff)',
    '''    DiscoveryBodyState.BACKOFF -> DiscoveryBodyText(R.string.discovery_feedback_waiting, R.string.discovery_feedback_waiting_detail)
    DiscoveryBodyState.SOURCE_COOLDOWN -> DiscoveryBodyText(R.string.discovery_copy_85, R.string.discovery_body_backoff)
    DiscoveryBodyState.SOURCE_UNCHECKED -> DiscoveryBodyText(R.string.discovery_feedback_source_unchecked, R.string.discovery_feedback_source_unchecked_detail)
    DiscoveryBodyState.SOURCE_FAILURE -> DiscoveryBodyText(discoverySourceIssueTitle(DiscoverySourceIssue.FAILURE), discoverySourceIssueDetail(DiscoverySourceIssue.FAILURE))
    DiscoveryBodyState.SOURCE_TIMEOUT -> DiscoveryBodyText(discoverySourceIssueTitle(DiscoverySourceIssue.TIMEOUT), discoverySourceIssueDetail(DiscoverySourceIssue.TIMEOUT))
    DiscoveryBodyState.SOURCE_INCOMPLETE -> DiscoveryBodyText(discoverySourceIssueTitle(DiscoverySourceIssue.INCOMPLETE), discoverySourceIssueDetail(DiscoverySourceIssue.INCOMPLETE))''')

FIELDS = [
    ('providerRequestFailed', 'discovery_presentation_provider_request_failed', '本次搜索的来源请求失败', 'Source request failed for this search'),
    ('providerRequestTimedOut', 'discovery_presentation_provider_request_timed_out', '本次搜索的来源请求超时', 'Source request timed out for this search'),
    ('providerRequestIncomplete', 'discovery_presentation_provider_request_incomplete', '本次搜索的来源请求未完成', 'Source request did not complete for this search'),
]
anchor = '    val providerStorageUnavailable: String = "本地进度不可读",'
add(APP+'discovery/DiscoveryPresentationCopy.kt', anchor,
    anchor+'\n'+'\n'.join(f'    val {field}: String = "{zh}",' for field,key,zh,en in FIELDS))
add(APP+'discovery/DiscoveryPresentationPolicy.kt',
    '''        return copy.format(copy.providerProgress, progress.providerId, state,
            if (progress.lastSuccessAtEpochMillis != null) copy.committedPage else "",
            if (progress.hasContinuation) copy.savedContinuation else "")''',
    '''        val issue = when (discoverySourceIssue(progress.currentSessionError)) {
            DiscoverySourceIssue.FAILURE -> copy.providerRequestFailed
            DiscoverySourceIssue.TIMEOUT -> copy.providerRequestTimedOut
            DiscoverySourceIssue.INCOMPLETE -> copy.providerRequestIncomplete
            null -> null
        }
        // NOT_STARTED only describes missing committed progress; a failed attempt did take place.
        val displayedState = if (progress.state == ProviderDiscoveryState.NOT_STARTED && issue != null) issue else state
        return copy.format(copy.providerProgress, progress.providerId, displayedState,
            if (progress.lastSuccessAtEpochMillis != null) copy.committedPage else "",
            if (progress.hasContinuation) copy.savedContinuation else "") +
            if (issue != null && progress.state != ProviderDiscoveryState.NOT_STARTED) " · $issue" else ""''')
anchor = '        providerStorageUnavailable = stringResource(R.string.discovery_presentation_provider_storage_unavailable),'
add(APP+'ui/DiscoveryPresentationResources.kt', anchor,
    anchor+'\n'+'\n'.join(f'        {field} = stringResource(R.string.{key}),' for field,key,zh,en in FIELDS))
anchor = '        providerStorageUnavailable = strings.getValue("discovery_presentation_provider_storage_unavailable"),'
add(TEST+'DiscoveryPresentationResourceFixtures.kt', anchor,
    anchor+'\n'+'\n'.join(f'        {field} = strings.getValue("{key}"),' for field,key,zh,en in FIELDS))
add(TEST+'DiscoveryPresentationResourceContractTest.kt', 'assertEquals(67, en.size)', 'assertEquals(70, en.size)')
add(TEST+'DiscoveryPresentationResourceContractTest.kt', '        val added = setOf(',
    '        val added = setOf(\n'+'\n'.join(f'        "{key}",' for field,key,zh,en in FIELDS))
for folder in ['values','values-zh-rCN']:
    add(f'app/src/main/res/{folder}/discovery_presentation.xml', '</resources>',
        ''.join(f'    <string name="{key}">"{en if folder == "values" else zh}"</string>\n' for field,key,zh,en in FIELDS)+'</resources>')
add('app/src/main/res/values/discovery_pending.xml',
    '    <string name="discovery_pending_notice_scope">Webpages and thumbnails are not fetched automatically. Duration, playability and usage rights are unknown. Only bounded candidates from this query are kept.</string>',
    '    <string name="discovery_pending_notice_scope">When verification is authorized, a limited number of candidate webpages may be checked automatically in the foreground within the round budget. Candidate thumbnails are not fetched automatically. Duration, playability and usage rights remain unverified. Only bounded candidates from this query are kept.</string>')
add('app/src/main/res/values-zh-rCN/discovery_pending.xml',
    '    <string name="discovery_pending_notice_scope">不会自动获取网页或缩略图；时长、可播放性和使用许可均未知。这里只保留本次查询的有界候选。</string>',
    '    <string name="discovery_pending_notice_scope">在验证已获准入时，可在前台按本轮预算自动检查有限候选网页；不会自动获取候选缩略图。时长、可播放性和使用许可仍未核验。这里只保留本次查询的有界候选。</string>')

anchor = 'import com.easysavevideo.app.discovery.discoveryBodyText'
add(APP+'ui/DiscoveryScreen.kt', anchor, anchor+'\n'+'\n'.join(
    'import com.easysavevideo.app.discovery.'+name for name in ['discoverySourceIssue','discoverySourceIssueTitle','discoverySourceIssueDetail','discoveryWaitingOnSource','discoveryHasUncheckedSource','discoveryPendingBudgetSpent']))
anchor = '            EsvText(statusText(state.status, state.storageUnavailable, state.ready), style = v.captionTextStyle, color = v.colors.muted)'
add(APP+'ui/DiscoveryScreen.kt', anchor, anchor+'''
            if (appliedReadable && !controller.filterSearchPending &&
                (bodyState == DiscoveryBodyState.CONTENT || bodyState == DiscoveryBodyState.PENDING_CANDIDATES) &&
                state.status?.state in setOf(DiscoveryState.FILLING, DiscoveryState.BUFFERED, DiscoveryState.BACKOFF, DiscoveryState.EXHAUSTED)) {
                discoverySourceIssue(state.status)?.let { issue ->
                    EsvText(stringResource(discoverySourceIssueDetail(issue)), style = v.captionTextStyle)
                }
            }
            if (appliedReadable && !controller.filterSearchPending &&
                discoveryPendingBudgetSpent(state.status, state.pendingCandidates.isNotEmpty())) {
                EsvText(stringResource(R.string.discovery_feedback_pending_budget,
                    state.status?.requestsThisRound ?: 0, state.status?.powerPolicy?.maxRequestsPerRound ?: 0),
                    style = v.captionTextStyle)
            }''')
add(APP+'ui/DiscoveryScreen.kt', '    val title = when(status?.state) {',
    '''    val issue = discoverySourceIssue(status)
    val title = when {
        (status?.state == DiscoveryState.EXHAUSTED || status?.state == DiscoveryState.BACKOFF) && issue != null ->
            stringResource(discoverySourceIssueTitle(issue))
        status?.state == DiscoveryState.EXHAUSTED && discoveryHasUncheckedSource(status) ->
            stringResource(R.string.discovery_feedback_source_unchecked)
        status?.state == DiscoveryState.BACKOFF && !discoveryWaitingOnSource(status) ->
            stringResource(R.string.discovery_feedback_waiting)
        else -> when(status?.state) {''')
add(APP+'ui/DiscoveryScreen.kt',
    '        else -> stringResource(R.string.discovery_copy_91)\n    }',
    '        else -> stringResource(R.string.discovery_copy_91)\n        }\n    }')
add('app/build.gradle.kts', '"discovery_body.xml", "discovery_recovery.xml"',
    '"discovery_body.xml", "discovery_status_feedback.xml", "discovery_recovery.xml"')
add('app/build.gradle.kts',
    '    "src/main/kotlin/com/easysavevideo/app/discovery/DiscoveryBodyPresentation.kt",',
    '    "src/main/kotlin/com/easysavevideo/app/discovery/DiscoveryBodyPresentation.kt",\n    "src/main/kotlin/com/easysavevideo/app/discovery/DiscoveryStatusFeedback.kt",')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--export-operations', type=Path, help='Only save reconstructed literal operations as JSON; no source tree read.')
    parser.add_argument('--source', type=Path, help='Separately recovered compatible pre-feedback source tree. Never modified.')
    parser.add_argument('--out', type=Path, help='New sparse overlay destination; must not exist.')
    args = parser.parse_args()
    if args.export_operations:
        args.export_operations.write_text(json.dumps({'status':'RECONSTRUCTED_UNVERIFIED', 'operations':OPERATIONS}, ensure_ascii=False, indent=2)+'\n')
        return
    if not args.source or not args.out:
        parser.error('Use --source and --out, or --export-operations.')
    source, out = args.source.resolve(), args.out.resolve()
    if not source.is_dir() or out.exists() or out == source or source in out.parents or out in source.parents:
        parser.error('Source must exist, output must be new and separate from source.')
    if source.name == 'remote-baseline':
        parser.error('The restored older remote-baseline is not the required pre-feedback prerequisite.')
    contents = {}
    for op in OPERATIONS:
        path = op['path']
        if path not in contents:
            contents[path] = (source/path).read_text()
        count = contents[path].count(op['old'])
        if count != 1:
            raise RuntimeError(f'Required historical edit anchor found {count} times: {path}; no output written.')
        contents[path] = contents[path].replace(op['old'], op['new'], 1)
    new_files = Path(__file__).resolve().parents[1]/'new-files'
    for file in new_files.rglob('*'):
        if file.is_file():
            relative = file.relative_to(new_files).as_posix()
            if (source/relative).exists():
                raise RuntimeError(f'New file already exists in supplied prerequisite: {relative}; no output written.')
            contents[relative] = file.read_text()
    assert len(contents) == 19
    for relative, content in contents.items():
        file = out/relative
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_text(content)
    print('RECONSTRUCTED_UNVERIFIED sparse overlay written; no test or historical equality claim.')

if __name__ == '__main__':
    main()
