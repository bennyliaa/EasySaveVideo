package com.easysavevideo.app.discovery

import com.easysavevideo.app.R
import com.easysavevideo.core.model.EpochClock
import com.easysavevideo.discovery.*
import java.io.File
import javax.xml.parsers.DocumentBuilderFactory
import org.junit.Assert.*
import org.junit.Test

/** Real coordinator-to-presentation regressions, entirely deterministic and network-free. */
class DiscoveryStatusFeedbackTest {
    private class Clock(var now: Long = 1000) : EpochClock { override fun nowMillis() = now }
    private class Timer(private val clock: Clock) : DiscoveryTimer {
        private data class Event(val at: Long, val action: () -> Unit, var cancelled: Boolean = false)
        private val events = mutableListOf<Event>()
        override fun schedule(delayMillis: Long, action: () -> Unit): CancellationHandle {
            val event = Event(clock.now + delayMillis, action); events += event
            return CancellationHandle { event.cancelled = true }
        }
        fun advance(millis: Long) {
            val end = clock.now + millis
            while (true) {
                val event = events.filter { !it.cancelled && it.at <= end }.minByOrNull { it.at } ?: break
                events.remove(event); clock.now = event.at; event.action()
            }
            clock.now = end
        }
    }
    private class Runtime : ProviderRuntime {
        data class Call(val provider: VideoSearchProvider, val request: SearchRequest,
            val operation: DiscoveryOperation, val callback: (ProviderOutcome) -> Unit)
        val calls = mutableListOf<Call>()
        override fun execute(provider: VideoSearchProvider, request: SearchRequest, operation: DiscoveryOperation,
            callback: (ProviderOutcome) -> Unit): CancellationHandle {
            calls += Call(provider, request, operation, callback)
            return CancellationHandle { operation.cancellation.cancel() }
        }
        fun fail(index: Int, error: DiscoveryError) = calls[index].callback(ProviderOutcome.Failure(error))
        fun complete(index: Int, results: List<VideoSearchResult> = emptyList(), nextCursor: String? = null) =
            calls[index].callback(ProviderOutcome.Success(ValidatedProviderPage(results, nextCursor, null, nextCursor == null)))
    }
    private class Fixture(count: Int = 1, automatic: Boolean = false, reducedBudget: Boolean = false) : AutoCloseable {
        val clock = Clock(); val timer = Timer(clock); val runtime = Runtime()
        val profile = SearchProfile("profile", "query", filters = SearchFilters(safeSearch = false))
        private val providers = (1..count).map { id -> object : VideoSearchProvider {
            override val descriptor = ProviderDescriptor("p$id", "1")
            override fun search(request: SearchRequest, operation: DiscoveryOperation): ProviderPage = error("No network")
        } }
        val coordinator = VideoDiscoveryCoordinator(ProviderRegistry(providers), runtime, InMemoryDiscoveryStore(), timer, clock,
            automaticCandidateEligibility = if (automatic) ({ true }) else null)
        init {
            coordinator.setVisibility(true, true)
            if (reducedBudget) coordinator.setPowerSignals(DiscoveryPowerSignals(true,
                BatterySignal.LOW, ThermalSignal.NORMAL, NetworkSignal.UNMETERED))
            coordinator.start("session", profile)
        }
        fun body(results: Boolean = false, selected: Boolean = false) = discoveryBodyState(results,
            coordinator.pendingCandidates().isNotEmpty(), selected, true, false, false, false, coordinator.status())
        fun pending(id: Int) = PendingCandidatePolicy.normalize(CandidateUrl("https://fixture.invalid/candidate/$id"), "p1", profile.filters)!!
        fun sourcePending(count: Int = 8) = runtime.calls[0].callback(ProviderOutcome.Success(
            ValidatedProviderPage(emptyList(), null, null, true, (1..count).map(::pending))))
        fun pendingUnknown(index: Int) {
            val call = runtime.calls[index]
            val candidate = PendingCandidatePolicy.normalize(call.provider.search(call.request, call.operation).candidates.single(),
                "p1", profile.filters)!!
            call.callback(ProviderOutcome.Success(ValidatedProviderPage(emptyList(), null, null, true, listOf(candidate),
                listOf(CandidateVerificationReport(candidate.candidateId,
                    VerificationSummary("fixture", EngineOutcome.UNKNOWN, EngineEvidence.NONE))))))
        }
        override fun close() = coordinator.close()
    }
    private fun result() = ResultNormalizer.normalize(RawVideoResult("https://fixture.invalid/video", true), "p1")!!

    @Test fun failureAndTimeoutRemainDistinctFromSuccessfulEmptyAfterCooldown() {
        for ((error, expected) in listOf(DiscoveryError.PROVIDER_FAILURE to DiscoveryBodyState.SOURCE_FAILURE,
            DiscoveryError.DEADLINE_EXCEEDED to DiscoveryBodyState.SOURCE_TIMEOUT,
            DiscoveryError.RATE_LIMITED to DiscoveryBodyState.SOURCE_INCOMPLETE,
            DiscoveryError.INVALID_RESULT to DiscoveryBodyState.SOURCE_INCOMPLETE,
            DiscoveryError.RESPONSE_TOO_LARGE to DiscoveryBodyState.SOURCE_INCOMPLETE)) Fixture().use { f ->
            f.runtime.fail(0, error)
            assertEquals(expected, f.body())
            f.timer.advance(30_000)
            assertEquals(DiscoveryState.EXHAUSTED, f.coordinator.status().state)
            assertEquals(expected, f.body())
            assertNotEquals(R.string.flow_discovery_no_results, discoveryBodyText(f.body())!!.title)
            f.timer.advance(600_000)
            assertEquals(1, f.runtime.calls.size)
            f.coordinator.requestMore(); f.runtime.complete(1)
            assertNull(discoverySourceIssue(f.coordinator.status()))
            assertEquals(DiscoveryBodyState.EXHAUSTED, f.body())
            assertEquals(R.string.flow_discovery_no_results, discoveryBodyText(f.body())!!.title)
        }
    }

    @Test fun successfulSiblingKeepsCardsAndOnlyFailedSourceHasCurrentError() = Fixture(2).use { f ->
        f.runtime.fail(1, DiscoveryError.DEADLINE_EXCEEDED)
        f.runtime.complete(0, listOf(result()))
        assertEquals(DiscoveryBodyState.CONTENT, f.body(results = true))
        assertEquals(DiscoverySourceIssue.TIMEOUT, discoverySourceIssue(f.coordinator.status()))
        assertNull(f.coordinator.status().providers.first { it.providerId == "p1" }.currentSessionError)
        assertEquals(DiscoveryError.DEADLINE_EXCEEDED,
            f.coordinator.status().providers.first { it.providerId == "p2" }.currentSessionError)
        assertTrue(f.coordinator.results(f.coordinator.page(0)!!).isNotEmpty())
    }

    @Test fun candidatesAndContentStillOutrankFeedback() = Fixture(2).use { f ->
        f.sourcePending()
        f.runtime.fail(1, DiscoveryError.PROVIDER_FAILURE)
        assertEquals(DiscoveryBodyState.PENDING_CANDIDATES, f.body())
        assertEquals(DiscoveryBodyState.CONTENT, f.body(results = true))
        assertEquals(DiscoveryBodyState.PENDING_CANDIDATES, f.body(results = true, selected = true))
        assertEquals(DiscoverySourceIssue.FAILURE, discoverySourceIssue(f.coordinator.status()))
    }

    @Test fun oldQueryFailureCannotBecomeCurrentFailureEvenWhenAggregateLastErrorReturns() = Fixture(2).use { f ->
        f.runtime.fail(0, DiscoveryError.PROVIDER_FAILURE)
        f.coordinator.start("session", f.profile.copy(query = "new query"))
        f.runtime.complete(2)
        assertEquals(DiscoveryError.PROVIDER_FAILURE, f.coordinator.status().lastError)
        assertNull(discoverySourceIssue(f.coordinator.status()))
        assertEquals(DiscoveryBodyState.SOURCE_COOLDOWN, f.body())
        f.timer.advance(30_000)
        assertEquals(DiscoveryBodyState.SOURCE_UNCHECKED, f.body())
        assertNull(discoverySourceIssue(f.coordinator.status()))
        assertEquals(3, f.runtime.calls.size)
    }

    @Test fun sameQueryRestartWithSavedPartialProgressIsIncompleteAfterInheritedCooldown() = Fixture().use { f ->
        f.runtime.complete(0, nextCursor = "next")
        f.runtime.fail(1, DiscoveryError.PROVIDER_FAILURE)
        f.coordinator.start("session", f.profile)
        assertEquals(DiscoveryBodyState.SOURCE_COOLDOWN, f.body())
        assertEquals(0, f.coordinator.status().requestsThisRound)
        f.timer.advance(30_000)
        assertEquals(ProviderDiscoveryState.READY, f.coordinator.status().providers.single().state)
        assertEquals(DiscoveryBodyState.SOURCE_UNCHECKED, f.body())
        assertNull(discoverySourceIssue(f.coordinator.status()))
        assertEquals(2, f.runtime.calls.size)
    }

    @Test fun normalPendingPacingIsNeutralAndBudgetAppearsOnlyAfterActualSharedLimit() {
        for (reduced in listOf(false, true)) Fixture(automatic = true, reducedBudget = reduced).use { f ->
            f.sourcePending()
            assertFalse(discoveryPendingBudgetSpent(f.coordinator.status(), true))
            f.pendingUnknown(1)
            assertEquals(DiscoveryState.BACKOFF, f.coordinator.status().state)
            assertFalse(discoveryWaitingOnSource(f.coordinator.status()))
            assertNull(discoverySourceIssue(f.coordinator.status()))
            assertEquals(R.string.discovery_feedback_waiting, discoveryBodyText(DiscoveryBodyState.BACKOFF)!!.title)
            assertFalse(discoveryPendingBudgetSpent(f.coordinator.status(), true))
            val budget = if (reduced) 3 else 6
            for (index in 2 until budget) { f.timer.advance(1000); f.pendingUnknown(index) }
            val status = f.coordinator.status()
            assertEquals(budget, status.powerPolicy.maxRequestsPerRound)
            assertEquals(budget, status.requestsThisRound)
            assertTrue(discoveryPendingBudgetSpent(status, true))
            assertEquals(8, f.coordinator.pendingCandidates().size)
            assertEquals(DiscoveryBodyState.PENDING_CANDIDATES, f.body())
            f.timer.advance(600_000)
            assertEquals(budget, f.runtime.calls.size)
            assertTrue(discoveryPendingBudgetSpent(f.coordinator.status(), true))
        }
    }

    @Test fun budgetFeedbackDoesNotMaskSuspensionInflightErrorsOrPolicyTransition() = Fixture(automatic = true).use { f ->
        f.sourcePending()
        for (index in 1..5) { if (index > 1) f.timer.advance(1000); f.pendingUnknown(index) }
        val spent = f.coordinator.status()
        assertTrue(discoveryPendingBudgetSpent(spent, true))
        assertTrue(discoveryPendingBudgetSpent(spent.copy(state = DiscoveryState.BUFFERED), true))
        // Boundary assertions supplement the real spent-round transition above.
        val blocked = listOf(spent.copy(roundActive = true), spent.copy(inFlightCount = 1),
            spent.copy(state = DiscoveryState.SUSPENDED), spent.copy(state = DiscoveryState.FAILED),
            spent.copy(state = DiscoveryState.UNSUPPORTED_FILTER), spent.copy(powerPolicyUpdatePending = true),
            spent.copy(powerPolicy = spent.powerPolicy.copy(maxRequestsPerRound = 0)),
            spent.copy(requestsThisRound = 5), spent.copy(providers = listOf(spent.providers.single().copy(
                currentSessionError = DiscoveryError.PROVIDER_FAILURE))),
            spent.copy(providers = listOf(spent.providers.single().copy(state = ProviderDiscoveryState.RETRY_WAIT))))
        blocked.forEach { assertFalse(it.toString(), discoveryPendingBudgetSpent(it, true)) }
        assertFalse(discoveryPendingBudgetSpent(spent, false))
        assertFalse(discoveryPendingBudgetSpent(null, true))
        f.coordinator.setVisibility(false, true)
        assertFalse(discoveryPendingBudgetSpent(f.coordinator.status(), true))
    }

    @Test fun unsupportedAndConfigurationStayOnTheirExistingBranches() {
        for ((error, expected) in listOf(DiscoveryError.UNSUPPORTED_FILTER to DiscoveryBodyState.UNSUPPORTED_FILTER,
            DiscoveryError.SOURCE_CONFIGURATION to DiscoveryBodyState.SOURCE_CONFIGURATION,
            DiscoveryError.INVALID_QUERY to DiscoveryBodyState.INVALID_QUERY)) Fixture().use { f ->
            f.runtime.fail(0, error)
            assertEquals(expected, f.body())
            assertNull(discoverySourceIssue(f.coordinator.status()))
        }
        for (error in listOf(DiscoveryError.NO_NEW_RESULTS, DiscoveryError.REPEATED_CURSOR, DiscoveryError.CANCELLED))
            assertNull(discoverySourceIssue(error))
    }

    @Test fun providerFeedbackUsesCurrentSessionFactAndDoesNotCallFailedAttemptNotStarted() = Fixture().use { f ->
        f.runtime.fail(0, DiscoveryError.PROVIDER_FAILURE); f.timer.advance(30_000)
        val progress = f.coordinator.status().providers.single()
        for (folder in listOf("values", "values-zh-rCN")) {
            val copy = discoveryPresentationFixture(folder)
            val rendered = DiscoveryPresentationPolicy.providerProgressText(progress, copy)
            assertTrue(rendered.contains(copy.providerRequestFailed))
            assertFalse(rendered.contains(copy.providerNotStarted))
            assertFalse(DiscoveryPresentationPolicy.providerProgressText(progress.copy(currentSessionError = null), copy)
                .contains(copy.providerRequestFailed))
            assertTrue(DiscoveryPresentationPolicy.providerProgressText(progress.copy(currentSessionError = DiscoveryError.DEADLINE_EXCEEDED), copy)
                .contains(copy.providerRequestTimedOut))
            assertTrue(DiscoveryPresentationPolicy.providerProgressText(progress.copy(currentSessionError = DiscoveryError.RATE_LIMITED), copy)
                .contains(copy.providerRequestIncomplete))
        }
    }

    private fun strings(folder: String, name: String): Map<String, String> {
        val nodes = DocumentBuilderFactory.newInstance().newDocumentBuilder()
            .parse(File(discoveryPresentationResourceRoot(), "$folder/$name.xml")).getElementsByTagName("string")
        return (0 until nodes.length).associate { nodes.item(it).attributes.getNamedItem("name").nodeValue to nodes.item(it).textContent }
    }

    @Test fun pairedCopyIsFiniteHonestAndDoesNotExpandAutomaticVerificationPermission() {
        val en = strings("values", "discovery_status_feedback"); val zh = strings("values-zh-rCN", "discovery_status_feedback")
        assertEquals(11, en.size); assertEquals(en.keys, zh.keys)
        val slots = Regex("%[0-9]+\\$(?:d)")
        for (key in en.keys) {
            assertEquals(slots.findAll(en.getValue(key)).map { it.value }.toList(), slots.findAll(zh.getValue(key)).map { it.value }.toList())
            assertTrue(en.getValue(key).isNotBlank()); assertTrue(zh.getValue(key).isNotBlank())
            assertFalse(en.getValue(key).contains("offline", true)); assertFalse(en.getValue(key).contains("DNS", true))
        }
        assertTrue(en.getValue("discovery_feedback_pending_budget").contains("does not mean every candidate was verified"))
        assertTrue(zh.getValue("discovery_feedback_pending_budget").contains("不代表每个候选都已验证"))
        val scope = strings("values", "discovery_pending").getValue("discovery_pending_notice_scope")
        listOf("When verification is authorized", "foreground", "round budget", "Candidate thumbnails are not fetched automatically")
            .forEach { assertTrue(it, scope.contains(it)) }
        val zhScope = strings("values-zh-rCN", "discovery_pending").getValue("discovery_pending_notice_scope")
        listOf("验证已获准入", "前台", "本轮预算", "不会自动获取候选缩略图").forEach { assertTrue(it, zhScope.contains(it)) }
    }

    @Test fun realScreenWiresInlineFeedbackWithoutRemovingCardsOrIssuingCommands() {
        val root = discoveryPresentationSourceRoot()
        val screen = File(root, "ui/DiscoveryScreen.kt").readText()
        for (required in listOf("discoverySourceIssueDetail(issue)", "discoverySourceIssueTitle(issue)",
            "discoveryPendingBudgetSpent(state.status, state.pendingCandidates.isNotEmpty())",
            "R.string.discovery_feedback_pending_budget", "state.status?.powerPolicy?.maxRequestsPerRound",
            "discoveryHasUncheckedSource(status)", "!discoveryWaitingOnSource(status)",
            "PendingCandidateCards(state.pendingCandidates", "items(state.results", "onClick = controller::retry"))
            assertTrue(required, screen.contains(required))
        val feedback = File(root, "discovery/DiscoveryStatusFeedback.kt").readText()
        for (forbidden in listOf("AndroidDiscoveryController", "java.net.", "CoroutineScope", "LaunchedEffect", "requestMore(", "start("))
            assertFalse(forbidden, feedback.contains(forbidden))
        assertFalse(feedback.contains("status.lastError")); assertFalse(feedback.contains("status.health"))
        val app = listOf(File("."), File("app")).first { File(it, "src/main/res").isDirectory }
        val build = File(app, "build.gradle.kts").readText()
        assertTrue(build.contains("discovery_status_feedback.xml"))
        assertTrue(build.contains("src/main/kotlin/com/easysavevideo/app/discovery/DiscoveryStatusFeedback.kt"))
    }
}
