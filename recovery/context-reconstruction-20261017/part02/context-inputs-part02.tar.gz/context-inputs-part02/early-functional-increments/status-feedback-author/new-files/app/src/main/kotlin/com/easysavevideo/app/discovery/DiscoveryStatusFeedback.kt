package com.easysavevideo.app.discovery

import com.easysavevideo.app.R
import com.easysavevideo.discovery.DiscoveryError
import com.easysavevideo.discovery.DiscoveryState
import com.easysavevideo.discovery.DiscoveryStatus
import com.easysavevideo.discovery.ProviderDiscoveryState

/** Finite display-only reasons. A source request failure never diagnoses device connectivity. */
internal enum class DiscoverySourceIssue { FAILURE, TIMEOUT, INCOMPLETE }

internal fun discoverySourceIssue(error: DiscoveryError?): DiscoverySourceIssue? = when (error) {
    DiscoveryError.PROVIDER_FAILURE -> DiscoverySourceIssue.FAILURE
    DiscoveryError.DEADLINE_EXCEEDED -> DiscoverySourceIssue.TIMEOUT
    DiscoveryError.INVALID_RESULT, DiscoveryError.RESPONSE_TOO_LARGE, DiscoveryError.TOO_MANY_CANDIDATES,
    DiscoveryError.VALIDATOR_UNAVAILABLE, DiscoveryError.BUSY, DiscoveryError.RATE_LIMITED -> DiscoverySourceIssue.INCOMPLETE
    else -> null
}

/** Never use aggregate lastError or cross-session health as evidence of a current search failure. */
internal fun discoverySourceIssue(status: DiscoveryStatus?): DiscoverySourceIssue? {
    val issues = status?.providers?.mapNotNull { discoverySourceIssue(it.currentSessionError) }.orEmpty()
    return DiscoverySourceIssue.entries.firstOrNull { it in issues }
}

internal fun discoverySourceIssueTitle(issue: DiscoverySourceIssue): Int = when (issue) {
    DiscoverySourceIssue.FAILURE -> R.string.discovery_feedback_source_failure
    DiscoverySourceIssue.TIMEOUT -> R.string.discovery_feedback_source_timeout
    DiscoverySourceIssue.INCOMPLETE -> R.string.discovery_feedback_source_incomplete
}

internal fun discoverySourceIssueDetail(issue: DiscoverySourceIssue): Int = when (issue) {
    DiscoverySourceIssue.FAILURE -> R.string.discovery_feedback_source_failure_detail
    DiscoverySourceIssue.TIMEOUT -> R.string.discovery_feedback_source_timeout_detail
    DiscoverySourceIssue.INCOMPLETE -> R.string.discovery_feedback_source_incomplete_detail
}

internal fun discoveryWaitingOnSource(status: DiscoveryStatus?): Boolean = status?.providers?.any {
    it.state == ProviderDiscoveryState.COOLDOWN || it.state == ProviderDiscoveryState.RETRY_WAIT
} == true

/** An inherited source failure can delay a new search, but cannot become that search's failure. */
internal fun discoveryHasUncheckedSource(status: DiscoveryStatus?): Boolean = status?.providers?.any {
    it.state in setOf(ProviderDiscoveryState.NOT_STARTED, ProviderDiscoveryState.READY,
        ProviderDiscoveryState.CURSOR_EXPIRED, ProviderDiscoveryState.CURSOR_INCOMPATIBLE) &&
        it.currentSessionError == null && discoverySourceIssue(it.lastError) != null
} == true

/** Spent requests are shared source/verification attempts, never a count of verified candidates. */
internal fun discoveryPendingBudgetSpent(status: DiscoveryStatus?, hasPendingCandidates: Boolean): Boolean {
    if (!hasPendingCandidates || status == null || status.powerPolicyUpdatePending ||
        !status.powerPolicy.allowsRequests || status.roundActive || status.inFlightCount != 0 ||
        status.state !in setOf(DiscoveryState.EXHAUSTED, DiscoveryState.BUFFERED) || discoverySourceIssue(status) != null ||
        status.providers.any { it.state == ProviderDiscoveryState.REQUESTING || it.state == ProviderDiscoveryState.RETRY_WAIT }) return false
    val budget = status.powerPolicy.maxRequestsPerRound
    return budget > 0 && status.requestsThisRound >= budget
}
