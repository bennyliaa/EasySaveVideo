package com.easysavevideo.discovery

import org.junit.Assert.*
import org.junit.Test

/** Real coordinator transitions with the existing offline runtime and deterministic clock. */
class DiscoverySessionSourceErrorTest {
    private class Fixture(count: Int = 1, automatic: Boolean = false) : AutoCloseable {
        val clock = FakeClock()
        val timer = FakeTimer(clock)
        val runtime = FakeRuntime()
        val store = InMemoryDiscoveryStore()
        val providers = (1..count).map { StubProvider(ProviderDescriptor("p$it", "1")) }
        val profile = SearchProfile("profile", "query", filters = SearchFilters(safeSearch = false))
        val registry = ProviderRegistry(providers)
        val coordinator = VideoDiscoveryCoordinator(registry, runtime, store, timer, clock,
            automaticCandidateEligibility = if (automatic) ({ true }) else null, retryDelayMillis = { 1000 })
        init { coordinator.setVisibility(true, true); coordinator.start("session", profile) }
        fun error(id: String = "p1") = coordinator.status().providers.single { it.providerId == id }.currentSessionError
        override fun close() = coordinator.close()
    }

    @Test fun finalFailureSurvivesCooldownExpiryWithoutInventingRequestsOrSuccess() {
        for (error in listOf(DiscoveryError.PROVIDER_FAILURE, DiscoveryError.DEADLINE_EXCEEDED,
            DiscoveryError.RATE_LIMITED, DiscoveryError.RESPONSE_TOO_LARGE, DiscoveryError.INVALID_RESULT)) Fixture().use { f ->
            f.runtime.fail(0, code = error)
            assertEquals(error, f.error())
            assertEquals(DiscoveryState.BACKOFF, f.coordinator.status().state)
            f.timer.advance(30_000)
            assertEquals(DiscoveryState.EXHAUSTED, f.coordinator.status().state)
            assertEquals(ProviderDiscoveryState.NOT_STARTED, f.coordinator.status().providers.single().state)
            assertEquals(error, f.error())
            f.timer.advance(600_000)
            assertEquals(1, f.runtime.calls.size)
            assertEquals(1, f.coordinator.status().requestsThisRound)
            assertNull(f.store.transaction { progress("profile", "p1", f.profile.queryKey) })
        }
    }

    @Test fun successfulExplicitRetryClearsOnlyItsOwnErrorAfterPublication() = Fixture(2).use { f ->
        f.runtime.fail(0)
        f.runtime.fail(1, code = DiscoveryError.DEADLINE_EXCEEDED)
        f.timer.advance(30_000)
        f.coordinator.requestMore()
        assertEquals(4, f.runtime.calls.size)
        val first = f.runtime.calls.indexOfLast { it.provider.descriptor.id == "p1" }
        val second = f.runtime.calls.indexOfLast { it.provider.descriptor.id == "p2" }
        assertEquals(DiscoveryError.PROVIDER_FAILURE, f.error("p1"))
        f.runtime.complete(first, 1)
        assertNull(f.error("p1"))
        assertEquals(DiscoveryError.DEADLINE_EXCEEDED, f.error("p2"))
        assertTrue(f.coordinator.results(f.coordinator.page(0)!!).isNotEmpty())
        f.runtime.complete(second)
        assertNull(f.error("p2"))
    }

    @Test fun successfulEmptyResponseIsNotAnError() = Fixture().use { f ->
        f.runtime.complete(0)
        f.timer.advance(30_000)
        assertEquals(DiscoveryState.EXHAUSTED, f.coordinator.status().state)
        assertEquals(ProviderDiscoveryState.EXHAUSTED, f.coordinator.status().providers.single().state)
        assertNull(f.error())
        assertNotNull(f.coordinator.status().providers.single().lastSuccessAtEpochMillis)
    }

    @Test fun newQueryAndSiblingSuccessCannotResurrectOldQueryErrorButKeepCooldown() = Fixture(2).use { f ->
        f.runtime.fail(0)
        val previousHealth = f.coordinator.status().health.getValue("p1")
        f.coordinator.start("session", f.profile.copy(query = "new query"))
        assertEquals(3, f.runtime.calls.size)
        assertEquals("p2", f.runtime.calls[2].provider.descriptor.id)
        assertNull(f.error("p1"))
        assertEquals(previousHealth, f.coordinator.status().health.getValue("p1"))
        f.runtime.complete(2)
        assertEquals(DiscoveryState.BACKOFF, f.coordinator.status().state)
        assertEquals(ProviderDiscoveryState.COOLDOWN, f.coordinator.status().providers.first { it.providerId == "p1" }.state)
        // Historical aggregate behavior is deliberately unchanged, but is not a presentation fact.
        assertEquals(DiscoveryError.PROVIDER_FAILURE, f.coordinator.status().lastError)
        assertNull(f.error("p1"))
        f.timer.advance(30_000)
        assertEquals(DiscoveryState.EXHAUSTED, f.coordinator.status().state)
        assertNull(f.error("p1"))
        assertEquals(3, f.runtime.calls.size)
    }

    @Test fun restoreAndCloseClearSessionErrorsWithoutClearingSourceHealth() = Fixture().use { f ->
        f.runtime.fail(0)
        val health = f.coordinator.status().health
        assertTrue(f.coordinator.restore("session"))
        assertNull(f.error())
        assertEquals(health, f.coordinator.status().health)
        f.coordinator.close()
        assertNull(f.error())
    }

    @Test fun olderEpochAndDuplicateCallbackCannotPolluteOrClearNewSessionError() = Fixture().use { f ->
        val old = f.runtime.calls[0]
        f.coordinator.start("session", f.profile.copy(query = "new query"))
        f.runtime.fail(1, code = DiscoveryError.DEADLINE_EXCEEDED)
        old.callback(ProviderOutcome.Failure(DiscoveryError.PROVIDER_FAILURE))
        old.callback(ProviderOutcome.Success(ValidatedProviderPage(emptyList(), null, null, true)))
        assertEquals(DiscoveryError.DEADLINE_EXCEEDED, f.error())
        assertEquals(0, f.coordinator.status().availableCount)
    }

    @Test fun sourceDescriptorChangeCannotInheritOldIdentityError() = Fixture().use { f ->
        f.runtime.fail(0)
        val original = f.providers[0].descriptor
        f.providers[0].descriptor = original.copy(version = "2")
        assertNull(f.error())
        f.providers[0].descriptor = original
        assertNull(f.error()) // Retired entry was removed, not just hidden for one snapshot.
    }

    @Test fun newerFinalReasonReplacesOlderFailureAndRetryWaitIsNotAFinalFailure() = Fixture().use { f ->
        f.runtime.fail(0)
        f.timer.advance(30_000)
        f.coordinator.requestMore()
        f.runtime.fail(1, code = DiscoveryError.RATE_LIMITED)
        assertEquals(DiscoveryError.RATE_LIMITED, f.error())
        f.timer.advance(30_000)
        f.coordinator.requestMore()
        f.runtime.fail(2, retryable = true)
        assertEquals(DiscoveryError.RATE_LIMITED, f.error())
        f.timer.advance(1000)
        f.runtime.complete(3)
        assertNull(f.error())
    }

    @Test fun candidateFailureDoesNotBecomeASourceRequestFailure() = Fixture(automatic = true).use { f ->
        val pending = PendingCandidatePolicy.normalize(CandidateUrl("https://fixture.invalid/video"), "p1", f.profile.filters)!!
        f.runtime.calls[0].callback(ProviderOutcome.Success(ValidatedProviderPage(emptyList(), null, null, true, listOf(pending))))
        assertEquals(2, f.runtime.calls.size)
        f.runtime.fail(1)
        assertNull(f.error())
        assertNull(f.coordinator.status().health.getValue("p1").lastError)
        assertEquals(1, f.coordinator.pendingCandidates().size)
    }

    @Test fun lateSuccessPastDeadlineBecomesTimeoutNotClearedFailure() = Fixture().use { f ->
        f.clock.now = 16_001
        f.runtime.complete(0, 1)
        assertEquals(DiscoveryError.DEADLINE_EXCEEDED, f.error())
        assertEquals(0, f.coordinator.status().availableCount)
    }

    @Test fun removedSourceCannotRecoverAnOldErrorWhenRegisteredAgain() = Fixture().use { f ->
        f.runtime.fail(0)
        val provider = f.registry.remove("p1")!!
        assertTrue(f.coordinator.status().providers.isEmpty())
        f.registry.register(provider)
        assertNull(f.error())
    }

    @Test fun revokedAuthorityClearsItsDisplayError() {
        val clock = FakeClock(); val timer = FakeTimer(clock); val runtime = FakeRuntime()
        val providerDescriptor = ProviderDescriptor("source", "1")
        var valid = true
        val authority = object : ProviderAuthorityView {
            override val descriptor = providerDescriptor
            override fun isCurrent(nowMillis: Long) = valid
            override fun publishIfCurrent(nowMillis: Long, operation: DiscoveryOperation?, publish: () -> Unit): Boolean {
                if (!valid) return false
                publish(); return true
            }
        }
        val source = object : VideoSearchProvider {
            override val descriptor = providerDescriptor
            override val requiresAuthority = true
            override fun search(request: SearchRequest, operation: DiscoveryOperation): ProviderPage = error("No network")
        }
        VideoDiscoveryCoordinator(ProviderRegistry(listOf(source)), runtime, InMemoryDiscoveryStore(), timer, clock).use { c ->
            c.setVisibility(true, true); c.start("session", SearchProfile("profile", "query"))
            runtime.calls[0].callback(ProviderOutcome.Success(ValidatedProviderPage(emptyList(), "next", null, false), authority))
            assertEquals(2, runtime.calls.size)
            runtime.fail(1)
            assertEquals(DiscoveryError.PROVIDER_FAILURE, c.status().providers.single().currentSessionError)
            valid = false
            assertNull(c.status().providers.single().currentSessionError)
        }
    }

}
