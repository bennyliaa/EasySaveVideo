package com.easysavevideo.app.discovery.network

import com.easysavevideo.commons.CommonsError
import com.easysavevideo.commons.CommonsFailure
import com.easysavevideo.core.model.ErrorCode
import com.easysavevideo.core.model.ErrorEnvelope
import com.easysavevideo.core.model.ErrorModule
import com.easysavevideo.core.model.ErrorSink
import com.easysavevideo.core.model.UserAction
import java.net.SocketTimeoutException
import java.util.concurrent.atomic.AtomicReference
import javax.net.ssl.SSLHandshakeException
import javax.net.ssl.SSLPeerUnverifiedException

internal enum class CommonsNetworkPhase { START, DNS, TCP, TLS, REQUEST, RESPONSE, CLEANUP }

/** Classification inspects only a closed failure code or exception type, never its contents. */
internal object CommonsTransportDiagnostics {
    fun classify(phase: CommonsNetworkPhase, problem: Throwable): ErrorCode? {
        val code = (problem as? CommonsFailure)?.code
        if (code == CommonsError.CANCELLED) return null
        if (code == CommonsError.DEADLINE_EXCEEDED) return deadline(phase)
        if (problem is SocketTimeoutException) return timeout(phase)
        if (code == CommonsError.UNSAFE_URL) return when (phase) {
            CommonsNetworkPhase.DNS -> ErrorCode.COMMONS_DNS_POLICY_REJECTED
            CommonsNetworkPhase.TCP -> ErrorCode.COMMONS_TCP_POLICY_REJECTED
            CommonsNetworkPhase.TLS -> ErrorCode.COMMONS_TLS_POLICY_REJECTED
            else -> failed(phase)
        }
        if (phase == CommonsNetworkPhase.TLS && (problem is SSLHandshakeException ||
                problem is SSLPeerUnverifiedException || code == CommonsError.INVALID_RESPONSE))
            return ErrorCode.COMMONS_TLS_REJECTED
        if (phase == CommonsNetworkPhase.RESPONSE) return when (code) {
            CommonsError.INVALID_RESPONSE -> ErrorCode.COMMONS_RESPONSE_INVALID
            CommonsError.RESPONSE_TOO_LARGE -> ErrorCode.COMMONS_RESPONSE_TOO_LARGE
            CommonsError.REDIRECT_REJECTED -> ErrorCode.COMMONS_RESPONSE_REDIRECT_REJECTED
            else -> failed(phase)
        }
        return failed(phase)
    }

    fun deadline(phase: CommonsNetworkPhase): ErrorCode = when (phase) {
        CommonsNetworkPhase.START -> ErrorCode.COMMONS_START_DEADLINE_EXCEEDED
        CommonsNetworkPhase.DNS -> ErrorCode.COMMONS_DNS_DEADLINE_EXCEEDED
        CommonsNetworkPhase.TCP -> ErrorCode.COMMONS_TCP_DEADLINE_EXCEEDED
        CommonsNetworkPhase.TLS -> ErrorCode.COMMONS_TLS_DEADLINE_EXCEEDED
        CommonsNetworkPhase.REQUEST -> ErrorCode.COMMONS_REQUEST_DEADLINE_EXCEEDED
        CommonsNetworkPhase.RESPONSE -> ErrorCode.COMMONS_RESPONSE_DEADLINE_EXCEEDED
        CommonsNetworkPhase.CLEANUP -> ErrorCode.COMMONS_CLEANUP_DEADLINE_EXCEEDED
    }

    fun timeout(phase: CommonsNetworkPhase): ErrorCode = when (phase) {
        CommonsNetworkPhase.DNS -> ErrorCode.COMMONS_DNS_TIMEOUT
        CommonsNetworkPhase.TCP -> ErrorCode.COMMONS_TCP_TIMEOUT
        CommonsNetworkPhase.TLS -> ErrorCode.COMMONS_TLS_TIMEOUT
        CommonsNetworkPhase.REQUEST -> ErrorCode.COMMONS_REQUEST_TIMEOUT
        CommonsNetworkPhase.RESPONSE -> ErrorCode.COMMONS_RESPONSE_TIMEOUT
        else -> failed(phase)
    }

    private fun failed(phase: CommonsNetworkPhase): ErrorCode = when (phase) {
        CommonsNetworkPhase.START -> ErrorCode.COMMONS_START_FAILED
        CommonsNetworkPhase.DNS -> ErrorCode.COMMONS_DNS_FAILED
        CommonsNetworkPhase.TCP -> ErrorCode.COMMONS_TCP_FAILED
        CommonsNetworkPhase.TLS -> ErrorCode.COMMONS_TLS_FAILED
        CommonsNetworkPhase.REQUEST -> ErrorCode.COMMONS_REQUEST_FAILED
        CommonsNetworkPhase.RESPONSE -> ErrorCode.COMMONS_RESPONSE_FAILED
        CommonsNetworkPhase.CLEANUP -> ErrorCode.COMMONS_CLEANUP_FAILED
    }

    fun report(errors: ErrorSink, code: ErrorCode?) {
        if (code == null) return
        // Diagnostics cannot replace the transport outcome or prevent resource cleanup.
        runCatching { errors.report(ErrorEnvelope(code, ErrorModule.PLATFORM, false, UserAction.NONE)) }
    }
}

/** A singleton transport forwards to one live controller sink without accumulating listeners. */
internal class CommonsTransportErrorSink : ErrorSink {
    private class Binding(val errors: ErrorSink)
    private val current = AtomicReference<Binding?>()

    fun attach(errors: ErrorSink): AutoCloseable {
        val binding = Binding(errors)
        current.set(binding)
        // An old controller closing must not detach a more recently attached controller.
        return AutoCloseable { current.compareAndSet(binding, null) }
    }

    override fun report(error: ErrorEnvelope) { current.get()?.errors?.report(error) }
}
