package com.easysavevideo.app.discovery.network

import com.easysavevideo.commons.CommonsError
import com.easysavevideo.commons.CommonsFailure
import com.easysavevideo.core.model.ErrorCode
import com.easysavevideo.core.model.ErrorEnvelope
import com.easysavevideo.core.model.ErrorModule
import com.easysavevideo.core.model.ErrorSink
import com.easysavevideo.core.model.SafeContext
import com.easysavevideo.core.model.UserAction
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLHandshakeException
import javax.net.ssl.SSLPeerUnverifiedException

class CommonsTransportDiagnosticsTest {
    @Test fun classifiesOnlyClosedPhaseAndReasonPairs() {
        assertCode(ErrorCode.COMMONS_DNS_FAILED, CommonsNetworkPhase.DNS, UnknownHostException(BAIT))
        assertCode(ErrorCode.COMMONS_TCP_FAILED, CommonsNetworkPhase.TCP, ConnectException(BAIT))
        assertCode(ErrorCode.COMMONS_TLS_REJECTED, CommonsNetworkPhase.TLS, SSLHandshakeException(BAIT))
        assertCode(ErrorCode.COMMONS_TLS_REJECTED, CommonsNetworkPhase.TLS, SSLPeerUnverifiedException(BAIT))
        assertCode(ErrorCode.COMMONS_TLS_FAILED, CommonsNetworkPhase.TLS, IOException(BAIT))
        assertCode(ErrorCode.COMMONS_REQUEST_FAILED, CommonsNetworkPhase.REQUEST, IOException(BAIT))
        assertCode(ErrorCode.COMMONS_RESPONSE_FAILED, CommonsNetworkPhase.RESPONSE, IOException(BAIT))
        assertCode(ErrorCode.COMMONS_RESPONSE_INVALID, CommonsNetworkPhase.RESPONSE, CommonsFailure(CommonsError.INVALID_RESPONSE))
        assertCode(ErrorCode.COMMONS_RESPONSE_TOO_LARGE, CommonsNetworkPhase.RESPONSE, CommonsFailure(CommonsError.RESPONSE_TOO_LARGE))
        assertCode(ErrorCode.COMMONS_RESPONSE_REDIRECT_REJECTED, CommonsNetworkPhase.RESPONSE, CommonsFailure(CommonsError.REDIRECT_REJECTED))
        assertCode(ErrorCode.COMMONS_DNS_POLICY_REJECTED, CommonsNetworkPhase.DNS, CommonsFailure(CommonsError.UNSAFE_URL))
        assertCode(ErrorCode.COMMONS_TCP_POLICY_REJECTED, CommonsNetworkPhase.TCP, CommonsFailure(CommonsError.UNSAFE_URL))
        assertCode(ErrorCode.COMMONS_TLS_POLICY_REJECTED, CommonsNetworkPhase.TLS, CommonsFailure(CommonsError.UNSAFE_URL))
    }

    @Test fun socketTimeoutAndAbsoluteDeadlineRemainDistinctInEveryNetworkPhase() {
        for (phase in listOf(CommonsNetworkPhase.DNS, CommonsNetworkPhase.TCP, CommonsNetworkPhase.TLS,
            CommonsNetworkPhase.REQUEST, CommonsNetworkPhase.RESPONSE)) {
            assertEquals("COMMONS_${phase.name}_TIMEOUT", CommonsTransportDiagnostics.classify(phase, SocketTimeoutException(BAIT))?.name)
        }
        for (phase in CommonsNetworkPhase.entries) {
            assertEquals("COMMONS_${phase.name}_DEADLINE_EXCEEDED",
                CommonsTransportDiagnostics.classify(phase, CommonsFailure(CommonsError.DEADLINE_EXCEEDED))?.name)
            assertNull(CommonsTransportDiagnostics.classify(phase, CommonsFailure(CommonsError.CANCELLED)))
        }
    }

    @Test fun neverInspectsExceptionTextCauseOrStackAndEmitsNoRequestMetadata() {
        val hostile = object : IOException() {
            override val message: String get() = throw AssertionError("Message must never be inspected")
            override val cause: Throwable? get() = throw AssertionError("Cause must never be inspected")
            override fun getLocalizedMessage(): String = throw AssertionError("Localized text must never be inspected")
            override fun getStackTrace(): Array<StackTraceElement> = throw AssertionError("Stack must never be inspected")
            override fun toString(): String = throw AssertionError("Exception must never be formatted")
        }
        val code = CommonsTransportDiagnostics.classify(CommonsNetworkPhase.RESPONSE, hostile)
        val records = mutableListOf<ErrorEnvelope>()
        CommonsTransportDiagnostics.report(ErrorSink { records += it }, code)
        assertEquals(listOf(ErrorEnvelope(ErrorCode.COMMONS_RESPONSE_FAILED, ErrorModule.PLATFORM,
            false, UserAction.NONE, SafeContext())), records)
        assertFalse(records.toString().contains(BAIT))
        assertTrue(records.single().javaClass.declaredFields.none { it.type == String::class.java || Throwable::class.java.isAssignableFrom(it.type) })
    }

    @Test fun reporterSwallowsSinkFailuresWithoutFallbackOrRetry() {
        var calls = 0
        CommonsTransportDiagnostics.report(ErrorSink { calls++; throw IllegalStateException(BAIT) }, ErrorCode.COMMONS_DNS_FAILED)
        CommonsTransportDiagnostics.report(ErrorSink { calls++; throw AssertionError(BAIT) }, ErrorCode.COMMONS_TCP_FAILED)
        CommonsTransportDiagnostics.report(ErrorSink { calls++ }, null)
        assertEquals(2, calls)
    }

    @Test fun singletonForwarderRetainsOnlyLatestBindingAndOldCloseCannotDetachIt() {
        val forwarder = CommonsTransportErrorSink()
        val first = mutableListOf<ErrorEnvelope>(); val second = mutableListOf<ErrorEnvelope>()
        val record = ErrorEnvelope(ErrorCode.COMMONS_DNS_FAILED, ErrorModule.PLATFORM, false, UserAction.NONE)
        forwarder.report(record)
        val old = forwarder.attach(ErrorSink { first += it })
        forwarder.report(record)
        val current = forwarder.attach(ErrorSink { second += it })
        old.close(); old.close()
        forwarder.report(record)
        current.close(); current.close()
        forwarder.report(record)
        assertEquals(listOf(record), first)
        assertEquals(listOf(record), second)
    }

    @Test fun reattachingSameSinkStillHasIndependentLifecycleIdentity() {
        val forwarder = CommonsTransportErrorSink()
        var calls = 0
        val sink = ErrorSink { calls++ }
        val old = forwarder.attach(sink)
        val current = forwarder.attach(sink)
        old.close()
        CommonsTransportDiagnostics.report(forwarder, ErrorCode.COMMONS_DNS_FAILED)
        current.close()
        CommonsTransportDiagnostics.report(forwarder, ErrorCode.COMMONS_DNS_FAILED)
        assertEquals(1, calls)
    }

    private fun assertCode(expected: ErrorCode, phase: CommonsNetworkPhase, problem: Throwable) {
        assertEquals(expected, CommonsTransportDiagnostics.classify(phase, problem))
    }
    companion object {
        private const val BAIT = "https://private.example/secret?q=private-title 192.0.2.9 cookie=secret certificate=/private/file"
    }
}
