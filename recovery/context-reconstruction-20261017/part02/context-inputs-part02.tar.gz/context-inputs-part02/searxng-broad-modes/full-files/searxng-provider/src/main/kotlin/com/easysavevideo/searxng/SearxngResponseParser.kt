package com.easysavevideo.searxng

import com.easysavevideo.discovery.CandidateUrl
import com.easysavevideo.discovery.ProviderCategoryStatus
import com.easysavevideo.discovery.SourceReportedCandidateMetadata
import java.net.URI

/** The category is an engine hint, not video evidence. Every returned item stays unverified. */
internal object SearxngResponseParser {
    data class ParsedPage(val candidates: List<CandidateUrl>, val rawResponseItemCount: Int,
        val categoryStatus: ProviderCategoryStatus = ProviderCategoryStatus.UNREPORTED)
    fun parse(bytes: ByteArray, maxCandidates: Int, check: () -> Unit): List<CandidateUrl> =
        parseWithCounts(bytes, maxCandidates, check).candidates
    fun parseWithCounts(bytes: ByteArray, maxCandidates: Int, check: () -> Unit,
        requestedCategory: SearxngCategory? = null): ParsedPage {
        val root = StrictJson.read(bytes, check).objectValue()
        val rows = (root["results"] as? Json.Arr)?.values ?: invalidResponse()
        if (rows.size > maxCandidates) throw SearxngFailure(SearxngError.TOO_MANY_CANDIDATES)
        val errorReported = errorReport(root["error"])
        val errorsReported = errorReport(root["errors"])
        val unresponsive = when (val value = root["unresponsive_engines"]) {
            null, Json.Nil -> false
            is Json.Arr -> value.values.isNotEmpty()
            else -> invalidResponse()
        }
        // Error text and engine names never leave this parser. Empty results with explicit failure
        // metadata are not successful exhaustion. Scope is unknown: do not hop to another category.
        if (rows.isEmpty() && (errorReported || errorsReported || unresponsive)) throw SearxngFailure(SearxngError.SERVICE_ERROR)
        // This is only an observed contract report. Empty rows or absent category metadata cannot
        // establish category support, and a silent server fallback must not become a support claim.
        var categoryStatus = if (rows.isEmpty() || requestedCategory == null) ProviderCategoryStatus.UNREPORTED
            else ProviderCategoryStatus.REPORTED_MATCH
        val found = linkedMapOf<String, CandidateUrl>()
        for (row in rows) {
            check()
            val fields = row.objectValue()
            if (requestedCategory != null) {
                val reported = fields["category"]?.let { if (it == Json.Nil) null else it.stringOrNull() ?: invalidResponse() }
                if (reported != null && reported != requestedCategory.parameter)
                    categoryStatus = ProviderCategoryStatus.CATEGORY_MISMATCH
                else if (reported == null && categoryStatus != ProviderCategoryStatus.CATEGORY_MISMATCH)
                    categoryStatus = ProviderCategoryStatus.UNREPORTED
            }
            val rawUrl = fields["url"]?.stringOrNull() ?: continue
            val url = SearxngUrlPolicy.candidate(rawUrl) ?: continue
            val title = text(fields["title"], 512, check)
            val description = text(fields["content"], 2048, check)
            found.putIfAbsent(url, CandidateUrl(url, sourceReported = SourceReportedCandidateMetadata(
                title = title, sourceName = URI(url).host, description = description)))
        }
        check()
        return ParsedPage(if (categoryStatus == ProviderCategoryStatus.CATEGORY_MISMATCH) emptyList()
            else found.values.toList(), rows.size, categoryStatus)
    }

    /** Recognize bounded presence only; never expose or log supplied upstream error text. */
    private fun errorReport(value: Json?): Boolean = when (value) {
        null, Json.Nil -> false
        is Json.Str -> value.value.isNotBlank()
        is Json.Arr -> value.values.isNotEmpty()
        is Json.Obj -> value.fields.isNotEmpty()
        else -> invalidResponse()
    }

    /** Plain text only. Drop markup and controls; never render/fetch supplied HTML or images. */
    private fun text(value: Json?, maximum: Int, check: () -> Unit): String? {
        val input = when (value) {
            null, Json.Nil -> return null
            is Json.Str -> value.value
            else -> invalidResponse()
        }
        val out = StringBuilder()
        var tag = false
        var whitespace = false
        for ((index, char) in input.withIndex()) {
            if (index % 256 == 0) check()
            when {
                char == '<' -> { tag = true; whitespace = true }
                char == '>' && tag -> tag = false
                tag -> Unit
                char.isWhitespace() || char.isISOControl() -> whitespace = true
                else -> {
                    if (whitespace && out.isNotEmpty()) out.append(' ')
                    whitespace = false
                    out.append(char)
                }
            }
            if (out.length >= maximum) break
        }
        return out.toString().take(maximum).dropLastWhile { it.isHighSurrogate() }.trim().takeIf { it.isNotEmpty() }
    }
}
