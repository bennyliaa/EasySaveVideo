package com.easysavevideo.searxng

import com.easysavevideo.discovery.*
import java.net.URI
import java.net.URLDecoder
import java.util.Base64
import org.junit.Assert.*
import org.junit.Test

class SearxngSearchModesTest {
    private fun provider(transport: SearxngTransport, mode: SearxngSearchMode, pages: Int = 20) =
        SearxngVideoSearchProvider(endpoint(), transport, SearxngLimits(maxPages = pages), TestClock(), TestTimer(), mode)
    private fun body(category: String? = null, url: String = "https://videos.example.org/watch/one") =
        """{"results":[{"url":"$url","title":"A film"${category?.let { ",\"category\":\"$it\"" }.orEmpty()}}]}"""
    private fun params(uri: URI) = uri.rawQuery.split('&').associate {
        val parts = it.split('=', limit = 2)
        URLDecoder.decode(parts[0], "UTF-8") to URLDecoder.decode(parts[1], "UTF-8")
    }
    @Test fun oldConstructorStillRequestsOnlyVideosAndUsesOriginalDescriptorAndCursor() {
        val transport = TestTransport(Reply())
        val old = com.easysavevideo.searxng.provider(transport)
        val page = old.search(request(), operation())
        assertEquals(endpoint().version, old.descriptor.version)
        assertEquals(1, old.descriptor.cursorSchemaVersion)
        assertEquals("videos", params(transport.requests.single().url)["categories"])
        val key = SearxngCursor.key(endpoint(), "short film", "en", request().profile.queryKey, SearxngLimits())
        assertEquals(2, SearxngCursor.decode(page.nextCursor!!, key, 1000, 20) {})
    }
    @Test fun webRequestsGeneralAndRemainsUnverifiedRegardlessOfReportedCategory() {
        val transport = TestTransport(Reply(body("general")))
        val source = provider(transport, SearxngSearchMode.WEB)
        val page = source.search(request(), operation())
        assertEquals("general", params(transport.requests.single().url)["categories"])
        assertEquals(ProviderCategoryObservation(ProviderSearchCategory.WEB, ProviderCategoryStatus.REPORTED_MATCH), page.categoryObservation)
        assertEquals(CandidateMetadataLevel.SOURCE_REPORTED, page.candidates.single().sourceReported!!.metadataLevel)
        assertTrue(page.results.isEmpty())
        assertEquals("searxng-1", source.descriptor.id)
        assertEquals(2, source.descriptor.cursorSchemaVersion)
    }
    @Test fun bothAlternatesOneRequestPerAttemptAndIndependentPagesSurviveProviderRecreation() {
        val expected = listOf("general" to "1", "videos" to "1", "general" to "2", "videos" to "2")
        var cursor: String? = null
        for ((category, pageNumber) in expected) {
            val transport = TestTransport(Reply(body(category)))
            val page = provider(transport, SearxngSearchMode.BOTH, pages = 2).search(request(cursor = cursor), operation())
            assertEquals(1, transport.requests.size)
            assertEquals(category, params(transport.requests.single().url)["categories"])
            assertEquals(pageNumber, params(transport.requests.single().url)["pageno"])
            assertEquals(1, page.rawResponseItemCount)
            cursor = page.nextCursor
            if (category == "videos" && pageNumber == "2") assertTrue(page.exhausted)
            else { assertFalse(page.exhausted); assertNotNull(cursor) }
        }
        assertNull(cursor)
    }
    @Test fun anEmptyCategoryExhaustsOnlyItsOwnLaneAndDoesNotClaimSupport() {
        val first = provider(TestTransport(Reply("""{"results":[]}""")), SearxngSearchMode.BOTH)
            .search(request(), operation())
        assertFalse(first.exhausted)
        assertEquals(ProviderCategoryStatus.UNREPORTED, first.categoryObservation!!.status)
        val secondTransport = TestTransport(Reply(body("videos")))
        val second = provider(secondTransport, SearxngSearchMode.BOTH).search(request(cursor = first.nextCursor), operation())
        assertEquals("videos", params(secondTransport.requests.single().url)["categories"])
        val thirdTransport = TestTransport(Reply("""{"results":[]}"""))
        val third = provider(thirdTransport, SearxngSearchMode.BOTH).search(request(cursor = second.nextCursor), operation())
        assertEquals("videos", params(thirdTransport.requests.single().url)["categories"])
        assertEquals("2", params(thirdTransport.requests.single().url)["pageno"])
        assertTrue(third.exhausted)
    }
    @Test fun explicitCategoryMismatchIsTypedAndNeverBecomesCandidateOrEmptySuccess() {
        val firstTransport = TestTransport(Reply(body("videos")))
        val first = provider(firstTransport, SearxngSearchMode.BOTH).search(request(), operation())
        assertEquals(1, firstTransport.requests.size)
        assertEquals(ProviderCategoryObservation(ProviderSearchCategory.WEB, ProviderCategoryStatus.CATEGORY_MISMATCH), first.categoryObservation)
        assertEquals(1, first.rawResponseItemCount)
        assertTrue(first.candidates.isEmpty()); assertTrue(first.results.isEmpty()); assertFalse(first.exhausted)
        val nextTransport = TestTransport(Reply(body("videos")))
        val next = provider(nextTransport, SearxngSearchMode.BOTH).search(request(cursor = first.nextCursor), operation())
        assertEquals("videos", params(nextTransport.requests.single().url)["categories"])
        assertEquals(1, next.candidates.size)
        val single = provider(TestTransport(Reply(body("general"))), SearxngSearchMode.VIDEOS).search(request(), operation())
        assertTrue(single.exhausted); assertNull(single.nextCursor)
        assertEquals(ProviderCategoryStatus.CATEGORY_MISMATCH, single.categoryObservation!!.status)
    }
    @Test fun absentCategoryAndSilentFallbackAreNotPromotedToVerifiedCategorySupport() {
        val page = provider(TestTransport(Reply(body())), SearxngSearchMode.WEB).search(request(), operation())
        assertEquals(ProviderCategoryStatus.UNREPORTED, page.categoryObservation!!.status)
        assertEquals(CandidateMetadataLevel.SOURCE_REPORTED, page.candidates.single().sourceReported!!.metadataLevel)
        assertTrue(page.results.isEmpty())
    }
    @Test fun filteredRowsDoNotPretendTheCategoryHasEnded() {
        val page = provider(TestTransport(Reply(body("general", "https://127.0.0.1/private"))), SearxngSearchMode.WEB)
            .search(request(), operation())
        assertEquals(1, page.rawResponseItemCount); assertTrue(page.candidates.isEmpty())
        assertFalse(page.exhausted); assertNotNull(page.nextCursor)
    }
    @Test fun modesBindCursorAndNeverReuseOneCategoryAsAnIndependentProvider() {
        val tokens = SearxngSearchMode.entries.associateWith { mode ->
            provider(TestTransport(Reply(body())), mode).search(request(), operation()).nextCursor!!
        }
        for ((oldMode, token) in tokens) for (newMode in SearxngSearchMode.entries.filter { it != oldMode }) {
            val transport = TestTransport()
            fails(DiscoveryError.PROVIDER_FAILURE) { provider(transport, newMode).search(request(cursor = token), operation()) }
            assertTrue(transport.requests.isEmpty())
        }
        val descriptors = SearxngSearchMode.entries.map { provider(TestTransport(), it).descriptor }
        assertEquals(setOf("searxng-1"), descriptors.map { it.id }.toSet())
        assertEquals(3, descriptors.map { it.version }.toSet().size)
    }
    @Test fun bothCursorIsSmallStrictAndContainsOnlyLocalCountersAndBindingHash() {
        val mode = SearxngSearchMode.BOTH; val limits = SearxngLimits()
        val key = SearxngCursor.key(endpoint(), "private query", "en", "profile", limits, mode)
        val state = SearxngCursor.initial(mode).advance(false, 20)
        val token = SearxngCursor.encodeCategories(state, key, 301_000)
        assertTrue(token.length <= 1024)
        val decoded = String(Base64.getUrlDecoder().decode(token), Charsets.UTF_8)
        assertFalse(decoded.contains("private")); assertFalse(decoded.contains("https")); assertFalse(decoded.contains("example.org"))
        assertEquals(state, SearxngCursor.decodeCategories(token, key, 1000, 20, mode) {})
        for (bad in listOf(state.copy(webPage = 21), state.copy(videoPage = 0),
            state.copy(videoDone = true), state.copy(webDone = true, videoDone = true)))
            protocolFails(SearxngError.INVALID_CURSOR) {
                SearxngCursor.decodeCategories(SearxngCursor.encodeCategories(bad, key, 301_000), key, 1000, 20, mode) {}
            }
        protocolFails(SearxngError.INVALID_CURSOR) { SearxngCursor.decodeCategories(token, key, 301_000, 20, mode) {} }
        protocolFails(SearxngError.INVALID_CURSOR) { SearxngCursor.decodeCategories(token, "other", 1000, 20, mode) {} }
    }
    @Test fun everyModeRetainsSafeSearchPreflightAndGlobalDenialsNeverHopCategory() {
        for (mode in SearxngSearchMode.entries) {
            val noRequests = TestTransport()
            fails(DiscoveryError.UNSUPPORTED_FILTER) { provider(noRequests, mode).search(request(safe = true), operation()) }
            assertTrue(noRequests.requests.isEmpty())
            for (status in listOf(401, 403, 429, 503)) {
                val transport = TestTransport(Reply(status = status))
                fails(if (status == 429 || status == 503) DiscoveryError.RATE_LIMITED else DiscoveryError.PROVIDER_FAILURE) {
                    provider(transport, mode).search(request(), operation())
                }
                assertEquals(1, transport.requests.size)
            }
            val challenge = TestTransport(Reply("<html>Challenge</html>", headers = mapOf("Content-Type" to listOf("text/html"))))
            fails(DiscoveryError.PROVIDER_FAILURE) { provider(challenge, mode).search(request(), operation()) }
            assertEquals(1, challenge.requests.size)
        }
    }
    @Test fun categoryDuplicatesNormalizeToOnePageWithOneProviderProvenance() {
        val pages = listOf("general", "videos").map { category ->
            val mode = if (category == "general") SearxngSearchMode.WEB else SearxngSearchMode.VIDEOS
            provider(TestTransport(Reply(body(category))), mode).search(request(), operation())
        }
        val filters = SearchFilters(safeSearch = false)
        val pending = pages.map { page -> PendingCandidatePolicy.normalize(page.candidates.single(), "searxng-1", filters)!! }
        assertEquals(1, pending.map { it.candidateId }.toSet().size)
        assertEquals(setOf("searxng-1"), pending.flatMap { it.provenance }.toSet())
        assertTrue(pending.all { it.sourceReported!!.metadataLevel == CandidateMetadataLevel.SOURCE_REPORTED })
    }
    @Test fun emptyRowsWithExplicitErrorsAreWholeProviderFailuresWithoutCategoryHopping() {
        val reports = listOf("\"error\":\"Unavailable\"", "\"errors\":[\"Unavailable\"]",
            "\"errors\":{\"upstream\":\"Unavailable\"}", "\"unresponsive_engines\":[[\"engine\",\"Timeout\"]]")
        for (report in reports) {
            val body = "{\"results\":[],$report}"
            protocolFails(SearxngError.SERVICE_ERROR) { SearxngResponseParser.parse(body.toByteArray(), 100) {} }
            val transport = TestTransport(Reply(body))
            fails(DiscoveryError.PROVIDER_FAILURE) { provider(transport, SearxngSearchMode.BOTH).search(request(), operation()) }
            assertEquals(1, transport.requests.size)
        }
    }
    @Test fun malformedErrorMetadataFailsClosedRatherThanBecomingEmptySuccess() {
        for (field in listOf("\"error\":true", "\"errors\":42", "\"unresponsive_engines\":\"timeout\"")) {
            val transport = TestTransport(Reply("{\"results\":[],$field}"))
            fails(DiscoveryError.PROVIDER_FAILURE) { provider(transport, SearxngSearchMode.BOTH).search(request(), operation()) }
            assertEquals(1, transport.requests.size)
        }
    }
    @Test fun genuinelyEmptyErrorReportsRemainUnknownAndPartialResultsRemainUnverified() {
        val empty = provider(TestTransport(Reply("""{"results":[],"error":" ","errors":[],"unresponsive_engines":[]}""")),
            SearxngSearchMode.WEB).search(request(), operation())
        assertTrue(empty.exhausted); assertEquals(ProviderCategoryStatus.UNREPORTED, empty.categoryObservation!!.status)
        val partial = body("general").dropLast(1) + ",\"unresponsive_engines\":[[\"engine\",\"timeout\"]]}"
        val page = provider(TestTransport(Reply(partial)), SearxngSearchMode.WEB).search(request(), operation())
        assertEquals(1, page.candidates.size); assertEquals(1, page.rawResponseItemCount)
        assertEquals(CandidateMetadataLevel.SOURCE_REPORTED, page.candidates.single().sourceReported!!.metadataLevel)
        assertTrue(page.results.isEmpty())
    }

}
