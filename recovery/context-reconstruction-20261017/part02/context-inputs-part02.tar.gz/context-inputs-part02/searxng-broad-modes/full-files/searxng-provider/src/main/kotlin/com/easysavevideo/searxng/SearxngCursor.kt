package com.easysavevideo.searxng

import java.util.Base64

/** Local progress only; never follows server-provided continuation URLs or trusts total counts. */
internal object SearxngCursor {
    const val TTL_MILLIS = 5 * 60_000L
    fun key(endpoint: SearxngEndpoint, query: String, language: String, profileKey: String,
        limits: SearxngLimits, mode: SearxngSearchMode = SearxngSearchMode.VIDEOS): String {
        // Legacy VIDEOS keys already imply that category; preserve their exact bytes.
        val parts = listOf(endpoint.id, endpoint.version, query, language, profileKey, "safesearch=0",
            limits.maxPages.toString(), limits.maxCandidates.toString()) +
            if (mode == SearxngSearchMode.VIDEOS) emptyList() else listOf("mode=${mode.name}")
        return sha256(parts.joinToString("") { "${it.length}:$it" })
    }

    fun encode(page: Int, key: String, expires: Long): String = Base64.getUrlEncoder().withoutPadding()
        .encodeToString(StrictJson.write(Json.Obj(linkedMapOf("v" to Json.Num("1"), "q" to Json.Str(key),
            "page" to Json.Num(page.toString()), "expires" to Json.Num(expires.toString())))).toByteArray(Charsets.UTF_8))

    fun decode(token: String, key: String, now: Long, maxPages: Int, check: () -> Unit): Int {
        check()
        try {
            if (token.length !in 1..1024 || !token.matches(Regex("[A-Za-z0-9_-]+"))) fail()
            val value = StrictJson.read(Base64.getUrlDecoder().decode(token), check).objectValue()
            val page = value["page"]?.longOrNull() ?: fail()
            val expires = value["expires"]?.longOrNull() ?: fail()
            if (value.keys != setOf("v", "q", "page", "expires") || value["v"]?.longOrNull() != 1L ||
                value["q"]?.stringOrNull() != key || page !in 2..maxPages.toLong() ||
                expires <= now || expires > plus(now, TTL_MILLIS)) fail()
            check()
            return page.toInt()
        } catch (failure: SearxngFailure) {
            if (failure.code == SearxngError.CANCELLED || failure.code == SearxngError.DEADLINE_EXCEEDED) throw failure
            fail()
        } catch (_: IllegalArgumentException) { fail() }
    }
    /** Exactly two bounded category counters. A token contains no query, URL, result, or engine name. */
    data class CategoryProgress(val webPage: Int, val videoPage: Int, val webDone: Boolean,
        val videoDone: Boolean, val next: SearxngCategory) {
        val exhausted: Boolean get() = webDone && videoDone
        val page: Int get() = if (next == SearxngCategory.WEB) webPage else videoPage
        fun advance(categoryExhausted: Boolean, maxPages: Int): CategoryProgress {
            val done = categoryExhausted || page >= maxPages
            val state = if (next == SearxngCategory.WEB) copy(webPage = if (done) webPage else webPage + 1, webDone = done)
                else copy(videoPage = if (done) videoPage else videoPage + 1, videoDone = done)
            return state.copy(next = when {
                next == SearxngCategory.WEB && !state.videoDone -> SearxngCategory.VIDEOS
                next == SearxngCategory.VIDEOS && !state.webDone -> SearxngCategory.WEB
                else -> next
            })
        }
    }
    fun initial(mode: SearxngSearchMode) = CategoryProgress(1, 1, mode == SearxngSearchMode.VIDEOS,
        mode == SearxngSearchMode.WEB, if (mode == SearxngSearchMode.VIDEOS) SearxngCategory.VIDEOS else SearxngCategory.WEB)

    fun encodeCategories(progress: CategoryProgress, key: String, expires: Long): String =
        Base64.getUrlEncoder().withoutPadding().encodeToString(StrictJson.write(Json.Obj(linkedMapOf(
            "v" to Json.Num("2"), "q" to Json.Str(key), "w" to Json.Num(progress.webPage.toString()),
            "p" to Json.Num(progress.videoPage.toString()), "wd" to Json.Bool(progress.webDone),
            "vd" to Json.Bool(progress.videoDone), "next" to Json.Str(progress.next.name),
            "expires" to Json.Num(expires.toString())))).toByteArray(Charsets.UTF_8))

    fun decodeCategories(token: String, key: String, now: Long, maxPages: Int, mode: SearxngSearchMode,
        check: () -> Unit): CategoryProgress {
        check()
        try {
            if (token.length !in 1..1024 || !token.matches(Regex("[A-Za-z0-9_-]+"))) fail()
            val value = StrictJson.read(Base64.getUrlDecoder().decode(token), check).objectValue()
            val web = value["w"]?.longOrNull() ?: fail()
            val video = value["p"]?.longOrNull() ?: fail()
            val expires = value["expires"]?.longOrNull() ?: fail()
            val webDone = (value["wd"] as? Json.Bool)?.value ?: fail()
            val videoDone = (value["vd"] as? Json.Bool)?.value ?: fail()
            val next = when (value["next"]?.stringOrNull()) {
                "WEB" -> SearxngCategory.WEB; "VIDEOS" -> SearxngCategory.VIDEOS; else -> fail()
            }
            if (value.keys != setOf("v", "q", "w", "p", "wd", "vd", "next", "expires") ||
                value["v"]?.longOrNull() != 2L || value["q"]?.stringOrNull() != key ||
                web !in 1..maxPages.toLong() || video !in 1..maxPages.toLong() ||
                expires <= now || expires > plus(now, TTL_MILLIS) || webDone && videoDone ||
                next == SearxngCategory.WEB && webDone || next == SearxngCategory.VIDEOS && videoDone ||
                mode == SearxngSearchMode.BOTH && web == 1L && video == 1L && !webDone && !videoDone ||
                mode == SearxngSearchMode.WEB && (!videoDone || video != 1L || web == 1L) ||
                mode == SearxngSearchMode.VIDEOS && (!webDone || web != 1L)) fail()
            check()
            return CategoryProgress(web.toInt(), video.toInt(), webDone, videoDone, next)
        } catch (failure: SearxngFailure) {
            if (failure.code == SearxngError.CANCELLED || failure.code == SearxngError.DEADLINE_EXCEEDED) throw failure
            fail()
        } catch (_: IllegalArgumentException) { fail() }
    }
    private fun fail(): Nothing = throw SearxngFailure(SearxngError.INVALID_CURSOR)
}
