# Explicit SearXNG search modes (2026-10-17)

This increment adds user-selected WEB, VIDEOS and BOTH search modes to each existing SearXNG source slot. It does not add endpoints, dependencies, credentials, automatic configuration, automatic searches, or video-verification authority.

## Request and progress contract

- WEB sends `categories=general`; VIDEOS sends `categories=videos`.
- BOTH begins with WEB and alternates one category per provider attempt. There is exactly one HTTP exchange per attempt, with no hidden fan-out or internal retry. All attempts consume the existing shared discovery coordinator request budget.
- Both categories retain the same source ID and the same process-retained slot transport/service admission. They are not separate providers or evidence of independent upstream engines.
- Page and exhaustion state are independent per category. A category's empty raw result array ends only that category. Filtered rows do not masquerade as an empty source array. The configured maximum page limit applies separately to each category; the default is 20 per category, and the coordinator still limits each request round.
- WEB/BOTH use a strict bounded cursor with two counters, two terminal flags, the next category, an expiry and a binding hash. It contains no query, page URL, result list or server continuation URL. Mode, query, locale, profile, endpoint version and limits participate in cursor binding. Cursor lifetime remains five minutes, with at most 1,024 encoded characters.
- Existing constructors and stored version-1 configurations default to VIDEOS. Default-only configuration encodings remain byte-identical to version 1, preserving their generation hashes. A nondefault mode uses strict version 2 encoding. Reads never migrate or rewrite the source file; unknown modes/versions fail closed.
- A saved mode change retires the source generation and old editor claims. The UI requires renewed endpoint/upstream disclosure acknowledgement for a mode change. Saving, disabling, resetting or changing modes never dispatches a query.

## Evidence and error boundaries

Every candidate remains SOURCE_REPORTED, with URL normalization/deduplication and the existing single-provider provenance. A WEB or VIDEOS category label never confirms a video, license, media URL, playback or Save capability.

The category observation has three finite statuses:

- REPORTED_MATCH: all returned result rows explicitly report the requested category. This is a source contract report only.
- UNREPORTED: the array is empty or category metadata is absent on a row. It does not establish support or prove that a server did not silently fall back.
- CATEGORY_MISMATCH: at least one row explicitly reports another category. The response is retained as a typed contract failure with its actual raw-row count; no candidates from it are accepted. Only that category is retired, and BOTH can continue the other category through a later budgeted attempt. It does not establish that the server's category is definitively unsupported.

An otherwise empty result array accompanied by a nonempty top-level `error`, `errors` or `unresponsive_engines` report is a whole-provider SERVICE_ERROR, not empty success. Malformed error-container types fail closed. The parser retains valid nonempty partial results as SOURCE_REPORTED but this increment does not export partial upstream error counts or engine details; those omissions must not be mistaken for a clean upstream-engine run.

Malformed JSON, invalid response framing, non-JSON/bot challenge responses, service denial, redirects, TLS/URL rejection, 429/503 cooldown, cancellation and deadlines remain whole-provider failures. No category switch is used to work around them. The original shared service admission remains unchanged.

SafeSearch capability remains UNKNOWN. Every mode refuses a request with SafeSearch enabled before I/O. No mode changes the requested filter to false, claims SafeSearch support or fetches candidate/media links.

No successful live search JSON was established by the companion endpoint observations. A point-in-time instance configuration cannot establish general support or engine coverage for all SearXNG instances. No unsupported-category JSON field is invented or trusted.

## Verification ownership

Added JVM tests cover legacy VIDEOS compatibility, WEB parameters, BOTH interleaving, independent exhaustion and page bounds, provider recreation, category mismatch, absent reports, strict bounded mode-bound cursors, raw counts, no-request SafeSearch refusals, global denial/no category hopping, and normalized URL/single-provider provenance. Added application tests cover v1/v2 persistence, unknown-mode rejection, configuration generations, editor claim fencing, one-provider registration and preserved duplicate-host fail-closed behavior.

The implementation worker did not run Gradle, network probes, APK assembly, device actions or uploads. The build owner serializes final compilation, focused tests and regression execution. This document is a source/design handoff, not a test-pass or live-service-acceptance claim.
