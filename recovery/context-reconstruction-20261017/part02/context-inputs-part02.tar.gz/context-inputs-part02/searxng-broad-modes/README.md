# SearXNG modes preservation bundle

Status for every item: **context-reconstructed/unverified**.

This directory preserves only material visible in this worker's current conversation: its previously executed patch inputs, complete new-file content, and complete source text printed by earlier tools. It is not a checkout, an applied patch, a verified prior release, or a reconstruction of missing baseline files.

## Preserved material

- `full-files/searxng-provider/src/main/kotlin/com/easysavevideo/searxng/SearxngCursor.kt`: complete last visible cursor source.
- `full-files/searxng-provider/src/main/kotlin/com/easysavevideo/searxng/SearxngResponseParser.kt`: complete last visible parser source, including the final non-short-circuit error-container validation change.
- `full-files/searxng-provider/src/test/kotlin/com/easysavevideo/searxng/SearxngSearchModesTest.kt`: complete new test file reconstructed from its visible initial write and visible appended error tests. It contains 14 test methods.
- `full-files/docs/searxng-discovery/SEARCH_MODES_20261017.md`: complete new document reconstructed from its visible initial write and error-handling addition.
- `patch-inputs/01-*.py.txt` through `07-*.py.txt`: ordered excerpts of the actual executed Python edit inputs for model/config/controller/registration/codec, settings UI, provider modes, category SPI, category observations, radio semantics and eight application tests. They are preserved as text and have NOT been executed in this recovery. Some excerpts depend on `Path` or `r` imported/declared by their original surrounding script. They are not a validated replay program.
- `patch-inputs/08-source-settings-entry-contract.diff`: complete visible follow-up diff correcting the mode-aware save substring and adding five acknowledgement/live-gate source assertions. No production change was made by that follow-up.
- `evidence/historical-evidence.json`: previously reported file list, the one full historical file hash explicitly visible in output, test-count context and cross-worker integration obligations. Reported history is not new verification.

## Material NOT recovered or verified

1. The original 17-file freeze JSON was written to `/workspace/shared/searxng-search-modes-20261017-files.json`, but its per-file hash values were never printed. Its contents are NOT recreated with invented historical hashes. Only its visible exact file list and reported 22-new-test count are retained.
2. The SHA-256 `a3a4b9571755787d4a8c85771ca79242e00dd2395c21baae19ef1dd2ed897ca0` was explicitly printed for the final historical `SourceSettingsEntryContractTest.kt`. This bundle preserves its diff, not a claimed byte-identical full file; that hash is historical evidence only.
3. Existing target-file baselines, `StrictJson`, `SearxngTestSupport`, `ProviderFramework` outside the shown SPI insertion, and application test harnesses are not synthesized. The edits rely on the contemporaneous baseline and on the already-added raw response count fields.
4. Shared service admission and duplicate canonical-host protection were present before this worker's task and were intentionally not edited. Their full implementation and any later changes are outside this bundle. The configuration and registration excerpts must not be applied in a way that removes those guards.
5. Coordinator category-mismatch health retention, ValidationPipeline pass-through, source/validation metrics, verification trace and source admission changes were owned by other workers/main. Only reported interface contracts are retained here; their implementation bytes are unknown here.
6. Subsequent main-thread fixes, merged source, dependency checks, test reports, build outputs and any post-07:33 source changes are unknown. Historical test results do not validate these recovered bytes.
7. No comparison against the read-only 2801 remote baseline was performed. Nothing was applied to it. No missing baseline is claimed to have been recovered.
8. Partial upstream errors accompanying nonempty results were explicitly documented as not exported by this increment. No new behavior was invented during preservation.

## Recovery actions and integrity

Only this designated preservation directory was created/written/read. No session-storage path, prior workspace, remote baseline or user computer was read. No network operation, source-patch application, build, test, APK operation or upload was performed by this worker in this recovery.

`MANIFEST.json` assigns the required status and contains the current SHA-256 and byte count for every preserved payload file. `MANIFEST.sha256` records the current manifest hash. These hashes prove only the integrity of this newly written preservation bundle, not equality with the destroyed workspace. Source files contain their visible source text without an added status header; the manifest applies the status to each file explicitly.

Before any later rebuild, the build owner must establish the exact target baseline, inspect the preserved edits, reconcile other workers' changes, apply only reviewed changes to a separate authorized working copy, and rerun verification. This bundle grants no authority to modify the remote baseline.
