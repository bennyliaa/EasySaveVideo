package com.easysavevideo.searxng

import com.easysavevideo.discovery.*
import org.junit.Assert.*
import org.junit.Test

class SearxngReportedContributorsTest {
    private fun row(extra: String = "", url: String = "https://video.example.org/watch"): String =
        """{"url":"$url","title":"First","content":"Description"${if (extra.isEmpty()) "" else ",$extra"}}"""
    private fun page(vararg rows: String, check: () -> Unit = {}) = SearxngResponseParser.parseWithCounts(
        """{"results":[${rows.joinToString(",") }]}""".toByteArray(), 100, check)
    private fun report(extra: String = ""): ReportedSearchContributors = page(row(extra)).candidates.single().reportedSearchContributors!!

    @Test fun singularEngineRecognizesEveryReviewedExactLabel() {
        for (id in ReportedSearchContributorId.entries) {
            val report = report("\"engine\":\"${id.technicalId}\"")
            assertEquals(setOf(id), report.ids); assertTrue(report.flags.isEmpty())
            assertEquals(1, report.reportObservationCount)
        }
    }

    @Test fun pluralEnginesKeepVariantIdsSeparateWithoutAssumingIndependence() {
        val report = report("\"engines\":[" + ReportedSearchContributorId.entries.joinToString(",") { "\"${it.technicalId}\"" } + "]")
        assertEquals(ReportedSearchContributorId.entries.toSet(), report.ids)
        assertEquals(1, report.reportObservationCount)
        assertTrue(report.flags.isEmpty())
    }

    @Test fun bothFieldsUnionRepeatedRecognizedNamesWithoutExtraRows() {
        val report = report(""""engine":"google","engines":["google","bing","google"]""")
        assertEquals(setOf(ReportedSearchContributorId.GOOGLE, ReportedSearchContributorId.BING), report.ids)
        assertEquals(1, report.reportObservationCount); assertTrue(report.flags.isEmpty())
    }

    @Test fun absentAndEmptyAreExplicitlyDifferent() {
        val absent = report()
        assertEquals(ReportedSearchContributors.UNREPORTED, absent)
        val empty = report("\"engines\":[]")
        assertTrue(empty.ids.isEmpty()); assertTrue(empty.flags.isEmpty())
        assertEquals(0, empty.unreportedObservationCount)
        assertNotEquals(absent, empty)
    }

    @Test fun nullAndWrongTypesAreInvalidWithoutRejectingValidCandidate() {
        for (fields in listOf("\"engine\":null", "\"engine\":3", "\"engine\":[]", "\"engine\":{}",
            "\"engine\":true", "\"engines\":null", "\"engines\":\"google\"", "\"engines\":{}",
            "\"engines\":false")) {
            val report = report(fields)
            assertEquals(setOf(ReportedSearchContributorFlag.INVALID), report.flags)
            assertEquals(1, report.invalidObservationCount)
            assertTrue(report.ids.isEmpty())
        }
    }

    @Test fun malformedPluralItemsAreCountedIndividually() {
        val report = report(""""engines":["bing",null,4,false,{},[]]""")
        assertEquals(setOf(ReportedSearchContributorId.BING), report.ids)
        assertEquals(5, report.invalidObservationCount)
        assertEquals(setOf(ReportedSearchContributorFlag.INVALID), report.flags)
    }

    @Test fun malformedFieldDoesNotEraseValidOtherField() {
        val report = report(""""engine":null,"engines":["google"]""")
        assertEquals(setOf(ReportedSearchContributorId.GOOGLE), report.ids)
        assertEquals(1, report.invalidObservationCount)
        assertFalse(ReportedSearchContributorFlag.UNREPORTED in report.flags)
    }

    @Test fun unknownNamesAreObservationCountsNotUniqueEngines() {
        val report = report(""""engine":"custom","engines":["custom","custom","different"]""")
        assertTrue(report.ids.isEmpty()); assertEquals(4, report.unrecognizedObservationCount)
        assertEquals(setOf(ReportedSearchContributorFlag.UNRECOGNIZED), report.flags)
        assertFalse(report.toString().contains("custom")); assertFalse(report.toString().contains("different"))
    }

    @Test fun technicalModuleAliasesCaseAndWhitespaceAreNotGuessed() {
        val labels = listOf("Google", " google", "google ", "google_videos", "bing_videos", "duckduckgo_extra", "brave.videos")
        val report = report("\"engines\":[" + labels.joinToString(",") { "\"$it\"" } + "]")
        assertTrue(report.ids.isEmpty()); assertEquals(labels.size, report.unrecognizedObservationCount)
        assertTrue(ReportedSearchContributorFlag.UNRECOGNIZED in report.flags)
    }

    @Test fun controlsUnicodeAndBlankNamesProduceOnlyBoundedInvalidMarkers() {
        val report = report(""""engines":[""," ","goog\nle","私人查询","google\u202e","\u007f"]""")
        assertTrue(report.ids.isEmpty()); assertEquals(6, report.invalidObservationCount)
        assertEquals(setOf(ReportedSearchContributorFlag.INVALID), report.flags)
        assertFalse(report.toString().contains("私人查询"))
    }

    @Test fun privateQueryTokenAndUrlLabelsCannotSurviveInDtoText() {
        val secrets = listOf("synthetic-query-secret", "synthetic-token-abcdef", "https://private.invalid/?q=secret")
        val parsed = page(row("\"engines\":[" + secrets.joinToString(",") { "\"$it\"" } + "]"))
        val candidate = parsed.candidates.single()
        assertEquals(secrets.size, candidate.reportedSearchContributors!!.unrecognizedObservationCount)
        val visible = listOf(candidate.toString(), candidate.reportedSearchContributors.toString(), parsed.toString()).joinToString()
        secrets.forEach { assertFalse(visible.contains(it)) }
        assertEquals(setOf(ReportedSearchContributorFlag.UNRECOGNIZED), candidate.reportedSearchContributors!!.flags)
    }

    @Test fun overlengthNameIsOmittedBeforeInterpretationAndNeverRetained() {
        val name = "synthetic-secret-" + "x".repeat(SearxngResponseParser.MAX_CONTRIBUTOR_NAME_LENGTH)
        val report = report("\"engine\":\"$name\"")
        assertTrue(report.ids.isEmpty()); assertEquals(1, report.invalidObservationCount)
        assertEquals(1, report.omittedObservationCount)
        assertEquals(setOf(ReportedSearchContributorFlag.INVALID, ReportedSearchContributorFlag.TRUNCATED), report.flags)
        assertFalse(report.toString().contains("synthetic-secret"))
    }

    @Test fun exactNameBoundIsNotTreatedAsOmitted() {
        val report = report("\"engine\":\"${"x".repeat(SearxngResponseParser.MAX_CONTRIBUTOR_NAME_LENGTH)}\"")
        assertEquals(1, report.unrecognizedObservationCount); assertEquals(0, report.omittedObservationCount)
        assertFalse(ReportedSearchContributorFlag.TRUNCATED in report.flags)
    }

    @Test fun pluralListBoundDropsUninspectedSuffixAndPreservesOmissionCount() {
        val limit = SearxngResponseParser.MAX_CONTRIBUTOR_LIST_LENGTH
        val labels = List(limit) { "\"google\"" } + listOf("\"bing\"", "\"duckduckgo\"", "null")
        val report = report("\"engines\":[${labels.joinToString(",")}]")
        assertEquals(setOf(ReportedSearchContributorId.GOOGLE), report.ids)
        assertEquals(3, report.omittedObservationCount)
        assertEquals(0, report.invalidObservationCount)
        assertEquals(setOf(ReportedSearchContributorFlag.TRUNCATED), report.flags)
    }

    @Test fun singularFieldStillParticipatesAtFullPluralBound() {
        val report = report("\"engine\":\"bing\",\"engines\":[" +
            List(SearxngResponseParser.MAX_CONTRIBUTOR_LIST_LENGTH) { "\"google\"" }.joinToString(",") + "]")
        assertEquals(setOf(ReportedSearchContributorId.GOOGLE, ReportedSearchContributorId.BING), report.ids)
        assertTrue(report.flags.isEmpty())
    }

    @Test fun sameUrlRowsMergeClaimsButKeepFirstTextAndRawRowCount() {
        val parsed = page(row("\"engine\":\"google\""), row("\"engines\":[\"bing\"]").replace("First", "Second"))
        assertEquals(2, parsed.rawResponseItemCount); assertEquals(1, parsed.candidates.size)
        val candidate = parsed.candidates.single()
        assertEquals("First", candidate.sourceReported!!.title)
        assertEquals(setOf(ReportedSearchContributorId.GOOGLE, ReportedSearchContributorId.BING), candidate.reportedSearchContributors!!.ids)
        assertEquals(2, candidate.reportedSearchContributors!!.reportObservationCount)
    }

    @Test fun duplicateMissingRowDoesNotBecomeCompleteWhenLaterRowReportsName() {
        val parsed = page(row(), row("\"engine\":\"google\""))
        val report = parsed.candidates.single().reportedSearchContributors!!
        assertEquals(1, report.unreportedObservationCount); assertEquals(2, report.reportObservationCount)
        assertEquals(setOf(ReportedSearchContributorFlag.UNREPORTED), report.flags)
    }

    @Test fun separateUrlsCannotExchangeContributors() {
        val parsed = page(row("\"engine\":\"google\""), row("\"engine\":\"bing\"", "https://video.example.org/other"))
        assertEquals(2, parsed.candidates.size)
        assertEquals(setOf(ReportedSearchContributorId.GOOGLE), parsed.candidates[0].reportedSearchContributors!!.ids)
        assertEquals(setOf(ReportedSearchContributorId.BING), parsed.candidates[1].reportedSearchContributors!!.ids)
    }

    @Test fun categoryMismatchStillDropsAllCandidatesAndReports() {
        val parsed = SearxngResponseParser.parseWithCounts("""{"results":[${row("\"engine\":\"google\",\"category\":\"general\"")}]}""".toByteArray(),
            100, {}, SearxngCategory.VIDEOS)
        assertEquals(ProviderCategoryStatus.CATEGORY_MISMATCH, parsed.categoryStatus)
        assertTrue(parsed.candidates.isEmpty()); assertEquals(1, parsed.rawResponseItemCount)
    }

    @Test fun invalidUrlsCannotIntroduceContributorReports() {
        val parsed = page(row("\"engine\":\"google\"", "file:///private"))
        assertTrue(parsed.candidates.isEmpty()); assertEquals(1, parsed.rawResponseItemCount)
    }

    @Test fun contributorParsingPreservesCancellationAndDeadlineFailures() {
        val json = """{"results":[${row("\"engines\":[" + List(32) { "\"google\"" }.joinToString(",") + "]")}]}""".toByteArray()
        var jsonChecks = 0
        StrictJson.read(json) { jsonChecks++ }
        for (code in listOf(SearxngError.CANCELLED, SearxngError.DEADLINE_EXCEEDED)) {
            var checks = 0
            protocolFails(code) { SearxngResponseParser.parseWithCounts(json, 100, {
                if (++checks >= jsonChecks + 5) throw SearxngFailure(code)
            }) }
        }
    }

    @Test fun realProviderBoundaryKeepsOneTransportCallAndOneProviderForManyLabels() {
        val transport = TestTransport(Reply("""{"results":[${row("\"engines\":[\"google\",\"bing\",\"google videos\"]")}]}"""))
        val page = provider(transport).search(request(), operation())
        assertEquals(1, transport.requests.size); assertEquals(1, page.candidates.size)
        val validated = ValidationPipeline(clock = TestClock(), retainUnvalidatedCandidates = true)
            .validate("searxng-1", page, SearchFilters(safeSearch = false), operation())
        val candidate = validated.pendingCandidates.single()
        assertEquals(setOf("searxng-1"), candidate.provenance)
        assertEquals(3, validated.reportedSearchContributorObservations.single().contributors.ids.size)
        assertEquals(1, validated.reportedSearchContributorObservations.single().contributors.reportObservationCount)
        assertTrue(validated.results.isEmpty())
    }

    @Test fun safeSearchRequiredStillRejectsBeforeTransportRegardlessOfClaims() {
        val transport = TestTransport(Reply("""{"results":[${row("\"engine\":\"google\"")}]}"""))
        fails(DiscoveryError.UNSUPPORTED_FILTER) { provider(transport).search(request(safe = true), operation()) }
        assertTrue(transport.requests.isEmpty())
    }
}
