package com.easysavevideo.discovery

import java.util.Collections
import java.util.EnumSet

/** Closed, reviewed endpoint-reported technical labels. Variants do not establish independence.
 * Catalog reviewed against https://docs.searxng.org/user/configured_engines.html on 2026-10-17.
 * A label is not an ESV provider, an observed upstream call, or verification/rights authority.
 */
enum class ReportedSearchContributorId(val technicalId: String) {
    GOOGLE("google"), GOOGLE_VIDEOS("google videos"),
    BING("bing"), BING_VIDEOS("bing videos"),
    DUCKDUCKGO("duckduckgo"), DUCKDUCKGO_VIDEOS("duckduckgo videos"),
    BRAVE("brave");

    companion object {
        /** Exact comparison only. No aliases, whitespace normalization, or regional inference. */
        fun fromTechnicalId(value: String): ReportedSearchContributorId? = entries.firstOrNull { it.technicalId == value }
    }
}

enum class ReportedSearchContributorFlag { UNREPORTED, INVALID, UNRECOGNIZED, TRUNCATED, COUNTER_SATURATED }

/** Detached and immutable. No response-supplied string or hash can be retained in this type.
 * Counts are observations, including repetitions, not unique labels, independent engines or calls.
 * reportObservationCount counts response rows, including rows with absent attribution. An explicit
 * empty array is a reported empty set (no UNREPORTED flag); missing fields are UNREPORTED.
 */
class ReportedSearchContributors(
    ids: Set<ReportedSearchContributorId> = emptySet(),
    flags: Set<ReportedSearchContributorFlag> = emptySet(),
    reportObservationCount: Int = 1,
    unreportedObservationCount: Int = 0,
    invalidObservationCount: Int = 0,
    unrecognizedObservationCount: Int = 0,
    omittedObservationCount: Int = 0,
) {
    val ids: Set<ReportedSearchContributorId> = immutableEnums(ids, ReportedSearchContributorId::class.java)
    val reportObservationCount: Int = reportObservationCount.coerceIn(1, MAX_OBSERVATIONS)
    val unreportedObservationCount: Int = unreportedObservationCount.coerceIn(0, MAX_OBSERVATIONS)
    val invalidObservationCount: Int = invalidObservationCount.coerceIn(0, MAX_OBSERVATIONS)
    val unrecognizedObservationCount: Int = unrecognizedObservationCount.coerceIn(0, MAX_OBSERVATIONS)
    val omittedObservationCount: Int = omittedObservationCount.coerceIn(0, MAX_OBSERVATIONS)
    val flags: Set<ReportedSearchContributorFlag> = immutableEnums(buildSet {
        addAll(flags)
        if (unreportedObservationCount > 0) add(ReportedSearchContributorFlag.UNREPORTED)
        if (invalidObservationCount > 0) add(ReportedSearchContributorFlag.INVALID)
        if (unrecognizedObservationCount > 0) add(ReportedSearchContributorFlag.UNRECOGNIZED)
        if (omittedObservationCount > 0) add(ReportedSearchContributorFlag.TRUNCATED)
        if (reportObservationCount < 1 || listOf(unreportedObservationCount, invalidObservationCount,
                unrecognizedObservationCount, omittedObservationCount).any { it < 0 }) add(ReportedSearchContributorFlag.INVALID)
        if (listOf(reportObservationCount, unreportedObservationCount, invalidObservationCount,
                unrecognizedObservationCount, omittedObservationCount).any { it > MAX_OBSERVATIONS })
            add(ReportedSearchContributorFlag.COUNTER_SATURATED)
    }, ReportedSearchContributorFlag::class.java)

    /** Caller must first establish the same exact canonical page and reporting ESV provider. */
    fun merge(other: ReportedSearchContributors): ReportedSearchContributors = ReportedSearchContributors(
        ids + other.ids, flags + other.flags,
        sum(reportObservationCount, other.reportObservationCount),
        sum(unreportedObservationCount, other.unreportedObservationCount),
        sum(invalidObservationCount, other.invalidObservationCount),
        sum(unrecognizedObservationCount, other.unrecognizedObservationCount),
        sum(omittedObservationCount, other.omittedObservationCount),
    )

    override fun equals(other: Any?): Boolean = other is ReportedSearchContributors && ids == other.ids && flags == other.flags &&
        reportObservationCount == other.reportObservationCount && unreportedObservationCount == other.unreportedObservationCount &&
        invalidObservationCount == other.invalidObservationCount && unrecognizedObservationCount == other.unrecognizedObservationCount &&
        omittedObservationCount == other.omittedObservationCount
    override fun hashCode(): Int = listOf(ids, flags, reportObservationCount, unreportedObservationCount,
        invalidObservationCount, unrecognizedObservationCount, omittedObservationCount).hashCode()
    override fun toString(): String = "ReportedSearchContributors(ids=$ids, flags=$flags, reportObservationCount=$reportObservationCount, " +
        "unreportedObservationCount=$unreportedObservationCount, invalidObservationCount=$invalidObservationCount, " +
        "unrecognizedObservationCount=$unrecognizedObservationCount, omittedObservationCount=$omittedObservationCount)"

    companion object {
        const val MAX_OBSERVATIONS = 1_000_000
        val UNREPORTED = ReportedSearchContributors(unreportedObservationCount = 1)
        // Retain a one-past-limit sentinel until construction to mark lost precision explicitly.
        private fun sum(first: Int, second: Int): Int = (first.toLong() + second).coerceAtMost(MAX_OBSERVATIONS.toLong() + 1).toInt()
        private fun <E : Enum<E>> immutableEnums(values: Set<E>, type: Class<E>): Set<E> =
            Collections.unmodifiableSet(EnumSet.noneOf(type).also { it.addAll(values) })
    }
}

/** Pipeline-bound accepted exact-page observation. It is RAM-only and grants no fetch/Save authority.
 * Construction is module-internal: response adapters cannot supply a reporting provider or page hash.
 */
class AcceptedPageReportedSearchContributors internal constructor(
    val providerId: String,
    val canonicalPageUrlHash: String,
    val contributors: ReportedSearchContributors,
) {
    init { requireId(providerId); require(canonicalPageUrlHash.matches(Regex("[a-f0-9]{64}"))) }
    override fun toString(): String = "AcceptedPageReportedSearchContributors([redacted])"
}
