package com.easysavevideo.discovery

import org.junit.Assert.*
import org.junit.Test

class ReportedSearchContributorsPipelineTest {
    private val filters = SearchFilters(safeSearch = false)
    private val google = ReportedSearchContributors(setOf(ReportedSearchContributorId.GOOGLE))
    private val bing = ReportedSearchContributors(setOf(ReportedSearchContributorId.BING))
    private val candidate = CandidateUrl("https://video.example/watch", SourceReportedCandidateMetadata(title = "First"), google)
    private fun pipeline(validator: CandidateValidator? = null, cap: Int = 100) = ValidationPipeline(validator,
        clock = FakeClock(), retainUnvalidatedCandidates = true, retainFailedValidationCandidates = true, maxValidationsPerPage = cap)
    private fun validate(candidates: List<CandidateUrl> = listOf(candidate), validator: CandidateValidator? = null,
        selectedFilters: SearchFilters = filters) = pipeline(validator).validate("searxng-1",
            ProviderPage(candidates = candidates, rawResponseItemCount = candidates.size), selectedFilters, operation())

    @Test fun canonicalDuplicatesMergeClaimsWithoutChangingFirstMetadataOrPoolSize() {
        val pool = CandidateUrlPool(5)
        assertTrue(pool.add(candidate))
        assertFalse(pool.add(candidate.copy(pageUrl = "https://VIDEO.example:443/watch",
            sourceReported = SourceReportedCandidateMetadata(title = "Second"), reportedSearchContributors = bing)))
        assertEquals(1, pool.size)
        val retained = pool.take()!!
        assertEquals("First", retained.sourceReported!!.title)
        assertEquals(setOf(ReportedSearchContributorId.GOOGLE, ReportedSearchContributorId.BING), retained.reportedSearchContributors!!.ids)
        assertEquals(2, retained.reportedSearchContributors!!.reportObservationCount)
        assertNull(pool.take())
    }

    @Test fun nonparticipatingDuplicateDoesNotInventMissingReport() {
        val pool = CandidateUrlPool(5)
        pool.add(candidate.copy(reportedSearchContributors = null)); pool.add(candidate); pool.add(candidate.copy(reportedSearchContributors = null))
        assertEquals(google, pool.take()!!.reportedSearchContributors)
    }

    @Test fun explicitMissingDuplicateRemainsVisibleAfterRecognizedReport() {
        val page = validate(listOf(candidate, candidate.copy(reportedSearchContributors = ReportedSearchContributors.UNREPORTED)))
        val report = page.reportedSearchContributorObservations.single().contributors
        assertEquals(2, report.reportObservationCount)
        assertEquals(1, report.unreportedObservationCount)
        assertTrue(ReportedSearchContributorFlag.UNREPORTED in report.flags)
    }

    @Test fun pendingObservationBindsOnlyActualProviderAndExactCanonicalHash() {
        val page = validate(listOf(candidate.copy(pageUrl = "https://VIDEO.example:443/watch")))
        assertEquals(1, page.pendingCandidates.size); assertTrue(page.results.isEmpty())
        val observation = page.reportedSearchContributorObservations.single()
        assertEquals("searxng-1", observation.providerId)
        assertEquals(digest(framed("url-v1", candidate.pageUrl)), observation.canonicalPageUrlHash)
        assertEquals(google, observation.contributors)
        assertEquals(setOf("searxng-1"), page.pendingCandidates.single().provenance)
        assertNull(page.pendingCandidates.single().verification)
    }

    @Test fun directConfirmationKeepsReportSeparateFromEvidenceAndRights() {
        val page = validate(validator = CandidateValidator { _, _ -> RawVideoResult("https://VIDEO.example:443/watch", true) })
        val result = page.results.single()
        assertEquals(google, page.reportedSearchContributorObservations.single().contributors)
        assertEquals(setOf("searxng-1"), result.provenance)
        assertEquals("searxng-1", result.sourceNamespace)
        assertNull(result.title); assertNull(result.thumbnailUrl)
        assertEquals(ResultRights(), result.rights)
        assertTrue(page.verificationReports.isEmpty())
    }

    @Test fun redirectedValidatedPageNeverInheritsOriginalSearchReport() {
        val page = validate(validator = CandidateValidator { _, _ -> RawVideoResult("https://video.example/different", true) })
        assertEquals(1, page.results.size)
        assertTrue(page.pendingCandidates.isEmpty())
        assertTrue(page.reportedSearchContributorObservations.isEmpty())
    }

    @Test fun differentFragmentsDoNotExchangeAttribution() {
        val page = validate(listOf(candidate, candidate.copy(pageUrl = candidate.pageUrl + "#other", reportedSearchContributors = bing)))
        val reports = page.reportedSearchContributorObservations.associateBy { it.canonicalPageUrlHash }
        assertEquals(2, reports.size)
        assertEquals(google, reports[digest(framed("url-v1", candidate.pageUrl))]!!.contributors)
        assertEquals(bing, reports[digest(framed("url-v1", candidate.pageUrl + "#other"))]!!.contributors)
    }

    @Test fun canonicalDedupKeepsRawCountsAndOnlyOneValidationAttempt() {
        var calls = 0
        val page = validate(listOf(candidate, candidate.copy(pageUrl = "https://VIDEO.example:443/watch", reportedSearchContributors = bing)),
            CandidateValidator { c, _ -> calls++; RawVideoResult(c.pageUrl, true) })
        assertEquals(1, calls); assertEquals(1, page.results.size)
        assertEquals(2, page.observation!!.providerReturnedItemCount)
        assertEquals(2, page.observation!!.rawResponseItemCount)
        assertEquals(2, page.reportedSearchContributorObservations.single().contributors.reportObservationCount)
    }

    @Test fun excludedProviderAndUnknownDurationRejectReportWithCandidate() {
        for (restricted in listOf(filters.copy(sourceNamespaces = setOf("searxng-2")), filters.copy(includeUnknownDuration = false))) {
            val page = validate(selectedFilters = restricted)
            assertTrue(page.pendingCandidates.isEmpty()); assertTrue(page.results.isEmpty())
            assertTrue(page.reportedSearchContributorObservations.isEmpty())
        }
    }

    @Test fun filteredConfirmedDurationDoesNotLeaveReportWithoutAcceptedPage() {
        val page = validate(validator = CandidateValidator { c, _ -> RawVideoResult(c.pageUrl, true, durationMs = 1000) },
            selectedFilters = filters.copy(minimumDurationMs = 2000))
        assertTrue(page.pendingCandidates.isEmpty()); assertTrue(page.results.isEmpty())
        assertTrue(page.reportedSearchContributorObservations.isEmpty())
    }

    @Test fun invalidCandidateUrlCannotProduceReport() {
        val page = validate(listOf(candidate.copy(pageUrl = "file:///secret")))
        assertTrue(page.reportedSearchContributorObservations.isEmpty()); assertTrue(page.pendingCandidates.isEmpty())
    }

    @Test fun absentReportAndRawVideoResultCannotInventContributorObservation() {
        val page = pipeline().validate("searxng-1", ProviderPage(candidates = listOf(candidate.copy(reportedSearchContributors = null)),
            results = listOf(RawVideoResult("https://video.example/already", true))), filters, operation())
        assertEquals(1, page.results.size); assertEquals(1, page.pendingCandidates.size)
        assertTrue(page.reportedSearchContributorObservations.isEmpty())
    }

    @Test fun validationFailureAndZeroBudgetRetainOnlyPendingObservation() {
        for (p in listOf(pipeline(CandidateValidator { _, _ -> throw IllegalStateException("PRIVATE") }),
            pipeline(CandidateValidator { _, _ -> fail(); null }, 0))) {
            val page = p.validate("searxng-1", ProviderPage(candidates = listOf(candidate)), filters, operation())
            assertEquals(1, page.pendingCandidates.size); assertTrue(page.results.isEmpty())
            assertEquals(google, page.reportedSearchContributorObservations.single().contributors)
        }
    }

    @Test fun deferredSourceCandidateRetainsReportWithoutInvokingValidator() {
        val page = pipeline(CandidateValidator { _, _ -> fail(); null }).validate("searxng-1",
            ProviderPage(candidates = listOf(candidate)), filters, operation(), deferCandidateValidation = true)
        assertEquals(google, page.reportedSearchContributorObservations.single().contributors)
        assertEquals(0, page.verificationObservation!!.validationCount)
    }

    @Test fun operationCancellationCannotPublishContributorObservations() {
        val op = operation()
        try {
            pipeline(CandidateValidator { c, _ -> op.cancellation.cancel(); RawVideoResult(c.pageUrl, true) })
                .validate("searxng-1", ProviderPage(candidates = listOf(candidate)), filters, op)
            fail()
        } catch (failure: DiscoveryFailure) { assertEquals(DiscoveryError.CANCELLED, failure.code) }
    }

    @Test fun expiredOperationCannotPublishContributorObservations() {
        try { pipeline().validate("searxng-1", ProviderPage(candidates = listOf(candidate)), filters, operation(deadline = 999)); fail() }
        catch (failure: DiscoveryFailure) { assertEquals(DiscoveryError.DEADLINE_EXCEEDED, failure.code) }
    }

    @Test fun emittedObservationListIsUnmodifiable() {
        val page = validate()
        try { (page.reportedSearchContributorObservations as MutableList).clear(); fail() }
        catch (_: UnsupportedOperationException) { }
    }
}
