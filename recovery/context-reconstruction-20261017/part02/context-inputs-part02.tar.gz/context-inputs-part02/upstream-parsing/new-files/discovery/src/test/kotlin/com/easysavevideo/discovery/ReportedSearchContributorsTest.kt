package com.easysavevideo.discovery

import org.junit.Assert.*
import org.junit.Test

class ReportedSearchContributorsTest {
    @Test fun reviewedCatalogUsesExactNamesWithoutAliases() {
        val expected = mapOf("google" to ReportedSearchContributorId.GOOGLE,
            "google videos" to ReportedSearchContributorId.GOOGLE_VIDEOS,
            "bing" to ReportedSearchContributorId.BING, "bing videos" to ReportedSearchContributorId.BING_VIDEOS,
            "duckduckgo" to ReportedSearchContributorId.DUCKDUCKGO,
            "duckduckgo videos" to ReportedSearchContributorId.DUCKDUCKGO_VIDEOS,
            "brave" to ReportedSearchContributorId.BRAVE)
        assertEquals(expected.size, ReportedSearchContributorId.entries.size)
        expected.forEach { (name, id) -> assertEquals(id, ReportedSearchContributorId.fromTechnicalId(name)) }
        for (name in listOf("Google", " google", "google ", "google_videos", "google.de", "bing-videos", "brave.videos"))
            assertNull(ReportedSearchContributorId.fromTechnicalId(name))
    }

    @Test fun constructorDetachesIdsAndFlagsFromCaller() {
        val ids = mutableSetOf(ReportedSearchContributorId.GOOGLE)
        val flags = mutableSetOf(ReportedSearchContributorFlag.INVALID)
        val report = ReportedSearchContributors(ids, flags)
        ids.clear(); flags.clear()
        assertEquals(setOf(ReportedSearchContributorId.GOOGLE), report.ids)
        assertEquals(setOf(ReportedSearchContributorFlag.INVALID), report.flags)
    }

    @Test fun exposedSetsAreUnmodifiableIncludingEmptySets() {
        for (report in listOf(ReportedSearchContributors(), ReportedSearchContributors.UNREPORTED,
            ReportedSearchContributors(setOf(ReportedSearchContributorId.GOOGLE)))) {
            try { (report.ids as MutableSet).add(ReportedSearchContributorId.BING); fail() }
            catch (_: UnsupportedOperationException) { }
            try { (report.flags as MutableSet).add(ReportedSearchContributorFlag.INVALID); fail() }
            catch (_: UnsupportedOperationException) { }
        }
    }

    @Test fun mergeUnionsIdsButCountsRepeatedRowAndUnknownObservations() {
        val first = ReportedSearchContributors(setOf(ReportedSearchContributorId.GOOGLE), unrecognizedObservationCount = 2)
        val second = ReportedSearchContributors(setOf(ReportedSearchContributorId.GOOGLE, ReportedSearchContributorId.BING),
            invalidObservationCount = 1, omittedObservationCount = 3)
        val merged = first.merge(second).merge(ReportedSearchContributors.UNREPORTED)
        assertEquals(setOf(ReportedSearchContributorId.GOOGLE, ReportedSearchContributorId.BING), merged.ids)
        assertEquals(3, merged.reportObservationCount)
        assertEquals(2, merged.unrecognizedObservationCount)
        assertEquals(1, merged.invalidObservationCount)
        assertEquals(3, merged.omittedObservationCount)
        assertEquals(1, merged.unreportedObservationCount)
        assertEquals(setOf(ReportedSearchContributorFlag.UNREPORTED, ReportedSearchContributorFlag.INVALID,
            ReportedSearchContributorFlag.UNRECOGNIZED, ReportedSearchContributorFlag.TRUNCATED), merged.flags)
        assertEquals(1, first.reportObservationCount)
    }

    @Test fun saturatedCountsCannotOverflowOrSilentlyBecomeComplete() {
        val cap = ReportedSearchContributors.MAX_OBSERVATIONS
        val maximum = ReportedSearchContributors(reportObservationCount = cap,
            unreportedObservationCount = cap, invalidObservationCount = cap,
            unrecognizedObservationCount = cap, omittedObservationCount = cap)
        assertFalse(ReportedSearchContributorFlag.COUNTER_SATURATED in maximum.flags)
        val merged = maximum.merge(maximum)
        assertEquals(listOf(cap, cap, cap, cap, cap), listOf(merged.reportObservationCount,
            merged.unreportedObservationCount, merged.invalidObservationCount,
            merged.unrecognizedObservationCount, merged.omittedObservationCount))
        assertTrue(ReportedSearchContributorFlag.COUNTER_SATURATED in merged.flags)
        assertTrue(ReportedSearchContributorFlag.COUNTER_SATURATED in merged.merge(ReportedSearchContributors()).flags)
    }

    @Test fun constructorClampsInvalidAndExcessiveCounters() {
        val report = ReportedSearchContributors(reportObservationCount = -1, unreportedObservationCount = -2,
            invalidObservationCount = Int.MAX_VALUE, unrecognizedObservationCount = Int.MAX_VALUE,
            omittedObservationCount = Int.MAX_VALUE)
        assertEquals(1, report.reportObservationCount)
        assertEquals(0, report.unreportedObservationCount)
        assertEquals(ReportedSearchContributors.MAX_OBSERVATIONS, report.invalidObservationCount)
        assertEquals(ReportedSearchContributors.MAX_OBSERVATIONS, report.unrecognizedObservationCount)
        assertEquals(ReportedSearchContributors.MAX_OBSERVATIONS, report.omittedObservationCount)
        assertTrue(ReportedSearchContributorFlag.INVALID in report.flags)
        assertTrue(ReportedSearchContributorFlag.COUNTER_SATURATED in report.flags)
    }

    @Test fun validEmptyReportAndUnreportedAreDistinct() {
        val empty = ReportedSearchContributors()
        assertTrue(empty.ids.isEmpty()); assertTrue(empty.flags.isEmpty())
        assertNotEquals(empty, ReportedSearchContributors.UNREPORTED)
        assertEquals(setOf(ReportedSearchContributorFlag.UNREPORTED), ReportedSearchContributors.UNREPORTED.flags)
        assertEquals(1, ReportedSearchContributors.UNREPORTED.unreportedObservationCount)
    }

    @Test fun equivalentReportsHaveValueEqualityAndStableHash() {
        val first = ReportedSearchContributors(setOf(ReportedSearchContributorId.BING, ReportedSearchContributorId.GOOGLE))
        val second = ReportedSearchContributors(setOf(ReportedSearchContributorId.GOOGLE, ReportedSearchContributorId.BING))
        assertEquals(first, second); assertEquals(first.hashCode(), second.hashCode())
    }
}
