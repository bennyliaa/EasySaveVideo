# 上游贡献者解析材料保全

状态：**context-reconstructed/unverified**。本目录不是已验证恢复包，也不是可直接应用的源码基线。

2026-10-17 22:36 UTC 起，根据本工作线程当前对话可见、此前已实际执行的写入/替换输入重建。没有读取任何会话存储路径，没有读取或修改 remote-baseline，没有联网、构建、设备操作或执行所保存的补丁。

## 全目录状态规则

本目录所有文件（包括 Kotlin、补丁输入、说明及清单）均标记为 `context-reconstructed/unverified`。为保全可见原输入，未向 Kotlin/补丁正文添加状态注释；文件级状态见 `MANIFEST.json`。`SHA256SUMS` 是当前保全字节的校验和，不是丢失工作区原件的校验和，不能据此宣称原件逐字恢复成功。

## 实际可重建的字节

1. `new-files/discovery/src/main/kotlin/com/easysavevideo/discovery/ReportedSearchContributors.kt`：当前对话完整 heredoc 新增输入，含七项闭合枚举、不可变集合、限幅计数、合并和内部构造的接受页观察类型。
2. `new-files/discovery/src/test/kotlin/com/easysavevideo/discovery/ReportedSearchContributorsTest.kt`：当前对话完整 heredoc 新增输入，8 个测试方法。
3. `new-files/discovery/src/test/kotlin/com/easysavevideo/discovery/ReportedSearchContributorsPipelineTest.kt`：当前对话完整 heredoc 新增输入，加已执行的一处字段名 sed 修正后的版本，17 个测试方法。原输入用 `validationInvocations`；最后已知本工作者修正为 `validationCount`。原修正命令另存于 `patch-inputs/03_pipeline_test_field_fix.sh.txt`，不要再据此重复修改已修正的新文件。
4. `new-files/searxng-provider/src/test/kotlin/com/easysavevideo/searxng/SearxngReportedContributorsTest.kt`：当前对话完整 heredoc 新增输入，23 个测试方法。
5. `patch-inputs/01_discovery_models_and_pipeline.py.txt`：实际执行过的 Python 替换输入，针对 `DiscoveryModels.kt` 和 `ValidationPipeline.kt`。只保全输入，未执行。
6. `patch-inputs/02_searxng_parser.py.txt`：实际执行过的 Python 替换输入，针对 `SearxngResponseParser.kt`。只保全输入，未执行。
7. `patch-inputs/03_pipeline_test_field_fix.sh.txt`：实际执行过的字段名 sed 修正输入。只保全输入，未执行。
8. `patch-inputs/04_parser_semantics_javadoc.py.txt`：实际执行过的末次解析语义 Javadoc 替换输入。只保全输入，未执行。

这些重建文件按当前可见输入逐段抄录，不代表与丢失原文件的独立字节比对。原写入和校正工具当时返回退出码 0；本次没有原件可比对。

## 仅设计、上下文或历史声明

- 当时向父线程报告已冻结 7 个代码/测试目标：4 个新增完整文件与3个既有文件的修改。这里没有重造3个既有文件的完整基线。
- 当前可见历史只记录本工作者添加了 48 个测试方法及交给父线程串行构建；**不含这些测试通过或构建成功的证据**。
- 既有接口约定：`CandidateUrl.reportedSearchContributors`；`ValidatedProviderPage.reportedSearchContributorObservations`；观察含实际 `providerId`、`canonicalPageUrlHash` 和 `contributors`。哈希公式为既有 `digest(framed("url-v1", canonicalUrl))`。
- 解析语义：两个字段均不存在为 UNREPORTED；显式 null/错误形状为 INVALID；有效空数组为空集合、无缺失标记。未知项计数为标签出现次数，行计数为响应行观察次数。
- 当时已查阅的官方来源为 https://docs.searxng.org/user/configured_engines.html，版本标记 2026.10.16+8252c0bf6，访问日期2026-10-17。可见历史引用 web 名称行230–233、video 名称行347、349、360。这里只保存历史引用，没有在恢复期间联网验证。精确空格名称与模块下划线名称不互作别名。
- 当前对话没有原文件 SHA256，所以没有可用于逐字验证的原件摘要。下面清单全部属于本次重建字节。

## 缺口和后续 main 未知修改

- 原完整 `DiscoveryModels.kt`、`ValidationPipeline.kt`、`SearxngResponseParser.kt` 及其所属 verified3009 基线未恢复。补丁要求当时精确前文；这些字符串替换没有匹配断言且部分不幂等，**不得盲目应用到恢复的 Git 2801 或其他基线**。
- 本工作者不拥有并未重建 `AcceptedPageLedger`、协调器、会话指标、评估采集或其他工作者的测试；它们由另一个工作者负责。对话中的 API 约定不是其实现字节证据。
- 本工作者最后已知代码冻结报告发生在2026-10-17约08:49 UTC。之后父线程/main或其他工作者的编译修正、重构、测试、审查结论、清单、提交和产物，在当前上下文均未知，不能假定这些重建文件就是最终 main。
- 不恢复 APK、SDK、依赖、构建缓存、测试 XML、运行日志、源清单、原检查点哈希、Git提交或部署状态；没有这些字节的可见执行输入。
- 本目录没有修正潜在编译/逻辑问题，也没有因恢复任务补充设计或实现。48是源中测试方法数，不是测试通过数。

## 清单

`MANIFEST.json` 逐项列明材料性质、当前字节数、当前SHA256、状态和原件比对缺失。`SHA256SUMS` 覆盖除自身外的全部文件（包括 `MANIFEST.json`）。清单生成和复核只是本次写入完整性检查，不构成编译、测试或历史真实性验证。
