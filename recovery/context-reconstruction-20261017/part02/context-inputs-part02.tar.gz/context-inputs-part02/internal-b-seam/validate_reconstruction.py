"""context-reconstructed/unverified: preservation checks only; never compile or patch a baseline."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
final_path = root / 'reconstructed/LocalVerificationEngineTransportSeamTest.kt'
prior_path = root / 'historical/LocalVerificationEngineTransportSeamTest.before-reflection-fix.kt'
expected = {
    str(final_path.relative_to(root)): '46d484161bfff25566e354cd45770b9eade96159e2b79cef8e74ae9b66a480e8',
    str(prior_path.relative_to(root)): '6c86fd27b86bacfcd91761cb1c4c08ce81f80d2f4a6e6cf23886d38d0b5416db',
}
results = []
for name, digest in expected.items():
    actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
    results.append({'file': name, 'current_sha256': actual, 'recorded_sha256': digest, 'matches_recorded_hash': actual == digest})
    assert actual == digest, name

add_lines = (root / 'patch-inputs/03-add-focused-test-file.apply_patch.txt').read_text().splitlines()
assert add_lines[0] == '*** Begin Patch' and add_lines[-1] == '*** End Patch'
assert add_lines[1].startswith('*** Add File: ')
assert all(line.startswith('+') for line in add_lines[2:-1])
initial = ''.join(line[1:] + '\n' for line in add_lines[2:-1])
assert initial.count('@Test') == 9
null_patch = (root / 'patch-inputs/04-test-foreign-null-callback.apply_patch.txt').read_text().splitlines()
null_block = ''.join(line[1:] + '\n' for line in null_patch if line.startswith('+'))
anchor = '\n    @Test fun successfulPublicPolicyReadsRobotsThenPageAndCancelsBeforeClosingBodies() {'
assert initial.count(anchor) == 1
replayed_prior = initial.replace(anchor, null_block + anchor)
assert replayed_prior == prior_path.read_text()
fix_lines = (root / 'patch-inputs/05-test-private-lambda-reflection-fix.apply_patch.txt').read_text().splitlines()
removed = ''.join(line[1:] + '\n' for line in fix_lines if line.startswith('-'))
added = ''.join(line[1:] + '\n' for line in fix_lines if line.startswith('+'))
assert replayed_prior.count(removed) == 1
replayed_final = replayed_prior.replace(removed, added)
assert replayed_final == final_path.read_text()
assert replayed_final.count('@Test') == 10
report = {
    'status': 'context-reconstructed/unverified',
    'purpose': 'Recovery material byte checks only, not compilation or test execution',
    'historical_hash_comparisons': results,
    'test_patch_text_replay_matches_saved_prior_and_final': True,
    'initial_test_count': 9,
    'final_test_count': 10,
    'production_patch_application': 'NOT_PERFORMED',
    'production_full_file_hash_check': 'NOT_PERFORMED: exact baseline and full production bytes not recovered',
    'build_tests_network_device_operations': 'NOT_PERFORMED',
}
(root / 'RECOVERY_VALIDATION.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
