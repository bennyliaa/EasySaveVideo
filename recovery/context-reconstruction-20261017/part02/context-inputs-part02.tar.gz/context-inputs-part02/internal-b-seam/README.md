# Internal B Call seam recovery materials

Status of every file in this directory: **context-reconstructed/unverified**.
Recovery date: 2026-10-17 UTC.
These are preservation materials, not an applied source candidate, a recovered Git commit, or a passing build.

## Scope and provenance

The assigned worker reconstructed only the seam changes that it previously executed and that remain visible in its current conversation: two production patch inputs, the complete new focused test file, the foreign-null callback test addition, and the later reflection-assertion correction. No session-storage paths were read. No baseline was read, modified, synthesized or patched. No build, network, device operation, or upload was performed.

Original target root, retained only as historical text in patch inputs:
`/workspace/scratch/df6c1284d5ab/esv-runtime-copy-20261015/composite-public-b-20261017/source`

Patch inputs intentionally retain that obsolete absolute target. They are data files and have not been executed during recovery. They must not be applied to the read-only remote-baseline or any other baseline without a separately authorized, exact source comparison.

## Actually reconstructed bytes

- `patch-inputs/01-engine-internal-call-seam.apply_patch.txt`: private immutable per-engine Request-to-Call callback, preserved public constructor/defaults and explicit no-argument constructor, internal synthetic public-policy-only factory, explicit Call selection without fallback. Reconstructed from the visible executed patch input.
- `patch-inputs/02-engine-timeout-ownership.apply_patch.txt`: move timeout configuration after active Call registration and inside the existing try/finally. Reconstructed from the visible executed patch input.
- `patch-inputs/03-add-focused-test-file.apply_patch.txt`: the original complete nine-test file addition. Reconstructed from the complete visible addition and checked against the two later visible deltas. No historical hash of this patch input was recorded.
- `patch-inputs/04-test-foreign-null-callback.apply_patch.txt`: tenth test for a foreign JVM callback returning null, without production fallback. Reconstructed from the visible executed patch input.
- `patch-inputs/05-test-private-lambda-reflection-fix.apply_patch.txt`: test-only correction that requires non-private factories to remain synthetic and any non-synthetic matching helper to be private. Reconstructed from the visible executed patch input.
- `reconstructed/LocalVerificationEngineTransportSeamTest.kt`: complete final test file last written by this worker. Its current byte hash matches the historical 09:24 hash recorded in the visible conversation: `46d484161bfff25566e354cd45770b9eade96159e2b79cef8e74ae9b66a480e8`.
- `historical/LocalVerificationEngineTransportSeamTest.before-reflection-fix.kt`: complete earlier ten-test version, retaining the broad-prefix reflection assertion that was reported failing. Its current byte hash matches the historical hash recorded in the visible conversation: `6c86fd27b86bacfcd91761cb1c4c08ce81f80d2f4a6e6cf23886d38d0b5416db`.

A matching historical digest establishes byte identity to the digest recorded in this conversation. It does not establish a recovered workspace, current main contents, source applicability, independent artifact custody, or test success. The files retain context-reconstructed/unverified status. Status labels live in this README and the inventory rather than altering hash-matched Kotlin bytes.

## Design / hash only, without recovered production baseline

The visible final production-file hash was:
`2966ac00a844f1679502f2e1e6f0d9626d0d861f6c0e74bf501bee1222b081c5` for `verification-local/src/main/kotlin/com/easysavevideo/verification/local/LocalVerificationEngine.kt`.

That complete production file was not reconstructed or rehashed in this recovery. Only its two executed patch inputs are preserved. The hash is historical metadata, not evidence that a current file with those bytes exists here.

The intended API was `LocalVerificationEngine.withScriptedPublicCalls(newCall: (Request) -> Call, monotonicMillis: () -> Long = system clock)`. The callback is immutable and instance-local, and the factory forces public mode with no renderer. Public construction selects constrained OkHttp. The seam preserves the real grant, policy, request/body budgets, cancellation and parsing path apart from the disclosed timeout-ownership ordering correction. Scripted Calls bypass DNS, TLS and network interceptors; they do not prove wire retry suppression, shared Retry-After interception, live public access, or TLS validation. This section restates the recorded design, not new verification against a production tree.

## Build / review evidence limitations

The parent previously reported successful compilation and a focused run of 17 tests with 16 passing and one reflection-test failure. It reported that javap showed synthetic callable factories but a private non-synthetic default-clock lambda helper. That report motivated patch 05. These were parent reports visible in this conversation; the worker did not execute those builds, and no original logs, XML, bytecode or test report artifacts are recovered here.

The independent reviewer accepted the original source design and reviewed the then-current ten-test source, subject to actual execution. It agreed to the narrower reflection correction. No new independent review or test execution was performed in this recovery. No post-correction rerun outcome is established by the recovered materials.

## Gaps and unknown later main changes

1. The exact 3016-file candidate baseline and surrounding production tree are absent from this package. The separately recovered read-only 2801-file remote baseline has not been inspected, changed, or used as a substitute.
2. No full LocalVerificationEngine.kt byte reconstruction is claimed. Exact patch applicability and production-file hash equality require the correct baseline, which is outside this recovery.
3. Integration tests, build.gradle changes, requirements audit, dependency lock/equality evidence, review files, build outputs, APKs and report logs were owned elsewhere and are not recovered here.
4. Changes made later by main/parent/other workers after the last visible 09:24 test correction are unknown. These files must not be labeled latest main, merged code, or the final released candidate.
5. The original failing run is preserved only as the historical source version and the quoted parent-reported summary. No missing execution log is fabricated.
6. Patch-input hashes below are newly calculated hashes of reconstructed text. No original patch-input hash exists in the visible record for an independent comparison.

## Current-byte inventory and validation

`HISTORICAL_HASHES.json` separates hash-only production metadata from the two hash-matched test snapshots. `RECOVERY_VALIDATION.json` records only current recovery checks: historical digest comparison and deterministic replay of test patch text to the final saved test file. It does not compile or execute the Kotlin code.

`SHA256SUMS` contains current byte hashes for all files in this package except itself. `ARTIFACT_INVENTORY.json` marks every listed artifact context-reconstructed/unverified and describes its provenance. `validate_reconstruction.py` reads only this package; it never applies production patches or touches a source baseline.
