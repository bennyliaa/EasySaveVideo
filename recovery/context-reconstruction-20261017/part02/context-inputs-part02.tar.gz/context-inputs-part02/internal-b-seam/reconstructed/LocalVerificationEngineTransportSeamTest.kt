package com.easysavevideo.verification.local

import com.easysavevideo.core.model.EpochClock
import com.easysavevideo.core.model.OperationContext
import com.easysavevideo.discovery.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okio.Buffer
import okio.BufferedSource
import okio.ForwardingSource
import okio.Timeout
import okio.buffer
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException
import java.lang.reflect.Modifier
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Authored in-memory Calls exercise the real public policy and ownership path, never DNS or sockets.
 * They do not run OkHttp's network interceptor, validate TLS, or prove HTTP-wire retry behavior.
 */
class LocalVerificationEngineTransportSeamTest {
    private val pageUrl = "https://transport-seam.example/watch"
    private val robots = "User-agent: *\nAllow: /\n"
    private val html = "<main><h1>Owned</h1><video data-esv-primary='true' src='/owned.mp4'></video></main>"

    @Test fun publicConstructorsRetainTheirShapeAndAlwaysSelectTheProductionTransport() {
        val constructors = LocalVerificationEngine::class.java.constructors.filterNot { it.isSynthetic }
        assertEquals(listOf(0, 3), constructors.map { it.parameterCount }.sorted())
        assertEquals(listOf(LocalDynamicRenderer::class.java, Boolean::class.javaPrimitiveType,
            kotlin.jvm.functions.Function0::class.java), constructors.single { it.parameterCount == 3 }.parameterTypes.toList())
        val factory = LocalVerificationEngine::class.java.getDeclaredField("scriptedCallFactory")
        assertTrue(Modifier.isPrivate(factory.modifiers))
        assertTrue(Modifier.isFinal(factory.modifiers))
        factory.isAccessible = true
        LocalVerificationEngine().use { assertNull(factory.get(it)) }
        LocalVerificationEngine(renderer = null, fixtureLoopbackOnly = true, monotonicMillis = { 1000L }).use {
            assertNull(factory.get(it))
        }
        // Kotlin internal + JVM synthetic is source API hygiene, not a reflection security boundary.
        val seamMethods = LocalVerificationEngine.Companion::class.java.declaredMethods
            .filter { it.name.startsWith("withScriptedPublicCalls") }
        val callableFactories = seamMethods.filterNot { Modifier.isPrivate(it.modifiers) }
        assertTrue(callableFactories.isNotEmpty())
        assertTrue(callableFactories.all { it.returnType == LocalVerificationEngine::class.java && it.isSynthetic })
        // The compiler may emit a private, non-synthetic helper for the default clock lambda.
        assertTrue(seamMethods.filterNot { it.isSynthetic }.all { Modifier.isPrivate(it.modifiers) })
    }

    @Test fun internalFactoryForcesPublicModeWithoutRendering() {
        LocalVerificationEngine.withScriptedPublicCalls({ error("Unexpected scripted request") }, { 1000L }).use { engine ->
            val fixture = LocalVerificationEngine::class.java.getDeclaredField("fixtureLoopbackOnly").apply { isAccessible = true }
            val renderer = LocalVerificationEngine::class.java.getDeclaredField("renderer").apply { isAccessible = true }
            assertFalse(fixture.getBoolean(engine))
            assertNull(renderer.get(engine))
            assertEquals(setOf(EngineCapability.STATIC_PAGE, EngineCapability.LOCAL_MATCHING), engine.capabilities)
        }
    }

    @Test fun missingPublicAdmissionCannotConstructAnyCall() {
        val calls = AtomicInteger()
        val cancellation = DiscoveryCancellation()
        val operation = DiscoveryOperation(OperationContext("seam-no-admission", 5000L, cancellation), cancellation)
        val request = EngineRequest("0".repeat(32), "seam-generation", CandidateUrl(pageUrl), 4000L,
            2, 262144L, false, false, EngineNetworkConstraints(setOf("https://transport-seam.example:443")))
        LocalVerificationEngine.withScriptedPublicCalls({ calls.incrementAndGet(); error("Unexpected scripted request") }, { 1000L }).use {
            val result = it.verify(request, operation)
            assertEquals(EngineOutcome.DENIED, result.outcome)
            assertEquals(0, result.requestsConsumed)
            assertEquals(0, calls.get())
            assertTrue(it.isPhysicallyIdle())
        }
    }

    @Test fun factoryFailureIsReportedWithoutFallbackAndReleasesOwnership() {
        GrantedRequest(pageUrl).use { grant ->
            val calls = AtomicInteger()
            LocalVerificationEngine.withScriptedPublicCalls({
                calls.incrementAndGet()
                throw IOException("ESV_SCRIPTED_FACTORY_FAILURE")
            }, { 1000L }).use { engine ->
                val result = engine.verify(grant.request(), grant.operation)
                assertEquals(EngineOutcome.ERROR, result.outcome)
                assertEquals(1, result.requestsConsumed)
                assertEquals(1, calls.get())
                assertTrue(engine.isPhysicallyIdle())
            }
        }
    }

    @Test fun timeoutConfigurationFailureCancelsConstructedCallBeforeReleasingOwnership() {
        GrantedRequest(pageUrl).use { grant ->
            lateinit var call: ScriptedCall
            LocalVerificationEngine.withScriptedPublicCalls({ request ->
                ScriptedCall(request, timeoutFails = true) { error("Execute must not run") }.also { call = it }
            }, { 1000L }).use { engine ->
                val result = engine.verify(grant.request(), grant.operation)
                assertEquals(EngineOutcome.ERROR, result.outcome)
                assertFalse(call.isExecuted())
                assertTrue(call.isCanceled())
                assertEquals(1, result.requestsConsumed)
                assertTrue(engine.isPhysicallyIdle())
            }
        }
    }

    @Test fun foreignNullReturningFactoryFailsClosedWithoutSelectingRealTransport() {
        GrantedRequest(pageUrl).use { grant ->
            val calls = AtomicInteger()
            val nullableFactory: (Request) -> Call? = { calls.incrementAndGet(); null }
            // Simulate a foreign JVM callback violating Kotlin's non-null return contract.
            @Suppress("UNCHECKED_CAST")
            val invalidFactory = nullableFactory as (Request) -> Call
            LocalVerificationEngine.withScriptedPublicCalls(invalidFactory, { 1000L }).use { engine ->
                val result = engine.verify(grant.request(), grant.operation)
                assertEquals(EngineOutcome.ERROR, result.outcome)
                assertEquals(1, calls.get())
                assertEquals(1, result.requestsConsumed)
                assertTrue(engine.isPhysicallyIdle())
            }
        }
    }

    @Test fun successfulPublicPolicyReadsRobotsThenPageAndCancelsBeforeClosingBodies() {
        GrantedRequest(pageUrl).use { grant ->
            val calls = mutableListOf<ScriptedCall>()
            val bodies = mutableListOf<TrackedBody>()
            LocalVerificationEngine.withScriptedPublicCalls({ request ->
                val index = calls.size
                assertTrue(index < 2)
                assertEquals(if (index == 0) "/robots.txt" else "/watch", request.url.encodedPath)
                assertEquals(if (index == 0) "text/plain" else "text/html", request.header("Accept"))
                assertEquals("identity", request.header("Accept-Encoding"))
                assertEquals(LocalRobotsPolicy.USER_AGENT, request.header("User-Agent"))
                assertEquals("GET", request.method)
                assertNotNull(request.tag(LocalSingleExchange::class.java))
                ScriptedCall(request) { call ->
                    TrackedBody(if (index == 0) robots else html, if (index == 0) "text/plain" else "text/html",
                        onClose = { assertTrue(call.isCanceled()) }).also { bodies += it }.let { response(request, it) }
                }.also { calls += it }
            }, { 1000L }).use { engine ->
                val result = engine.verify(grant.request(), grant.operation)
                assertEquals(EngineOutcome.PAGE_EVIDENCE, result.outcome)
                assertEquals(EngineEvidence.HTML_VIDEO, result.evidence)
                assertEquals(pageUrl, result.raw?.pageUrl)
                assertEquals(2, result.requestsConsumed)
                assertEquals(2, calls.size)
                assertTrue(calls.all { it.isExecuted() && it.isCanceled() })
                assertTrue(bodies.all { it.closed.get() && it.readBytes.get() > 0 })
                assertTrue(engine.isPhysicallyIdle())
                // One-shot grant remains consumed even after successful cleanup.
                assertEquals(EngineOutcome.DENIED, engine.verify(grant.request(), grant.operation).outcome)
                assertEquals(2, calls.size)
            }
        }
    }

    @Test fun declaredOversizeBodyIsClosedWithoutReadingOrEvidence() {
        GrantedRequest(pageUrl).use { grant ->
            val calls = AtomicInteger()
            lateinit var page: TrackedBody
            LocalVerificationEngine.withScriptedPublicCalls({ request ->
                val index = calls.getAndIncrement()
                assertTrue(index < 2)
                ScriptedCall(request) { call ->
                    val body = if (index == 0) TrackedBody(robots, "text/plain") else
                        TrackedBody(html + "x".repeat(4096), "text/html", onClose = { assertTrue(call.isCanceled()) }).also { page = it }
                    response(request, body)
                }
            }, { 1000L }).use { engine ->
                val result = engine.verify(grant.request(maxBytes = 512L), grant.operation)
                assertEquals(EngineOutcome.UNKNOWN, result.outcome)
                assertNull(result.raw)
                assertEquals(2, result.requestsConsumed)
                assertTrue(page.closed.get())
                assertEquals(0, page.readBytes.get())
                assertTrue(engine.isPhysicallyIdle())
            }
        }
    }

    @Test fun malformedResponseMetadataIsDeniedBeforeReadingItsBody() {
        GrantedRequest(pageUrl).use { grant ->
            lateinit var body: TrackedBody
            val calls = AtomicInteger()
            LocalVerificationEngine.withScriptedPublicCalls({ request ->
                calls.incrementAndGet()
                ScriptedCall(request) { call ->
                    body = TrackedBody(robots, "text/plain", onClose = { assertTrue(call.isCanceled()) })
                    response(request, body).newBuilder().addHeader("Content-Type", "text/plain").build()
                }
            }, { 1000L }).use { engine ->
                val result = engine.verify(grant.request(), grant.operation)
                assertEquals(EngineOutcome.DENIED, result.outcome)
                assertEquals(1, calls.get())
                assertEquals(0, body.readBytes.get())
                assertTrue(body.closed.get())
                assertTrue(engine.isPhysicallyIdle())
            }
        }
    }

    @Test(timeout = 10000L) fun cancellationKeepsPhysicalOwnershipUntilScriptedCloseFinishes() {
        val closeEntered = CountDownLatch(1)
        val releaseClose = CountDownLatch(1)
        val caller = Executors.newSingleThreadExecutor()
        GrantedRequest(pageUrl).use { first ->
            GrantedRequest("https://transport-seam.example/second").use { second ->
                val calls = AtomicInteger()
                lateinit var active: ScriptedCall
                val engine = LocalVerificationEngine.withScriptedPublicCalls({ request ->
                    assertEquals(0, calls.getAndIncrement())
                    ScriptedCall(request) { call ->
                        response(request, TrackedBody(robots, "text/plain", onClose = {
                            assertTrue(call.isCanceled())
                            closeEntered.countDown()
                            check(releaseClose.await(5, TimeUnit.SECONDS))
                        }))
                    }.also { active = it }
                }, { 1000L })
                try {
                    val result = caller.submit<EngineResult> { engine.verify(first.request(), first.operation) }
                    assertTrue(closeEntered.await(2, TimeUnit.SECONDS))
                    first.operation.cancellation.cancel()
                    assertEquals(EngineOutcome.CANCELLED, result.get(2, TimeUnit.SECONDS).outcome)
                    assertTrue(active.isCanceled())
                    assertFalse(engine.isPhysicallyIdle())
                    assertEquals(EngineOutcome.UNAVAILABLE, engine.verify(second.request(), second.operation).outcome)
                    assertEquals(1, calls.get())
                    releaseClose.countDown()
                    awaitIdle(engine)
                    assertEquals(1, calls.get()) // Cancellation prevents the page exchange after robots cleanup.
                } finally {
                    releaseClose.countDown()
                    engine.close()
                    caller.shutdownNow()
                }
            }
        }
    }

    private fun response(request: Request, body: TrackedBody): Response = Response.Builder()
        .request(request).protocol(Protocol.HTTP_1_1).code(200).message("OK")
        .header("Content-Type", body.contentType().toString()).body(body).build()

    private fun awaitIdle(engine: LocalVerificationEngine) {
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(2)
        while (!engine.isPhysicallyIdle() && System.nanoTime() < deadline) Thread.sleep(1)
        assertTrue(engine.isPhysicallyIdle())
    }

    private class ScriptedCall(private val original: Request, private val timeoutFails: Boolean = false,
        private val executeResponse: (ScriptedCall) -> Response) : Call {
        private val executed = AtomicBoolean()
        private val cancelled = AtomicBoolean()
        private val timeout = Timeout()
        override fun request() = original
        override fun execute(): Response {
            check(executed.compareAndSet(false, true))
            return executeResponse(this)
        }
        override fun enqueue(responseCallback: Callback): Unit = error("Unexpected asynchronous call")
        override fun cancel() { cancelled.set(true) }
        override fun isExecuted() = executed.get()
        override fun isCanceled() = cancelled.get()
        override fun timeout(): Timeout {
            if (timeoutFails) throw IOException("ESV_SCRIPTED_TIMEOUT_FAILURE")
            return timeout
        }
        override fun clone(): Call = error("Unexpected cloned call")
    }

    private class TrackedBody(text: String, private val type: String, onClose: () -> Unit = {}) : ResponseBody() {
        private val bytes = text.toByteArray()
        val closed = AtomicBoolean()
        val readBytes = AtomicInteger()
        private val source = object : ForwardingSource(Buffer().write(bytes)) {
            override fun read(sink: Buffer, byteCount: Long): Long = super.read(sink, byteCount).also {
                if (it > 0) readBytes.addAndGet(it.toInt())
            }
            override fun close() {
                try { onClose() } finally { super.close(); closed.set(true) }
            }
        }.buffer()
        override fun contentType(): MediaType = type.toMediaType()
        override fun contentLength(): Long = bytes.size.toLong()
        override fun source(): BufferedSource = source
    }

    /** A real coordinator alone issues the opaque grant; neither reflection nor a fake grant is used. */
    private class GrantedRequest(pageUrl: String) : AutoCloseable {
        private data class Captured(val operation: DiscoveryOperation, val callback: (ProviderOutcome) -> Unit)
        private val captured = mutableListOf<Captured>()
        private val profile = SearchProfile("seam-profile", "owned fixture", filters = SearchFilters(safeSearch = false))
        private val source = object : VideoSearchProvider {
            override val descriptor = ProviderDescriptor("seam-source", "1")
            override fun search(request: SearchRequest, operation: DiscoveryOperation): ProviderPage = error("No source I/O")
        }
        private val runtime = object : ProviderRuntime {
            override fun execute(provider: VideoSearchProvider, request: SearchRequest, operation: DiscoveryOperation,
                callback: (ProviderOutcome) -> Unit): CancellationHandle {
                captured += Captured(operation, callback)
                return CancellationHandle { operation.cancellation.cancel() }
            }
        }
        private val timer = object : DiscoveryTimer {
            override fun schedule(delayMillis: Long, action: () -> Unit) = CancellationHandle {}
        }
        private val coordinator = VideoDiscoveryCoordinator(ProviderRegistry(listOf(source)), runtime,
            InMemoryDiscoveryStore(), timer, EpochClock { 1000L }, publicSearchCandidateVerification = true,
            monotonicMillis = { 1000L })
        private val candidate = CandidateUrl(pageUrl)
        val operation: DiscoveryOperation
        init {
            coordinator.setVisibility(true, true)
            val stamp = coordinator.start("seam-session", profile)
            val pending = requireNotNull(PendingCandidatePolicy.normalize(candidate, source.descriptor.id, profile.filters))
            captured.single().callback(ProviderOutcome.Success(ValidatedProviderPage(emptyList(), null, null, true, listOf(pending))))
            check(coordinator.verifyPending(stamp, pending.candidateId))
            operation = captured.last().operation
            check(coordinator.networkForCandidate(candidate, operation).searchCandidateAdmission != null)
        }
        fun request(maxBytes: Long = 262144L) = EngineRequest("0".repeat(32), "seam-generation", candidate,
            4000L, 2, maxBytes, false, false, coordinator.networkForCandidate(candidate, operation))
        override fun close() = coordinator.close()
    }
}
